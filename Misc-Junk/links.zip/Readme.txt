#               -------------
#                  Links
#               -------------
#               Links Manager
#
#         File: Readme.txt
#  Description: Program Documentation
#       Author: Alex Krohn
#        Email: alex@gossamer-threads.com
#          Web: http://www.gossamer-threads.com/
#      Version: 1.11
#
# COPYRIGHT NOTICE:
#
# Copyright 1997 Gossamer Threads Inc.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program 
# you agree to indemnify Gossamer Threads Inc. from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.
# =====================================================================

Revision History:
====================================================
1.11 Jun 24, 1997
  - Minor Bug fixes.
	1. Jump.cgi is overhauled. Fixed occasional file corrupting
	   bug found on heavily trafficed site. Also now works with
           random link.
        2. Added admin email check in add.cgi and modify.cgi.
        3. Added perl 5 check for admin.cgi.
	4. Added sorting modification to db.pl.
	5. Added better error checking for header/footer inclusions.
	6. Can only validate 10 links at a time.

1.1 Mar. 13, 1997
  - Lots of new changes. First major revision to the script.
  
    1.Categories are now completely separate from links. 
    2.Can add/remove/delete/modify categories exactly as you can links. 
    3.More category information like: meta tags, header, footer, etc. Can
	  easily, at least for me ;), add new attributes. 
    4.No longer need one link per category. 
    5.Routine to check to make sure every link has a matching category. 
    6.Routine to check for duplicate links (based on domain name). 
    7.Admin now allows you to edit multiple links at once. No more 
	  search-modify-search-modify-search. 
    8.Validate links now auto-emails notices that the link has been 
	  updated or added (Sorry, nothing about deletion as each case 
	  will be different and you'll
      probably want to send a personal message). 
    9.Validate links now lets you edit before adding. 
    10.Verify links has been re-vamped. It still uses LWP, but now can 
	   run using multiple processes! This should speed things up a lot 
	   if you are using a system that supports fork() (not win95, not 
	   sure about NT?). 
    11.Both nph-verify and nph-build can be run from the command line
	   and don't produce html. 
    12.Default of two columns in site_html, as well as a lot of html 
	   fix up. 
    13.nph-build rewritten, to make a lot more sense (to me at least).
	   Shouldn't affect site_html though.
    14.Can now split up links so they span multiple pages.                
	15.What's New Page can now span multiple pages.

1.0 Dec. 4, 1997  
  - First Official Release. 
  - Category Descriptions, Related Categories added.
  - Modify listing script added.
  - Date format easier to modify.
  - Various bugs squashed.

0.9 Nov. 10, 1997 - First Beta Released.

TABLE OF CONTENTS

    1. Welcome
        1.1 About the Script
        1.2 System Requirements
        1.3 Registration
    2. Installation
		2.1 Quick Install
		2.2 Detailed Install
    3. The Files
    4. Problems
	5. Revision History

1. Welcome
====================================================

1.1 About the Script
----------------------------------------------------
Links is a shareware links manager. It provides an interface for a 
visitor to browse, search and add to your directory of links. It also 
provides a powerful administration tool that can add, modify, delete, 
validate the links.

Links is based primarily on static html pages. It does not generate html
pages every time a user wants to view a category of links. Instead the 
administrator "builds" the directory when it should be updated. The 
script then recreates all the necessary html. 

This model has several advantages: 

    * security - visitors are viewing static pages and never interact
                 with the actual database.
    * speed - since the user is primarily requesting regular pages
              the server does not have to work as hard.
              
The main disadvantage is maintenance. The pages must be manually (or 
automatically using cron) rebuilt whenever the database is updated.

1.2 System Requirements
----------------------------------------------------
Links requires the following:

    * A working copy of Perl 5 (might have problems on versions less then
      5.002).
    * A basic understanding of both Perl and CGI (this should NOT
      be the first script you've ever installed. It creates directories,
      and files and other potentially hazardous stuff!).
    * An installed LWP module and NET::FTP module if you want to use the verify links
      routine. This module (like most) can be retrieved from CPAN at:
            
			http://www.perl.com/CPAN/modules/by-module/LWP/
			
      If you can't install it, the script will work fine except for the
      verify links routine.

This program has been tested on the following platforms: Win95 (without 
file locking), HP-UX 9.05 and Linux 2.0 and should work on any system 
with a working, fairly current, Perl5. 

1.3 Registration
----------------------------------------------------
Links is free for non-profit, academic, government or personal use.
However, if this script is going to be used by a for-profit company, 
there is a one time $150 US registration fee. This fee helps me offer
a support forum for people to use, and offsets a little of the development
costs.

I feel this script can add a lot of value to a website (Yahoo being the most
heavily trafficked site on the net!) and $150 US is not too much to ask. 

With registration, you get (60) sixty days of email support, although I'll 
probably be inclined to answer after that, as well as free upgrades within
the version number, and discounts after that (I don't see a version 2.0 in the
future for quite a while).

To Register, please make check/money order payable to Gossamer Threads Inc., 
and mail it to:

        Gossamer Threads Inc.
        653 Andover Pl.
        West Vancouver, B.C.
        V7S 1Y6

If you need an invoice, just send me an email and I'll be happy to fax/mail one
to you.

I also ask that if you use Links, you let me know where it is
setup (a link to my site would also be nice, though if you really
feel it wrecks the look of your site, it is not required, although I'll remember
that if you email me for support ;). (Tangent: One big pet peeve of mine is
when someone puts Get MS IE, Get Netscape Now, Built with FrontPage, etc. buttons
all over their site, yet won't put a notice to me!)

If you really like the script, feel free to use a powered by Gossamer
logo found at:

    http://www.gossamer-threads.com/images/powered.gif
	
Please do not take credit for the script. 
    
Thanks!

2. Installation
====================================================

2.1 Quick Install
----------------------------------------------------
If you are comfortable with Perl, here's some instructions that
should get the script up and running quickly.

1. Untar/Unzip the distribution and preserve directory structure.
2. Double check path to Perl is set up.
3. chmod 755 all .cgi files.
4. chmod 666 all data files in the data dir.
5. chmod 777 the backup directory, and the dir where the pages will
   be built.
6. Edit links.cfg and set things up to your liking.
7. Go to the admin index.html and make sure it works.
8. Try adding a category.
9. Try adding a link.
10. Try building the pages.
11. Password protect admin directory.

Hopefully that should be all that's necessary to get the script to
work. If you run into problems, take a look at the Problems section
below.

2.2 Detailed Install.
----------------------------------------------------
    1.) Untar/Unzip the archive, make sure the directory structure
	    is preserved.
    2.) You should find the following files, set the permissions
        accordingly (for a description of what the files do, see section 3):

-rw-r--r--   (644)  Readme.txt
-rw-r--r--   (644)  Upgrade.txt
-rwxr-xr-x   (755)  add.cgi
-rwxr-xr-x   (755)  jump.cgi
-rwxr-xr-x   (755)  modify.cgi
-rwxr-xr-x   (755)  search.cgi

drwxr-xr-x   (755)  admin
    drwxr-xr-x   (755)  headers             # Must Create
    drwxr-xr-x   (755)  footers             # Must Create
    drwxrwxrwx   (777)  backup
    drwxr-xr-x   (755)  data
        -rw-rw-rw-   (666)  links.db
        -rw-rw-rw-   (666)  linksid.txt
        -rw-rw-rw-   (666)  url.db
        -rw-rw-rw-   (666)  validate.db
        -rw-rw-rw-   (666)  categories.db
        -rw-rw-rw-   (666)  categoriesid.txt
        -rw-rw-rw-   (666)  modified.db
        -rw-rw-rw-   (666)  verify.log
    -rwxr-xr-x   (755)  admin.cgi
    -rwxr-xr-x   (755)  nph-build.cgi
    -rwxr-xr-x   (755)  nph-verify.cgi
    -rw-r--r--   (644)  links.cfg
	-rw-r--r--   (644)  links.def
	-rw-r--r--   (644)  categories.def
    -rw-r--r--   (644)  admin_html.pl
    -rw-r--r--   (644)  site_html.pl
    -rw-r--r--   (644)  db.pl
    -rw-r--r--   (644)  bookmark.pl
    -rw-r--r--   (644)  index.html
    -rw-r--r--   (644)  codes.htm
    -rw-r--r--   (644)  head.htm
    -rw-r--r--   (644)  help.htm
    -rw-r--r--   (644)  nav.htm

    3.) You will want to password protect the admin directory,
        as the admin script contains no authentication routines. See
		   
		   http://hoohoo.ncsa.uiuc.edu/docs/tutorials/user.html
		   
		for a good tutorial on how to use user authentication with
		NCSA/Apache servers.
		
    4.) The add.cgi, jump.cgi, search.cgi and modify.cgi
        should be accessible by all visitors.
		
    5.) If you use the default installation dir structure, things should
	    be ok, but otherwise you'll need to edit all the .cgi files and
		change the path to links.cfg file. Use the full path. For example,
		suppose my config file was in /gossamer/www/links/admin/links.cfg and
		my add.cgi file was in /gossamer/www/links/pages/add.cgi, then in add.cgi
		I would set:
		
			require "admin/links.cfg";
			
		to
		
			require "/gossamer/www/links/admin/links.cfg";
			
    6.) Edit Links.cfg and you'll want to change the following lines:

# PATH of Admin Script directory. No Trailing Slash.
    $db_script_path = "/path/to/admin";
# URL of Admin Script directory. No Trailing Slash.
    $db_dir_url = "http://url/to/admin
    
# PATH of Pages to be built. No Trailing Slash.
    $build_root_path = "/path/to/pages";
# URL of Pages to be built. No Trailing Slash.
    $build_root_url  = "http://url/to/pages";    

# Directory Permissions
$build_dir_per = 0755;

    NOTE: You may experience some problems with permissions. The script
    generates a directory for each category and chmod's it 0755. This means
    you might not be able to delete the directory depending on how your
    web server is set up. Try setting the permissions to 0777, or if you are
    feeling brave, create a script that removes the directory and run it from 
    the web (be sure to erase the script as soon as you are done!).
    
    ** PLEASE NOTE ** If you are installing this script I'm assuming you 
    are comfortable enough in the operating system to be able to remove
    directories created by someone else. If you aren't, pay someone to get
    the script going for you. By installing this script, you are assuming
    all liability for anything that might go wrong.
        
You should be all set! 

To test things, follow these steps:

	1. Go to the index.html included with the distribution, and try adding
	   a category.
	2. Try adding a link.
	3. Try building the pages.
	4. Try clicking on the link you just added from the pages that were just
	   built.
	5. Try searching for the link.
	6. Try adding a new link through the user interface, not the admin.
	7. Try modifying the one link you added through the admin.
	8. Try validating the links in the admin program.
	9. Try verifying the links.

If you run into problems along the way, fix them before you move on to the 
next step. Hopefully there should be some detailed error messages saying
what went wrong. Also check out the Problems section below, the FAQ and
the support forum.

2.3 Customization.
----------------------------------------------------
To customize the look of the directory, you will spend 99% of your time 
editing site_html.pl. This file contains almost all of the html a visitor
will see.

I _REALLY_ recommend you get a good text editor, my favorite being TextPad,
which you can download from:

	http://www.textpad.com/
	
or any Tucows site.

Look at the default html, and read the comments in site_html.pl to learn how
to customize it. If you get stuck, try posting a message on the forum.

3. The Files
====================================================
Interested in a few more details "under the hood"? I've included a brief
description of what each file does:

User Interface:
----------------------------------------------------
add.cgi - When called with no input, this script makes an add form for 
visitors to add links to the validate database. The links do not go 
directly into the main database, they must be approved first.                         

When called with input, the script checks to make sure the link passes 
the validation test, and then adds in any system fields as defined 
in the config. Assuming the link is ok, it puts it in the validation
database and emails the administrator that there is a link awaiting
validation.

modify.cgi - When called with no input, this script makes a modify request
form which is basically identical to an add form, only it asks for the URL
of the link to be modified.

When called with input, the script validates the link (makes sure it is
in the database, and the modified request is ok), then inserts the link
into the modified.db database and sends an email to the admin saying there
is a link waiting to be validated. 

jump.cgi - Not required, but this script tracks how many times a link
has been clicked on. It only counts one link per IP address per six hours.
If you don't care about this, a quicker way would be to just display the URL.
It is called by passing in the key name and key value of the link to go to.

search.cgi - This script searches the actual database, and returns a list of 
links. It uses the following parameters:

    query = the string to search for..
    mh = maximum number of hits...
    type = either 'keyword' or 'phrase'
    bool = either 'and' or 'or'
    
You can also choose whether or not you want the results "bolded". This is
set up in the config file.

Admin Interface:
----------------------------------------------------
admin.cgi - This is the main script and controls the following functions: 
adding, removing, modifying, viewing, validating links. For more details, 
please take a look at DBMan (http://www.gossamer-threads.com/scripts/dbman/). It
is simply a pared down version of DBMan.

The validate function deserves a couple of words. Basically when you click on
validate, it checks to see if there are any links awaiting validation. If
there are, it presents a list of links with the option of either deleting
or validating each link. If you delete it, it will be gone for good. If you 
validate it, the link will be copied into the real database. It won't appear
to the public until you rebuild the pages.

The two other options available to the admin are: build pages and verify links.

nph-build.cgi - This script should be set up as a non parsed header script if 
possible as it can take a while to complete depending on the size of the database. 
It's job is to build a set of HTML pages based that users can browse through. It
uses templates found in site_html.pl, which has some documentation you should 
read through.

nph-verify.cgi - This script verifies that each link is still ok. It requires
the LWP module available at CPAN (http://www.perl.com/CPAN/). It can take quite
a while to complete (150 links seems to average 5-8 minutes), so you might want
to run it from the command line. It produces a log file of links that failed.
Links that return a 404 error, should be checked immediately. Other errors should
be checked, but the link might still be ok (poor network connectivity, timeout
errors etc.).

admin_html.pl - This library contains all the admin html and probably
won't need to be modified.

site_html.pl - This library describes how the site will look and will have
to be extensively modified. Learn by example, and read the documentation inside.
Feel free to post a question (see Problems below) if you have any questions.

bookmark.pl - A quick script I wrote that will convert a Netscape bookmark
file to a links database. It does NOT convert descriptions at the moment.

Data Files:
----------------------------------------------------
links.db - This is your main database of links. It is a flat file, usually pipe (|)
delimited, text file.

linksid.txt - This is a counter file that stores the next ID number to use for your
links database.

categories.db - This is your category database and contains a list of all your 
categories plus the info about each category (header, footer, etc.).

categoriesid.txt - This is another counter file that stores the next ID number to use
for your category database.

url.db - This is a list of link ID's and URLs. It is used by jump.cgi to quickly
look up a URL to jump to, and also to track the number of hits a link gets.

validate.db - This is a list of links that users have suggested and are waiting to
be added to the main database.

modified.db - This is a list of links that users have requested be modified and are
waiting to be accepted.

verify.log - This is a log of what happened with the verify routine.

4. Problems
====================================================
* 500 Server Errors.
I've tried to remove as much chance of 500 server errors as possible. If you still 
get one check the following:

   - Did you upload/ftp the file up in ASCII mode?
   - Is the path to Perl right? (#!/usr/bin/perl)
   - Is the path to Perl to a version of perl5?
   - Are there any syntax errors you made when editing links.cfg?
   - Are the file set to the right permissions?
   
* Problems building pages: Illegal Characters.
The script tries to protect as much as possible against creating potentially
hazardous directories. It does two checks:

   - Make sure that the root of directory to be built is the same as the
     root specified in links.cfg
   - Make sure that the dir does not contain any weird characters. It defaults
     to allowing only letters, numbers, the _ and / characters and a -. You can
	 manually allow more characters by editing links.cfg.
	 
For a more detailed explanation see the online FAQ.

* Header/Footer problems.
The script looks at whatever you have entered in the header/footer field. It first
checks to see if what you entered is a file and if it is it will insert the contents
of that file. 

If it can't find/open the file the script will insert the value. This way you can
either specify a file or some text to use as a category header/footer. 

TIP: If you want the same text to appear on all pages, don't use a header. Just put
that text into site_html.pl.

Remember: Please be careful with the script as it does create 
directories and other potentially hazardous stuff. 

Use it at your own risk!

Good Luck!

Alex Krohn
Gossamer Threads Inc.
