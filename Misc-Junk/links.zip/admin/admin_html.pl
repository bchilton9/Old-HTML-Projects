#!/usr/bin/perl
#
#               -------------
#				   Links
#               -------------
#               Links Manager
#
#         File: admin_html.pl
#  Description: This library contains all the html used in the admin 
#               interface.
#       Author: Alex Krohn
#        Email: alex@gossamer-threads.com
#          Web: http://www.gossamer-threads.com/
#      Version: 1.11
#
# COPYRIGHT NOTICE:
#
# Copyright 1997 Gossamer Threads Inc.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program 
# you agree to indemnify Gossamer Threads Inc. from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.
# =====================================================================

##########################################################
##					  Globals							##
##########################################################

$body = qq|BODY BGCOLOR="#FFFFFF"|;

$html_search_options =  qq!
    <STRONG>Search Options: (use "*" to match everything in a field)</STRONG><BR>
    <INPUT TYPE="TEXT" NAME="keyword" SIZE=15 MAXSIZE=255> Keyword Search <INPUT TYPE="TEXT" NAME="mh" VALUE="$db_max_hits" SIZE=3 MAXSIZE=4> Max. Returned Hits<BR>
    <INPUT TYPE="CHECKBOX" NAME="ma"> Match Any  <INPUT TYPE="CHECKBOX" NAME="cs"> Match Case <INPUT TYPE="CHECKBOX" NAME="ww"> Match Whole Words <INPUT TYPE="CHECKBOX" NAME="re"> Regular Expression
!;
         
$html_footer = qq!
        <h5 align=center>&copy 1998 <a href="http://www.gossamer-threads.com/" target="_blank">Gossamer Threads Inc.</a></h5>
!; 

##########################################################
##					  Adding					      ##
##########################################################

sub html_add_form {
# --------------------------------------------------------
# The add form page where the user fills out all the details
# on the new record he would like to add. You should use 
# &html_record_form to print out the form as it makes
# updating much easier. Feel free to edit &get_defaults
# to change the default values.

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Add a New Record</TITLE>
</HEAD>

<$body>
    <H2><TT>Add a New Record</TT></H2>
        <FORM ACTION="$db_script_url" METHOD="POST">
            |; &html_record_form (&get_defaults); print qq|
           <P><INPUT TYPE="HIDDEN" NAME="add_record" VALUE="1">
           <INPUT TYPE="SUBMIT" VALUE="Add Record"> <INPUT TYPE="RESET" VALUE="Reset Form">
         </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_add_success {
# --------------------------------------------------------
# The page that is returned upon a successful addition to
# the database. You should use &get_record and &html_record
# to verify that the record was inserted properly and to make
# updating easier.

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Record Added.</TITLE>
</HEAD>

<$body>
    <H2><TT>Record Added.</TT></H2>
    <P><Font face="Verdana, Arial, Helvetica" Size=2>The following record was successfully added to the database:</FONT>
|; &html_record(&get_record($in{$db_key})); print qq|   
    <P><Font face="Verdana, Arial, Helvetica" Size=2>Add Another?</FONT>
        <FORM ACTION="$db_script_url" METHOD="POST">
            |; &html_record_form (&get_defaults); print qq|
           <P><INPUT TYPE="HIDDEN" NAME="add_record" VALUE="1">
           <INPUT TYPE="SUBMIT" VALUE="Add Record"> <INPUT TYPE="RESET" VALUE="Reset Form">
         </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_add_failure {
# --------------------------------------------------------
# The page that is returned if the addition failed. An error message 
# is passed in explaining what happened in $message and the form is
# reprinted out saving the input (by passing in %in to html_record_form).

    my ($message) = $_[0];
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Error! Unable to Add Record.</TITLE>
</HEAD>

<$body>
    <H2><TT><FONT COLOR="red">Error! Unable to Add Record.</FONT></TT></H2>
    <P>There were problems with the following fields: <FONT COLOR="red"><B>$message</B></FONT>
    <BR>Please fix any errors and submit the record again.
    <P>
    <FORM ACTION="$db_script_url" METHOD="POST">
        |; &html_record_form (%in); print qq|
       <P><INPUT TYPE="HIDDEN" NAME="add_record" VALUE="1">
       <INPUT TYPE="SUBMIT" VALUE="Add Record"> <INPUT TYPE="RESET" VALUE="Reset Form">
     </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_add_record_mult {
# --------------------------------------------------------
# This page is returned upon successful completion of check_links.
# It really ownly works with multiple category additions, but should
# be generalized to work with other databases.

	my ($categories) = @_;

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Categories Added.</TITLE>
</HEAD>

<$body>
    <H2><TT>Categories Added.</TT></H2>
    <P><Font face="Verdana, Arial, Helvetica" Size=2>The following categories were successfully added:
	<strong>$categories</strong>
	</FONT>
	
    $html_footer
</BODY>
</HTML>
|;
}

##########################################################
##					  Viewing					     ##
##########################################################

sub html_view_search {
# --------------------------------------------------------
# This page is displayed when a user requests to search the 
# database for viewing. 

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Search the Database.</TITLE>
</HEAD>

<$body>
    <H2><TT>Search the Database.</TT></H2>
    <P>
    <FORM ACTION="$db_script_url" METHOD="GET">
    |;  &html_record_form(); print qq|
        <P>$html_search_options
        <P><INPUT TYPE="HIDDEN" NAME="view_records" VALUE="1">
        <INPUT TYPE="SUBMIT" VALUE="View Records"> <INPUT TYPE="RESET" VALUE="Reset Form">
    </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_view_success {
# --------------------------------------------------------
# This page displays the results of a successful search. The hits
# are stored in an array @hits and the number of hits is calculated
# and stored in $numhits.
# A little work must be done to convert each hit to a hash to pass off
# to html_record for printing.

    my ($i, $col, %tmp);
    my (@hits) = @_;
    my ($numhits) = ($#hits+1) / ($#db_cols+1);
    my ($maxhits) = $db_max_hits;
    $maxhits = $in{'mh'} if ($in{'mh'});
    
    &html_print_headers;    
    print qq|
<HTML>
<HEAD>
    <TITLE>Search Results.</TITLE>
</HEAD>

<$body>
    <H2><TT>Search Results.</TT></H2>
|;
    if ($numhits == $maxhits) {
        print qq|<P>Your search returned the maximum of <strong>$maxhits</strong> records.
				 <A HREF="$db_search_next_url">Next $maxhits</a>?
				|;
    }
    else {
        print qq|<P>Your search returned <strong>$numhits</strong> records:
				 <P>|;
    }

# Go through each hit and convert the array to hash and send to 
# html_record for printing.
    for ($i = 0; $i < $numhits; $i++) {
        %tmp = &array_to_hash ($i, @hits); 
        print "<P>";
        &html_record (%tmp);
    }

print qq|
        <P><CENTER><A HREF="$db_script_url?view_search=1">Search Again?</A></CENTER>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_view_failure {
# --------------------------------------------------------
# The search for viewing failed. The reason is stored in $message
# and a new search form is printed out.

    my ($message) = $_[0];
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Search Failed.</TITLE>
</HEAD>

<$body>
    <H2><TT><FONT COLOR="red">Search Failed.</FONT></TT></H2>
    <P>There were problems with the search. Reason: <FONT COLOR="red"><B>$message</B></FONT>
    <BR>Please fix any errors and submit the record again.
    <P>
    <FORM ACTION="$db_script_url" METHOD="GET">
        |; &html_record_form(); print qq|
        <P>$html_search_options
        <P><INPUT TYPE="HIDDEN" NAME="view_records" VALUE="1">
        <INPUT TYPE="SUBMIT" VALUE="View Records"> <INPUT TYPE="RESET" VALUE="Reset Form">
    </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

##########################################################
##					  Deleting					    ##
##########################################################

sub html_delete_search {
# --------------------------------------------------------
# The page is displayed when a user wants to delete records. First
# the user has to search the database to pick which records to delete.
# That's handled by this form.

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Search the Database for Deletion.</TITLE>
</HEAD>

<$body>
    <H2><TT>Search the Database for Deletion.</TT></H2>
    <P>Search the database for the records you wish to delete or 
       <A HREF="$db_script_url?delete_form=1&$db_key=*">list all</a>:
    <P>
    <FORM ACTION="$db_script_url" METHOD="GET">
    |;  &html_record_form(); print qq|
        <P>$html_search_options
        <P><INPUT TYPE="HIDDEN" NAME="delete_form" VALUE="1">
        <INPUT TYPE="SUBMIT" VALUE="Search"> <INPUT TYPE="RESET" VALUE="Reset Form">
    </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_delete_form {
# --------------------------------------------------------
# The user has searched the database for deletion and must now
# pick which records to delete from the records returned. This page
# should produce a checkbox with name=ID value=delete for each record.
# We have to do a little work to convert the array @hits that contains
# the search results to a hash for printing.

    my ($status, @hits) = &query(); 
    my ($numhits) = ($#hits+1) / ($#db_cols+1);
    my ($maxhits) = $db_max_hits;
    $maxhits = $in{'mh'} if ($in{'mh'});
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Delete Record(s).</TITLE>
</HEAD>

<$body>
    <H2><TT>Delete Record(s).</TT></H2>
    <P>Check which records you wish to delete and then press "Delete Records":
|;

    if ($numhits == $maxhits) {
        print qq|<P>Your search returned the maximum of <strong>$maxhits</strong> records.
				 <A HREF="$db_search_next_url">Next $maxhits</a>?
				|;
    }
    else {
        print qq|<P>Your search returned <strong>$numhits</strong> records:
				 <P>|;
    }
    
print qq|<FORM ACTION="$db_script_url" METHOD="POST">
         <TABLE BORDER=1>|;

# Go through each hit and convert the array to hash and send to 
# html_record for printing. Also add a checkbox with name=key and value=delete.

    if ($status ne "ok") {  # There was an error searching!
        print qq|<TR><TD><FONT COLOR="RED" SIZE=4>Error: $status</FONT></TD></TR>|;
    }
    else {
# Print Column Headers
		print "<tr><th>$db_key</th>";	
		foreach $col (@db_record_header_columns) {
			print qq|<th>$col</th>|;
		}
		print "</tr>";

# Print Main Body.		
        for ($i = 0; $i < $numhits; $i++) {
            %tmp = &array_to_hash ($i, @hits);
            print qq|<TR><TD><INPUT TYPE=CHECKBOX NAME="$tmp{$db_key}" VALUE="delete"> $tmp{$db_key}</TD>|;
            &html_record_spreadsheet (%tmp);
            print qq|</TR>|;
        }
    }
print qq|
    </TABLE>
    <P><INPUT TYPE="HIDDEN" NAME="delete_records" VALUE="1">
       <INPUT TYPE="SUBMIT" VALUE="Delete Checked Record(s)"> <INPUT TYPE="RESET" VALUE="Reset Form">
    </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_delete_success {
# --------------------------------------------------------
# This page let's the user know that the records were successfully
# deleted.

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Record(s) Deleted.</TITLE>
</HEAD>

<$body>
    <H2><TT>Record(s) Deleted.</TT></H2>
    <P>The requested records were successfully deleted from the database.
    $html_footer
</BODY>
</HTML>
|;
}

sub html_delete_failure {
# --------------------------------------------------------
# This page let's the user know that some/all of the records were
# not deleted (because they were not found in the database). 
# $errstr contains a list of records not deleted.

    my ($errstr) = $_[0];
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Error: Record(s) Not Deleted.</TITLE>
</HEAD>

<$body>
    <H2><TT><FONT COLOR="red">Error! Unable to Delete Record(s).</FONT></TT></H2>
    <P>The records with the following keys were not found in the database: <FONT COLOR="red">$errstr</FONT>.
    $html_footer
</BODY>
</HTML>
|;  
}

##########################################################
##					  Modifying							##
##########################################################
sub html_modify_search {
# --------------------------------------------------------
# The page is displayed when a user wants to modify a record. First
# the user has to search the database to pick which record to modify.
# That's handled by this form.

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Search the Database for Modifying.</TITLE>
</HEAD>

<$body>
    <H2><TT>Search the Database for Modifying.</TT></H2>
    <P>Search the database for the record you wish to modify or
      <A HREF="$db_script_url?modify_form_mult=1&$db_key=*">list all</a>:
    <P>
    <FORM ACTION="$db_script_url" METHOD="GET">
    |;  &html_record_form(); print qq|
        <P>$html_search_options
        <P><INPUT TYPE="HIDDEN" NAME="modify_form_mult" VALUE="1">
        <INPUT TYPE="SUBMIT" VALUE="Search"> <INPUT TYPE="RESET" VALUE="Reset Form">
    </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_modify_form {
# --------------------------------------------------------
# The user has searched the database for modification and must now
# pick which record to modify from the records returned. This page
# should produce a radio button with name=modify value=ID for each record.
# We have to do a little work to convert the array @hits that contains
# the search results to a hash for printing.

    my ($status, @hits) = &query(); 
    my ($numhits) = ($#hits+1) / ($#db_cols+1);
    if ($numhits == 1) {            # Only one result, so let's modify it.
        $in{'modify'} = $hits[0];
        &html_modify_form_record();
    }
    else {
        my ($maxhits) = $db_max_hits;
        $maxhits = $in{'mh'} if ($in{'mh'});

        &html_print_headers;
        print qq|
<HTML>
<HEAD>
    <TITLE>Modify Record.</TITLE>
</HEAD>

<$body>
    <H2><TT>Modify Record.</TT></H2>
    <P>Check which record you wish to modify and then press "Modify Record":
|;
# Print out how many hits, if maximum, produce a link to get next n hits.
    if ($numhits == $maxhits) {
        print qq|<P>Your search returned the maximum of <strong>$maxhits</strong> records.
				 <A HREF="$db_search_next_url">Next $maxhits</a>?
				|;
    }
    else {
        print qq|<P>Your search returned <strong>$numhits</strong> records:
				 <P>|;
    }
    
print qq|<P>
    <FORM ACTION="$db_script_url" METHOD="POST">
    <TABLE>|;

# Go through each hit and convert the array to hash and send to 
# html_record for printing. Also add a radio button with name=modify
# and value=key.
    if ($status ne "ok") {  # Error searching database!
        print qq|<TR><TD><FONT COLOR="RED" SIZE=4>Error: $status</FONT></TD></TR>|;
    }
    else {
        for ($i = 0; $i < $numhits; $i++) {
            %tmp = &array_to_hash ($i, @hits);
            print qq|<TR><TD><INPUT TYPE=RADIO NAME="modify" VALUE="$tmp{$db_key}"></TD><TD>|;
            &html_record (%tmp);
            print qq|</TD></TR>|;
        }
    }
print qq|
    </TABLE>
    <P><INPUT TYPE="HIDDEN" NAME="modify_form_record" VALUE="1">
       <INPUT TYPE="SUBMIT" VALUE="Modify Record"> <INPUT TYPE="RESET" VALUE="Reset Form">
    </FORM>
    $html_footer
</BODY>
</HTML>
|;
    }
}

sub html_modify_form_mult {
# --------------------------------------------------------
# Allows modification of more then one record at a time.
#
	my ($errstr, $succstr) = @_;
	
    my ($status, @hits) = &query(); 
    my ($numhits) = ($#hits+1) / ($#db_cols+1);
	my ($maxhits) = $db_max_hits;
	$maxhits = $in{'mh'} if ($in{'mh'});

	if ($numhits == 1) {
		$in{'modify'} = $hits[0];
		&html_modify_form_record();
		return;
	}
	
	&html_print_headers;
        print qq|
<HTML>
<HEAD>
    <TITLE>Modify a Record</TITLE>
</HEAD>

<$body>
    <H2><TT>Modify a Record</TT></H2>
|;
if ($errstr) {
	print qq|<font color=red><strong>$errstr</strong></font>|;
}
if ($succstr) {
	print qq|The following records were successfully modified: <font color=red><strong>$succstr</strong></font>.|;
}
else {
	print qq|	<P>
		<p>Check which record you wish to modify and then press "Modify Record":|;

# Print out how many hits, if maximum, produce a link to get next n hits.
	    if ($numhits == $maxhits) {
	        print qq|<P>Your search returned the maximum of <strong>$maxhits</strong> records.
					 <A HREF="$db_search_next_url">Next $maxhits</a>?
					|;
	    }   
print qq|
	    <FORM ACTION="$db_script_url" METHOD="POST">
	    <TABLE BORDER=1>|;
	
# We need to pre load the available categories so we don't search the database for
# every link! We store the results in $db_select_field so the script can use 
# &build_select_field as if it was a normal select field.	
	    if ($status ne "ok") {  # Error searching database!
	        print qq|<TR><TD><FONT COLOR="RED" SIZE=4>Error: $status</FONT></TD></TR>|;
	    }
	    else {
# Pre Load the category list.		
			$db_select_fields{'Category'} = $db_select_fields{'Related'} = join (",", &category_list);

# Print Column Headers
			print "<tr><th>$db_key</th>";
			foreach $col (@db_form_header_columns) {
				print qq|<th>$col</th>|;
			}
			print "</tr>";

# Print Main Body.		
	        for ($i = 0; $i < $numhits; $i++) {
	            %tmp = &array_to_hash ($i, @hits);
	            print qq|<TR><TD VALIGN=TOP><nobr><INPUT TYPE=CHECKBOX NAME="$tmp{$db_key}" VALUE="modify">$tmp{$db_key} </nobr></TD>|;
	            &html_record_form_spreadsheet (%tmp);
	            print qq|</TR>|;
	        }
			print "</table>";
	    }

# Print out how many hits, if maximum, produce a link to get next n hits.
	    if ($numhits == $maxhits) {
	        print qq|<P>Your search returned the maximum of <strong>$maxhits</strong> records.
				 <A HREF="$db_search_next_url">Next $maxhits</a>?
					|;
	    }   	
print qq|
	    <P><INPUT TYPE="HIDDEN" NAME="modify_record_mult" VALUE="1">
	       <INPUT TYPE="SUBMIT" VALUE="Modify Record"> <INPUT TYPE="RESET" VALUE="Reset Form">
	    </FORM>
    	|; 
	}
	print qq|$html_footer
</BODY>
</HTML>
|;
}

sub html_modify_form_record {
# --------------------------------------------------------
# The user has picked a record to modify and it should appear
# filled in here stored in %rec. If we can't find the record,
# the user is sent to modify_failure.

    my (%rec) = &get_record($in{'modify'});
    if (!%rec) { &html_modify_failure("unable to find record/no record specified: $in{'modify'}"); }
    else {
        &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Modify a Record</TITLE>
</HEAD>

<$body>
    <H2><TT>Modify a Record</TT></H2>
        <FORM ACTION="$db_script_url" METHOD="POST">
            |; &html_record_form (%rec); print qq|
           <P><INPUT TYPE="HIDDEN" NAME="modify_record" VALUE="1">
           <INPUT TYPE="SUBMIT" VALUE="Modify Record"> <INPUT TYPE="RESET" VALUE="Reset Form">
         </FORM>
    $html_footer
</BODY>
</HTML>
|;
    }
}

sub html_modify_success {
# --------------------------------------------------------
# The user has successfully modified a record, and this page will 
# display the modified record as a confirmation.

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Record Modified.</TITLE>
</HEAD>

<$body>
    <H2><TT>Record Modified.</TT></H2>
    <P><Font face="Verdana, Arial, Helvetica" Size=2>The following record was successfully modified:</FONT>
    |; &html_record(&get_record($in{$db_key})); print qq|
    $html_footer
</BODY>
</HTML>
|;
}

sub html_modify_failure {
# --------------------------------------------------------
# There was an error modifying the record. $message contains
# the reason why.

    my ($message) = $_[0];
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Error! Unable to Modify Record.</TITLE>
</HEAD>

<$body>
    <H2><TT><FONT COLOR="red">Error! Unable to Modify Record.</FONT></TT></H2>
    <P>There were problems modifying the record: <FONT COLOR="red"><B>$message</B></FONT>
    <BR>Please fix any errors and submit the record again.
    <P>
    <FORM ACTION="$db_script_url" METHOD="POST">
        |; &html_record_form (%in); print qq|
       <P><INPUT TYPE="HIDDEN" NAME="modify_record" VALUE="1">
       <INPUT TYPE="SUBMIT" VALUE="Modify Record"> <INPUT TYPE="RESET" VALUE="Reset Form">
     </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

##########################################################
##					  Validation						##
##########################################################
sub html_validate_form {
# --------------------------------------------------------
# This page produces a list of records waiting to be validated, 
# from which the admin can either delete, or validate the records.

# First let's just get a list of all the records to validate/modify.
    my (@lines, @valhits, @modhits, $numhits, $counter);
    
    open (VALIDATE, "<$db_valid_name") or &cgierr("unable to open validation file: $db_valid_name. Reason: $!");    
        @lines = <VALIDATE>;
    close VALIDATE; 
    LINE: foreach $line (@lines) {
        next LINE if ($line =~ /^#/); next LINE if ($line =~ /^\s*$/);
        push (@valhits, &split_decode($line));
    }
    open (MODIFY, "<$db_modified_name") or &cgierr("unable to open validation file: $db_valid_name. Reason: $!");    
        @lines = <MODIFY>;
    close MODIFY; 
    LINE: foreach $line (@lines) {
        next LINE if ($line =~ /^#/); next LINE if ($line =~ /^\s*$/);
        push (@modhits, &split_decode($line));
    }	
    $numhits = (($#valhits+1) + ($#modhits+1)) / ($#db_cols+1);

# Now let's print out the page:     
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Validate Record(s).</TITLE>
</HEAD>

<$body>
    <H2><TT>Validate Record(s).</TT></H2>
    <P>Check which records ($numhits) you wish to validate and then press "Validate Records". <br>
	   Only 10 records are displayed at a time.<br>
	   Click on the validate link to open a new window to preview the site.
    <FORM ACTION="$db_script_url" METHOD="POST">
         <TABLE BORDER=1>|;
# Print Column Headers
		print "<tr><th>Action</th>";
		foreach $col (@db_form_header_columns) {
			print qq|<th>$col</th>|;
		}
		print "</tr>";
		
# Pre Load Category List
	$db_select_fields{'Category'} = join (",", &category_list);

# Counter, we only want to display 10 at a time.
	$counter = 0;

# Go through each validated hit and convert the array to hash and send to 
# html_record for printing. Also add a checkbox with name=key and value=delete.
    for ($i = 0; $i < ($#valhits+1) / ($#db_cols+1); $i++) {
		last if (++$counter > 10);
        %tmp = &array_to_hash ($i, @valhits);
        print qq|<TR><TD>
<PRE><a href="$tmp{'URL'}" target="_blank">validate</a>: <INPUT TYPE="RADIO" NAME="$tmp{$db_key}" VALUE="validate">
  delete: <INPUT TYPE="RADIO" NAME="$tmp{$db_key}" VALUE="delete"></PRE></TD>|;
        &html_record_form_spreadsheet (%tmp);
        print qq|</TD></TR>|;		
    }

# Go through each modified hit and convert the array to hash and send to 
# html_record for printing. Also add a checkbox with name=key and value=delete.
    for ($i = 0; $i < ($#modhits+1) / ($#db_cols+1); $i++) {
		last if (++$counter > 10);
        %tmp = &array_to_hash ($i, @modhits);
        print qq|<TR><TD>
<PRE>modify: <INPUT TYPE="RADIO" NAME="$tmp{$db_key}" VALUE="modify">
delete: <INPUT TYPE="RADIO" NAME="$tmp{$db_key}" VALUE="delete"></PRE></TD>|;
        &html_record_form_spreadsheet (%tmp);
        print qq|</TD></TR>|;
    }


print qq|
    </TABLE>
    <P><INPUT TYPE="HIDDEN" NAME="validate_records" VALUE="1">
       <INPUT TYPE="SUBMIT" VALUE="Validate/Delete Selected Record(s)"> <INPUT TYPE="RESET" VALUE="Reset Form">
    </FORM>
    $html_footer
</BODY>
</HTML>
|;
}

sub html_validate_success {
# --------------------------------------------------------
# This page let's the user know that the records were successfully
# validated.
	my ($valsuc, $modsuc, $delsuc) = @_;
	
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Record(s) Validated/Deleted.</TITLE>
</HEAD>

<$body>
    <H2><TT>Record(s) Validated/Deleted.</TT></H2>
    <P>|; 
	
print "The following records were successfully validated: $valsuc<br>" if ($valsuc);
print "The following records were successfully modified: $modsuc<br>" if ($modsuc);
print "The following records were successfully deleted: $delsuc<br>" if ($delsuc);
print qq|
$html_footer
</BODY>
</HTML>
|;
}

sub html_validate_failure {
# --------------------------------------------------------
# This page let's the user know that some/all of the records were
# not validated (because they were not found in the database). 
# $errstr contains a list of records not deleted.

    my ($errstr) = $_[0];
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Error: Problems Validating Records.</TITLE>
</HEAD>

<$body>
    <H2><TT><FONT COLOR="red">Error! Problems Validating Records.</FONT></TT></H2>
    <P>There were problems with the validation:
	<FONT COLOR="red">	
	<ul>
	$errstr
	</ul>
	</FONT>.
    <P>|; 
	
print "The following records were successfully validated: $valsuc<br>" if ($valsuc);
print "The following records were successfully modified: $modsuc<br>" if ($modsuc);
print "The following records were successfully deleted: $delsuc<br>" if ($delsuc);
print qq|	
$html_footer
</BODY>
</HTML>
|;  
}

##########################################################
##					  Email Messages					##
##########################################################

sub html_validate_email {
# --------------------------------------------------------
# All the link information is stored in %link.
	my (%link) = @_;

	open (MAIL, "|$db_mail_path") or &cgierr ("unable to open mail: $db_mail_path. Reason: $!");
	print MAIL "To: $link{'Contact Name'} <$link{'Contact Email'}>\n";
	print MAIL "From: $db_admin_email\n";
	print MAIL "Subject: Your link has been added!\n\n";
	print MAIL qq|
Thank you for visiting our site. We've added the following link into
our directory:

Title: $link{'Title'}
URL: $link{'URL'}
Category: $link{'Category'}
Description: $link{'Description'}
Contact Name: $link{'Contact Name'}
Contact Email: $link{'Contact Email'}

You can see your new listing at:

  $build_root_url

Should you have any questions, please don't hesitate to ask.

Sincerely,

Links Manager.
|;
	close MAIL;
}

sub html_modify_email {
# --------------------------------------------------------
# All the link information is stored in %link.
	my (%link) = @_;

	open (MAIL, "|$db_mail_path") or &cgierr ("unable to open mail: $db_mail_path. Reason: $!");
	print MAIL "To: $link{'Contact Name'} <$link{'Contact Email'}>\n";
	print MAIL "From: $db_admin_email\n";
	print MAIL "Subject: Your link has been modified!\n\n";
	print MAIL qq|
Thank you for visiting our site. We've modified your link as
you requested. Here's our new listing:

Title: $link{'Title'}
URL: $link{'URL'}
Category: $link{'Category'}
Description: $link{'Description'}
Contact Name: $link{'Contact Name'}
Contact Email: $link{'Contact Email'}

You can see your updated listing at:

  $build_root_url
  
Should you have any questions, please don't hesitate to ask.

Sincerely,

Links Manager.
|;
	close MAIL;
}

##########################################################
##					  Misc								##
##########################################################

sub html_check_links {
# --------------------------------------------------------
# This routine checks to make sure that there are no links w/o
# associated categories.
#

	my ($bad_category, @bad_links) = @_;
    my ($numhits) = ($#bad_links+1) / ($#db_cols+1);
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Check Links.</TITLE>
</HEAD>

<$body>
    <H2><TT>Check Links: Find Links with No Associated Category.</TT></H2>
|;
    if (!$bad_category) {
        print qq|<P>There were no problems found!|;
    }
    else {
        print qq|<P>You have some links in your links database that are associated with a category that does not exist
					in the category database. You can <b>either</b> delete the problem links, or add the missing categories.
				 <P>To add the categories, click on the checkboxes for the categories you wish to add, and then click add. To
				    delete the links, click on the links you wish to remove and then click delete (<strong>note: outputs a max of $db_max_hits links
					to delete</strong>).
			     <FORM ACTION="$db_script_url/category" METHOD="POST">
				 <SCRIPT LANGUAGE="Javascript">
				 <!--
				 	function check_all () {
						var loop = 0;
						for (loop=0; loop < window.document.forms[0].elements.length; loop++) {							
							window.document.forms[0].elements[loop].checked = true;
						}
					}
					
					function clear_all () {
						var loop = 0;
						for (loop=0; loop < window.document.forms[0].elements.length; loop++) {							
							window.document.forms[0].elements[loop].checked = false;
						}
					}						
				// -->
				 </SCRIPT>
				 <P><INPUT TYPE=BUTTON VALUE="Check All" OnClick="check_all(); return true;">
				    <INPUT TYPE=BUTTON VALUE="Clear All" OnClick="clear_all(); return true;"></P>
				 <P>
				 <TABLE BORDER=1>$bad_category</TABLE>
				 <P><INPUT TYPE="HIDDEN" NAME="add_record_mult" VALUE="1">
				 <INPUT TYPE="SUBMIT" VALUE="Add Checked Categories"> <INPUT TYPE="RESET" VALUE="Reset Form"></FORM>
				 <hr width=100% size=1 noshade>
				 <p>To delete the offending links, click on the checkboxes and click delete:
    			 <FORM ACTION="$db_script_url/links" METHOD="POST">
		         <TABLE BORDER=1>
		|;
		# Print Column Headers
				print "<tr><th>Delete</th>";
				foreach $col (@db_record_header_columns) {
					print qq|<th>$col</th>|;
				}
		print "</tr>";
		for ($i = 0; $i < $numhits; $i++) {
			%tmp = &array_to_hash ($i, @bad_links);
			print qq|<TR><TD><INPUT TYPE=CHECKBOX NAME="$tmp{$db_key}" VALUE="delete"></TD>|;
			&html_record_spreadsheet (%tmp);
			print qq|</TR>|;
		}
		print qq|
			    </TABLE>
			    <P><INPUT TYPE="HIDDEN" NAME="delete_records" VALUE="1">
			       <INPUT TYPE="SUBMIT" VALUE="Delete Checked Record(s)"> <INPUT TYPE="RESET" VALUE="Reset Form">
			    </FORM>
	    |; 
	}
	print qq|
	$html_footer
</BODY>
</HTML>
|;
}

sub html_check_duplicates {
# --------------------------------------------------------
# This routine checks to see if there are any duplicate links.
#

	my (@dup_links) = @_;
    my ($numhits) = ($#dup_links+1) / ($#db_cols+1);
    
    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Check Duplicate Links.</TITLE>
</HEAD>

<$body>
    <H2><TT>Check Links: Find Duplicate Links.</TT></H2>
|;
	if (!$numhits) {
		print "<P>No duplicates found!";
	}
	else {
		print qq|
			 <p>To delete the offending links, click on the checkboxes and click delete:
	 		<FORM ACTION="$db_script_url/links" METHOD="POST">
		     <TABLE BORDER=1>
		|;
# Print Column Headers
		print "<tr><th>Delete</th>";
		foreach $col (@db_record_header_columns) {
			print qq|<th>$col</th>|;
		}
		print "</tr>";
	
		for ($i = 0; $i < $numhits; $i++) {
			%tmp = &array_to_hash ($i, @dup_links);
			print qq|<TR><TD><INPUT TYPE=CHECKBOX NAME="$tmp{$db_key}" VALUE="delete"></TD>|;
			&html_record_spreadsheet (%tmp);
			print qq|</TR>|;
		}
		print qq|
		    </TABLE>
			    <P><INPUT TYPE="HIDDEN" NAME="delete_records" VALUE="1">
			       <INPUT TYPE="SUBMIT" VALUE="Delete Checked Record(s)"> <INPUT TYPE="RESET" VALUE="Reset Form">
			    </FORM>
	    |; 
	}
	print qq|
	$html_footer
</BODY>
</HTML>
|;
}

sub html_unkown_action {
# --------------------------------------------------------
# The program received a command it did not recognize.

    &html_print_headers;
    print qq|
<HTML>
<HEAD>
    <TITLE>Error! Unkown Action.</TITLE>
</HEAD>

<$body>
    <H2><TT>Error! Unkown Action.</TT></H2>
    <P>The database program received a command that it does not recognize. Remember, you have to call
	   the script from the included html files, not by itself.  
     $html_footer       
</BODY>
</HTML>
|;
}

1;