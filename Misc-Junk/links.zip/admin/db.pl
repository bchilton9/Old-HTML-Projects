#!/usr/bin/perl
#
#			   -------------
#				   Links
#			   -------------
#			   Links Manager
#
#		 File: db.pl
#  Description: Contains the heart of the admin program. All the database 
#			   routines are stored here.
#	   Author: Alex Krohn
#		Email: alex@gossamer-threads.com
#		  Web: http://www.gossamer-threads.com/
#	  Version: 1.11
#
# COPYRIGHT NOTICE:
#
# Copyright 1997 Gossamer Threads Inc.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program 
# you agree to indemnify Gossamer Threads Inc. from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.
# =====================================================================

sub add_record {
# --------------------------------------------------------
# Adds a record to the database. First, validate_record is called
# to make sure the record is ok to add. If it is, then the record is
# encoded and added to the database and the user is sent to 
# html_add_success, otherwise the user is sent to html_add_failure with
# an error message explaining why. The counter file is also updated to the
# next number.

	my ($output, $status);
	
	$status = &validate_record;
	if ($status eq "ok") {
		open (DB, ">>$db_file_name") or &cgierr("error in add_record. unable to open database: $db_file_name. Reason: $!");
			flock(DB, $LOCK_EX) unless (!$db_use_flock);		
			print DB &join_encode(%in); 
		close DB;	   # automatically removes file lock
		open (ID, ">$db_id_file_name") or &cgierr("error in add_record. unable to open id file: $db_id_file_name. Reason: $!");
			flock(ID, $LOCK_EX) unless (!$db_use_flock);
			print ID $in{'ID'};	 # update counter.
		close ID;	   # automatically removes file lock
		&html_add_success;
	}
	else {
		&html_add_failure($status);
	}
}

sub add_record_mult {
# --------------------------------------------------------
# Adds multiple records to the database. This routine only works
# with check_links to add multiple categories. It should really
# be generalized to work with any database.
#

	my ($id, $category, @categories, %tmp, $output);

	open (ID, "<$db_id_file_name") or &cgierr("error in add_record_mult. unable to open id file: $db_id_file_name. Reason: $!");
		$id = int <ID>;
	close ID;	   # automatically removes file lock

	$output = "<ul>";
	foreach $key (keys %in) {
		if ($in{$key} eq "add") {
			push (@categories, $key);
			$output .= "<li>$key\n";
		}		
	}
	$output .= "</ul>";
	
	if ($#categories < 0) {
		&html_add_record_mult ("no categories specified!");
		return;
	}

	open (DB, ">>$db_file_name") or &cgierr("error in add_record_mult. unable to open database: $db_file_name. Reason: $!");
		flock(DB, $LOCK_EX) unless (!$db_use_flock);
		foreach $category (@categories) {
			$tmp{$db_key} = ++$id;
			$tmp{'Name'}  = $category;
			print DB &join_encode(%tmp);
		}
	close DB;	   # automatically removes file lock

	open (ID, ">$db_id_file_name") or &cgierr("error in add_record_mult. unable to open id file: $db_id_file_name. Reason: $!");
		flock(ID, $LOCK_EX) unless (!$db_use_flock);
		print ID $id;	 # update counter.
	close ID;	   # automatically removes file lock
	
	&html_add_record_mult ($output);
}

sub delete_records {
# --------------------------------------------------------
# Deletes a single or multiple records. First the routine goes thrrough
# the form input and makes sure there are some records to delete. It then goes
# through the database deleting each entry and marking it deleted. If there
# are any keys not deleted, an error message will be returned saying which keys
# were not found and not deleted, otherwise the user will go to the success page.

	my ($key, %delete_list, $rec_to_delete, @lines, $line, $id, @rest, $errstr, $succstr, $output); 
	$rec_to_delete = 0;
	foreach $key (keys %in) {			   # Build a hash of keys to delete.
		if ($in{$key} eq "delete") {
			$delete_list{$key} = 1;
			$rec_to_delete = 1;
		}
	}
	if (!$rec_to_delete) {
		&html_delete_failure("no records specified.");
	}
	else {
		open (DB, "<$db_file_name") or &cgierr("error in delete_records. unable to open db file: $db_file_name. Reason: $!");
			@lines = <DB>;
		close DB;

		LINE: foreach $line (@lines) {
			if ($line =~ /^$/) { next LINE; }
			if ($line =~ /^#/) { print DB $line; next LINE; }
			chomp ($line);		  
			($id, @rest) = &split_decode($line);
			if ($delete_list{$id}) {			# if this id is one we want to delete
				$delete_list{$id} = 0;		  # then mark it deleted and don't print it to 
			}								   # the new database.
			else { 
				$output .= $line . "\n";			# otherwise print it.
			}
		}
	
		foreach $key (keys %delete_list) {
			if ($delete_list{$key}) {		   # Check to see if any items weren't deleted
				$errstr .= "$key,";			 # that should have been.
			}
			else {  
				$succstr .= "$key,";			# For logging, we'll remember the one's we
			}								   # deleted.
		}
		chop($succstr);	 # Remove trailing delimeter
		chop($errstr);	  # Remove trailing delimeter

		open (DB, ">$db_file_name") or &cgierr("error in delete_records. unable to open db file: $db_file_name. Reason: $!");
			flock(DB, $LOCK_EX) unless (!$db_use_flock);
			print DB $output;
		close DB;	   # automatically removes file lock
		
		if ($errstr) {
			&html_delete_failure($errstr);	  # If so, then let's report an error.
		}
		else {
			&html_delete_success();			 # else, everything went fine.
		}
	}
}   

sub modify_record {
# --------------------------------------------------------
# This routine does the actual modification of a record. It expects
# to find in %in a record that is already in the database, and will
# rewrite the database with the new entry. First it checks to make
# sure that the modified record is ok with validate record.
# It then goes through the database looking for the right record to
# modify, if found, it prints out the modified record, and returns
# the user to a success page. Otherwise the user is returned to an error
# page with a reason why.

	my ($status, $line, @lines, $id, @rest, $output, $found);

	$status = &validate_record;	 # Check to make sure the modifications are ok!

	if ($status eq "ok") {
		open (DB, "<$db_file_name") or &cgierr("error in modify_records. unable to open db file: $db_file_name. Reason: $!");
			@lines = <DB>;  # Slurp the database into @lines..
		close DB;

		$found = 0;	 # Make sure the record is in here!
		LINE: foreach $line (@lines) {
			if ($line =~ /^$/) { next LINE; }				   # Skip and Remove blank lines
			if ($line =~ /^#/) { $output .= $line; next LINE; }   # Comment Line
			chomp ($line);		  
			($id, @rest) = &split_decode($line);
			if ($id eq $in{$db_key}) {				  # If this is the one we are looking for
				$output .= &join_encode(%in);			   # print modified record to database
				$found = 1;							 # and remember that we did it.
			}
			else {
				$output .= $line . "\n";					# else print regular line.
			}
		}
		if ($found) {
			open (DB, ">$db_file_name") or &cgierr("error in modify_records. unable to open db file: $db_file_name. Reason: $!");
				flock(DB, $LOCK_EX) unless (!$db_use_flock);
				print DB $output;
			close DB;		   # automatically removes file lock

			&html_modify_success;
		}
		else {
			&html_modify_failure("$in{$db_key} (can't find requested record)");
		}
	}
	else {
		&html_modify_failure($status);	  # Validation Error
	}
}

sub modify_record_mult {
# --------------------------------------------------------
# Modifies one or more records at a time.
#
	my ($rec_to_modify, %modify_list);
	my ($line, @lines, $id, @rest, $output, $succstr, $errstr);
	
	$rec_to_modify = 0;
	foreach $key (keys %in) {				# Build a hash of keys to modify.
		if ($in{$key} eq "modify") {
			$modify_list{$key} = 1;
			$rec_to_modify = 1;
		}
	}
	if (!$rec_to_modify) {
		&html_modify_form_mult("You must mark at least one record to be modified.");
	}	
	else {
		open (DB, "<$db_file_name") or &cgierr("error in delete_records. unable to open db file: $db_file_name. Reason: $!");
			@lines = <DB>;
		close DB;		
		
		LINE: foreach $line (@lines) {
			if ($line =~ /^$/) { next LINE; }
			if ($line =~ /^#/) { $output .= $line; next LINE; }
			chomp ($line);			
			($id, @rest) = &split_decode($line);
			if ($modify_list{$id}) {  
				foreach $key (keys %in) {				
					if ($key =~ /^\Q$id\E-(.*)$/) {
						$rec{$1} = $in{$key};
					}
				}
				$status = &validate_record (%rec);
				if ($status eq "ok") {
					$output .= &join_encode (%rec);
					$succstr .= "$rec{$db_cols[0]} ";
				}
				else { 
					$output .= $line . "\n"; 
					$errstr .= "Record: $rec{$db_cols[0]} - $status<br>";
				}
				undef %rec;
			}
			else { 
				$output .= $line . "\n";
			}
		}
		open (DB, ">$db_file_name") or &cgierr("error in modify_mult_records. unable to open db file: $db_file_name. Reason: $!");
			flock(DB, $LOCK_EX) unless (!$db_use_flock);
			print DB $output;
		close DB;		# automatically removes file lock
		
		&html_modify_form_mult($errstr, $succstr);
	}
}	

sub view_records {
# --------------------------------------------------------
# This is called when a user is searching the database for 
# viewing. All the work is done in query() and the routines just
# checks to see if the search was successful or not and returns
# the user to the appropriate page.

	my ($status, @hits) = &query();
	if ($status eq "ok") {
		&html_view_success(@hits);
	}
	else {
		&html_view_failure($status);
	}
}

sub validate_records {
# --------------------------------------------------------
# This routine takes a list of records to either delete, validate
# or modify and does the appropriate action.

	my ($rec_to_delete, $rec_to_validate, $rec_to_modify, 
		%delete_list, %validate_list, %modify_list, %links);
	my (@lines, @rest, $id);
	my ($first, $last, $errstr, $output);

# First let's go through %in and see what we have to delete, modify
# and/or validate. We also store all the links in easy to get at hashes.
# We know what fields go with what records as they should all be of the form
# ID-Field_Name. For instance: 12-URL is the URL field for record number 12.

	$rec_to_delete = $rec_to_validate = $rec_to_modify = 0;
	foreach $key (keys %in) { # Build a hash of keys to delete, validate and modify.
		($in{$key} eq "delete") 	and $delete_list{$key} = 1 		and $rec_to_delete = 1;
		($in{$key} eq "validate") 	and $validate_list{$key} = 1 	and $rec_to_validate = 1;
		($in{$key} eq "modify") 	and $modify_list{$key} = 1 		and $rec_to_modify = 1;
		($key =~ /^(\d+)-(.*)$/)	and	$links{$1}{$2} = $in{$key};
	}

# If there isn't anything to do, let's complain.
	if (!$rec_to_validate and !$rec_to_delete and !$rec_to_modify) {
		&html_validate_failure("no records specified."); return;
	}

# Let's go through the validation file and remove all the ones
# we want to validate as well as all the ones we want to delete.
	if ($rec_to_validate or $rec_to_delete) {
		open (VAL, "<$db_valid_name") or &cgierr("error in validate_records. unable to open validate file: $db_valid_name. Reason: $!");
			@lines = <VAL>;
		close VAL;

		LINE: foreach $line (@lines) {
			if ($line =~ /^#/)		{ $output .= $line; next LINE; }
			if ($line =~ /^\s*$/)	{ next LINE; }
			chomp ($line);		  
			($id, @rest) = &split_decode($line);

			if	($delete_list{$id})   { $delete_list{$id} = 0; }
			elsif ($validate_list{$id}) { remove: $validate_list{$id} = 2; print "$id: $validate_list{$id}\n"; }
			else 						{ $output .= "$line\n"; }
		}
		open (VAL, ">$db_valid_name") or &cgierr("error in validate_records. unable to open validate file: $db_valid_name. Reason: $!");
			flock(VAL, $LOCK_EX) unless (!$db_use_flock);	   
			print VAL $output;
		close VAL;	  # automatically removes file lock
		undef $output;
	}

# Now if we have something to delete from the modify list, let's get rid of it.
	if ($rec_to_modify or $rec_to_delete) {
		open (MOD, "<$db_modified_name") or &cgierr("error in validate_records. unable to open modified database: $db_modified_name. Reason: $!");
			@lines = <MOD>;
		close VAL;

		LINE: foreach $line (@lines) {
			if ($line =~ /^#/) { $output .= $line; next LINE; }
			if ($line =~ /^\s*$/) { next LINE; }
			chomp ($line);		  
			($id, @rest) = &split_decode($line);

			if	($delete_list{$id}) { $delete_list{$id} = 0; }
			elsif ($modify_list{$id}) { $modify_list{$id} = 2; } # Do Nothing.
			else 					  { $output .= "$line\n"; }
		}
		open (MOD, ">$db_modified_name") or &cgierr("error in validate_records. unable to open modified database: $db_modified_name. Reason: $!");
			flock(MOD, $LOCK_EX) unless (!$db_use_flock);	   
			print MOD $output;
		close MOD;	  # automatically removes file lock
		undef $output;		
	}

# Now we update any modifications to the database.
	if ($rec_to_modify) {
		open (DB, "<$db_file_name") or &cgierr("error in validate_records. unable to open db file: $db_file_name. Reason: $!");
			@lines = <DB>;  # Slurp the database into @lines..
		close DB;

		$found = 0;	 # Make sure the record is in here!
		LINE: foreach $line (@lines) {
			if ($line =~ /^\s*$/) { next LINE; }
			if ($line =~ /^#/) { $output .= $line; next LINE; }
			chomp ($line);		  
			($id, @rest) = &split_decode($line);
			if ($modify_list{$id} == 2) { # If this is the one we are looking for
				$output .= &join_encode(%{$links{$id}}); 
				$modify_list{$id} = 0;	$found = 1;							
			}
			else {
				$output .= "$line\n";			# else print regular line.
			}
		}
		if ($found) {
			open (DB, ">$db_file_name") or &cgierr("error in validate_records. unable to open db file: $db_file_name. Reason: $!");
				flock(DB, $LOCK_EX) unless (!$db_use_flock);
				print DB $output;
			close DB;		   # automatically removes file lock
		}
		undef $output;
	}
	
# Now let's see if we have something to add to the real database, then
# let's do it.
	if ($rec_to_validate) {  
		open (DB, ">>$db_file_name") or &cgierr("error in validate_records, unable to open db file: $db_file_name. Reason: $!");
		flock(DB, $LOCK_EX) unless (!$db_use_flock);			
		
		foreach $id (keys %validate_list) {
			print "add: $id: $validate_list{$id}\n";
			if ($validate_list{$id} == 2) {
				print DB &join_encode(%{$links{$id}});
				$validate_list{$id} = 0;
			}
			print "add2: $id: $validate_list{$id}\n";
		}
		close DB;
	}

# Now let's check to make sure everything that was asked to be val/del/mod
# actually happend. If not, let's complain.
	foreach $key (keys %validate_list) {
		if   ($validate_list{$key}) { $errstr .= "<li>Validate Error: <strong>$key</strong>. Couldn't find record in validation database.";   }
		else 						{ $valsuc .= "$key,"; }
	}
	foreach $key (keys %delete_list) {
		if ($delete_list{$key})		{ $errstr .= "<li>Delete Error: <strong>$key</strong>. Couldn't find record in validation/modified database."; }
		else						{ $delsuc .= "$key,"; }
	}
	foreach $key (keys %modify_list) {
		if ($modify_list{$key})		{ $errstr .= "<li>Modify Error: <strong>$key</strong>. Couldn't find record in modified/links database."; }
		else 						{ $modsuc .= "$key,"; }
	}
	chop($errstr); chop($valsuc); chop ($delsuc); chop ($modsuc);
	
# Before we display the HTML, let's fire off some validate/modify emails
# lettings visitors know we've added their link. We only send the mail
# if $modify_list{$id} = 0 (if it's still 1, that means there was an error).

# NOTE: You can modify the text of the email in admin_html.pl in the following
# subroutines: html_modify_email and html_validate_email.
	&html_print_headers; # Just in case sendmail coughs up an error.
	
	if ($db_email_modify) {
		ID: foreach $id (keys %modify_list) {
			if ($modify_list{$id}) { next ID; } 
			elsif (${$links{$id}}{'Contact Email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/ ||
				${$links{$id}}{'Contact Email'} !~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/) {
					$errstr .= ($errstr, "<li>Email Error: <strong>$id</strong>. Record validated, but couldn't send auto email. Reason: Bad Email addres: '${$links{$id}}{'Contact Email'}'.");
			}
			else { &html_modify_email (%{$links{$id}}); }
		}
	}
	if ($db_email_add) {
		ID: foreach $id (keys %validate_list) {
			if ($validate_list{$id}) { next ID; }
			elsif (${$links{$id}}{'Contact Email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/ ||
				${$links{$id}}{'Contact Email'} !~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/) {
					$errstr .= ($errstr, "<li>Email Error: <strong>$id</strong>. Record validated, but couldn't send auto email. Reason: Bad Email addres: '${$links{$id}}{'Contact Email'}'.");
			}
			else { &html_validate_email (%{$links{$id}}); }
		}
	}
	
# Now let's go to the error page or the success page depending on
# what $errstr is.
	 $errstr and &html_validate_failure($errstr, $valsuc, $modsuc, $delsuc);	
	!$errstr and &html_validate_success($valsuc, $modsuc, $delsuc);
}   

sub check_links {
# --------------------------------------------------------
# This routine makes sure that there is an entry in the category 
# database for every category in the links database.
#
	my (@lines, $line, @links_list, %category_hash, @missing_categories, @bad_links);
	my ($category_out, $category);
	my (@category_list) = &category_list;

	foreach $category (@category_list) {
		$category_hash{$category} = 1;
	}

	open (DB, "<$db_links_name") or &cgierr("error in check_links. unable to open db file: $db_links_name. Reason: $!");
		@lines = <DB>;  # Slurp the database into @lines..
	close DB;

	LINE: foreach $line (@lines) {
		if ($line =~ /^$/) { next LINE; }	# Skip blank lines
		if ($line =~ /^#/) { next LINE; }   # Comment Line
		
		@values = &split_decode ($line);

# Check to see if this link is in a valid category.		
		if ($category_hash{$values[$db_category]}) {
			next LINE;
		}
		else {
			if (!(grep $_ eq $values[$db_category], @missing_categories)) {
				push (@missing_categories, $values[$db_category]);
			}
			push (@bad_links, @values) unless (($#bad_links+1) / ($#db_cols+1) > $db_max_hits);
		}
	}
	if ($#missing_categories >= 0) {
		foreach $category (@missing_categories) {
			$category_out .= qq|<tr><td><input type=checkbox name="$category" value="add"></td><td>$category</td></tr>|;
		}
		&html_check_links ($category_out, @bad_links);		
	}
	else {
		&html_check_links ("");
	}
}

sub check_duplicates {
# --------------------------------------------------------
# This routine searches through the database and pulls up sets
# of links that have the same domain.
#
	my (@lines, $line, @values, @domains, @doub_domains, %doubles);
#print "Content-type: text/plain\n\n";
	open (DB, "<$db_links_name") or &cgierr("error in check_links. unable to open db file: $db_links_name. Reason: $!");
		@lines = <DB>;  # Slurp the database into @lines..
	close DB;

	LINE: foreach $line (@lines) {
		if ($line =~ /^$/) { next LINE; }	# Skip blank lines
		if ($line =~ /^#/) { next LINE; }   # Comment Line
		
		@values = &split_decode ($line);
		if ($values[$db_url] =~ /^http/) { 	# We only look at web links..
			$values[$db_url] =~ m,^http://([^/]*),;
			if (@{$domains{$1}} && !$db_ignore_doubles{$1}) {	# If this domain already exists..			
				$doubles{$1} = 1;
			}
			push (@{$domains{$1}}, @values);
		}
	}
	foreach $key (keys %doubles) {
		push (@doub_domains, @{$domains{$key}});
	}
	&html_check_duplicates (@doub_domains);
}

sub query {
# --------------------------------------------------------
# This routines does the actual search of the database. It could be
# improved by somehow remembering the options in the reg expression
# so you don't have to go through the options each time. 
# The search is performed in two steps. First we build an array of
# search fields. This array contains the column numbers of fields we 
# want to search. i.e. if we are searching columns 1, 3, and 4, the array
# will hold 1 3 4.
# The next part is to do the actual search. We open the database, and go
# through it line by line. We then go through each field (i.e. 1, 3, 4) and
# see if we have a match, if so we push it on to an array @hits.
# Must use GET forms if you want to use Next ?.

	my ($column, @search_fields, @lines, $line, $field, @hits, @sortedhits, %sortby, 
		$numhits, $maxhits, $match, $key_match, $i, %search);   

	if (@_) { %search = @_; }
	else { %search = %in; }
# Get search fields.
	if ($search{'keyword'}) {	   # If this is a keyword search, we are searching the same
		$i = 0;				 # thing in all fields. Make sure "match any" option is 
		$search{'ma'} = "on";	   # on, otherwise this will almost always fail.
		foreach $column (@db_cols) {
			push (@search_fields, $i);	  # Search every column
			$search{$column} = $search{'keyword'};  # Fill %search with keyword we are looking for.
			$i++;
		}
	}
	else {					  # Otherwise this is a regular search, and we only want records
		$i = 0;				 # that match everything the user specified for.
		foreach $column (@db_cols) {
			if (!($search{$column} =~ /^\s*$/)) { 
				push(@search_fields, $i);   # Make sure we add only non empty fields.
			}
			$i++;
		}
	}
	if ($#search_fields == -1) {
		return ("no search terms specified.");	  # Make sure we are actually looking for
	}											   # something.
	else {
		open (DB, "<$db_file_name") or &cgierr("error in search. unable to open database: $db_file_name. Reason: $!");
			@lines = <DB>;	  # Open the Database and read in all the lines.
		close (DB);

		if ($search{'mh'}) { $maxhits = $search{'mh'}; }	# Define the max number of hits we
		else		   { $maxhits = $db_max_hits; } # will allow.

		$numhits = 0;
		LINE: foreach $line (@lines) {			  # Search through the database
			if ($line =~ /^#/) { next LINE; }	   # Skip comment lines.   
			chomp ($line);					   
			last LINE if ((($#hits+1) / ($#db_cols+1)) >= $maxhits);	# Too many hits! Abort!
			
			@values = &split_decode($line);

			$key_match = 0;						 # key_match is used for match_any option.
			FIELD: foreach $field (@search_fields) {	
				last FIELD if ($key_match && $search{'ma'}); # No Point searching rest of fields if we already have a match!
				if ($search{$db_cols[$field]} eq "*") { $key_match = 1 if ($search{'ma'}); next FIELD; }
				if ($search{'re'}) {			# if regular expression matching
					if ($search{'cs'}) {		# if case sensitive matching
								# Trap Errors in reg exp using eval so program doesn't choke.
						$match = eval { $values[$field] =~ /$search{$db_cols[$field]}/; };
						if ($@) { return ("error in regular expression."); }
						if ($search{'ma'}) { $key_match = ($key_match || $match); }
						else { next LINE unless ($match); }
					}
					else {
								# Trap Errors in reg exp using eval so program doesn't choke.
						$match = eval { $values[$field] =~ /$search{$db_cols[$field]}/i; };
						return ("error in regular expression.") if ($@);
						if ($search{'ma'}) { $key_match = ($key_match || $match); }
						else { next LINE unless ($match); }				 }
				}
				elsif ($search{'ww'}) {		 # if whole word matching
					if ($search{'cs'}) {
						if ($search{'ma'}) { $key_match = ($key_match || ($values[$field] =~ /\b\Q$search{$db_cols[$field]}\E\b/)); }
						else { next LINE unless ($values[$field] =~ /\b\Q$search{$db_cols[$field]}\E\b/); }
					}
					else {
						if ($search{'ma'}) { $key_match = ($key_match || ($values[$field] =~ /\b\Q$search{$db_cols[$field]}\E\b/i)); }
						else { next LINE unless ($values[$field] =~ /\b\Q$search{$db_cols[$field]}\E\b/i); }
					}
				}
				else {
					if ($search{'cs'}) {
						if ($search{'ma'}) { $key_match = ($key_match || ($values[$field] =~ /\Q$search{$db_cols[$field]}\E/)); }
						else { next LINE unless ($values[$field] =~ /\Q$search{$db_cols[$field]}\E/); }
					}
					else {
						if ($search{'ma'}) { $key_match = ($key_match || ($values[$field] =~ /\Q$search{$db_cols[$field]}\E/i)); }
						else {  next LINE unless ($values[$field] =~ /\Q$search{$db_cols[$field]}\E/i); }
					}
				}
			} # END FIELD
			if ($key_match || (!($search{'keyword'}) && !($search{'ma'}))) {			
				$numhits++;	 # Increment the number of hits we've found..				
				if ($numhits > (($search{'nh'}) * $maxhits)) {  # Add it only if this is within the current range.
					$sortby{(($#hits+1) / ($#db_cols+1))} = $values[$search{'sb'}] if ($search{'sb'});
					push (@hits, @values);				  
				}
			}
		} # END LINE		
				
		if ($#hits == -1) {
			return ("no matching records.");
		}
		else {		  
			$db_search_next_url = $ENV{'QUERY_STRING'}; # Let's set a global to use to find next n hits..
			if ($search{'nh'}) { 
				my ($next) = $search{'nh'} + 1;
				$db_search_next_url =~ s/&nh=(\d+)/&nh=$next/; 
			}
			else		   { $db_search_next_url .= "&nh=1"; }
			$db_search_next_url = $db_script_url . "?" . $db_search_next_url;

			if ($search{'sb'}) {	# Sort hits on $search{'sb'} field.	 
				if ($search{'so'} eq "descend") {   # Sort in decending order..
					foreach $hit (sort { lc($sortby{$b}) cmp lc($sortby{$a}) } (keys %sortby)) {
						$first = ($hit * $#db_cols) + $hit;
						$last = ($hit * $#db_cols) + $#db_cols + $hit;		  
						push (@sortedhits, @hits[$first .. $last]);
					}
				}
				else {  # Sort in ascending order..
					foreach $hit (sort { lc($sortby{$a}) cmp lc($sortby{$b}) } (keys %sortby)) {
						$first = ($hit * $#db_cols) + $hit;
						$last = ($hit * $#db_cols) + $#db_cols + $hit;		  
						push (@sortedhits, @hits[$first .. $last]);
					}
				}
				return ("ok", @sortedhits);
			}

			else {
				return ("ok", @hits);
			}
		}
	}
}   


sub get_record {
# --------------------------------------------------------
# Given an ID as input, get_record returns a hash of the 
# requested record or undefined if not found.

	my ($key, $found, @lines, $line, $id, @rest, %rec);
	$key = $_[0];   
	$found = 0;
	
	open (DB, "<$db_file_name") or &cgierr("error in get_records. unable to open db file: $db_file_name. Reason: $!");
		@lines = <DB>;
	close DB;

	LINE: foreach $line (@lines) {
		if ($line =~ /^#/) { next LINE; }
		chomp ($line);	  
		($id, @rest) = &split_decode($line);
		if ($id eq $key) {
			$found = 1;
			unshift (@rest, $id);
			$counter = 0;
			foreach $field (@db_cols) {
				$rec{$field} = $rest[$counter];
				$counter++;
			}
			last LINE;
		}
	}
	if ($found) {
		return %rec;
	}
	else {
		return undef;
	}
}

sub get_defaults {
# --------------------------------------------------------
# Returns a hash of the defaults used for a new record.

	my (%default);

	foreach $field (keys %db_defaults) {
		$default{$field} =  $db_defaults{$field};
	}
	
	open (ID, "<$db_id_file_name") or &cgierr("error in get_defaults. unable to open id file: $db_id_file_name. Reason: $!");
	$default{$db_key} = <ID> + 1;			   # Get next ID number
	close ID;
	
	$default{'Date'} = &get_date;		   # Get Todays Date

	return %default;
}


sub validate_record {
# --------------------------------------------------------
# Verifies that the information passed through the form and stored
# in %in matches a valid record. It checks first to see that if 
# we are adding, that a duplicate ID key does not exist. It then
# checks to see that fields specified as not null are indeed not null,
# finally it checks against the reg expression given in the database
# definition.

	my ($col, @input_err, $errstr, $err, $line, @lines, $id, @rest);	
	my (%record) = @_;
	@_ or (%record = %in);

	if ($record{'add_record'})  {	   # don't need to worry about duplicate key if modifying  
		open (DB, "<$db_file_name") or &cgierr("error in validate_records. unable to open db file: $db_file_name. Reason: $!");
			@lines = <DB>;
		close DB;
		LINE: foreach $line (@lines) {
			if ($line =~ /^#/) { next LINE; }		   
			chomp ($line);
			($id, @rest) = &split_decode($line);	
			if ($id eq $record{$db_key}) {
				return "duplicate key error";
			}
		}
	}
# We do an extra check for dates, as they can really mess things up if they are inputed wrong.
# The field must be named "Date".
	if ($record{'Date'}) {
		eval {	&date_to_unix($record{'Date'}); };
		if ($@) { push (@input_err, "Bad Date Format: $@"); }
	}	
	foreach $col (@db_cols) {
		if ($record{$col} =~ /^\s*$/) {			 # entry is null or only whitespace
			if ($db_not_null{$col}) {		   # entry is not allowed to be null.
				push(@input_err, "$col (Missing)"); # so let's add it as an error
			}		   
		}
		else {								  # else entry is not null.
			if (defined($db_valid_types{$col}) && !($record{$col} =~ /$db_valid_types{$col}/)) {
				push(@input_err, "$col (Invalid)"); # but has failed validation so add
			}								   # it as an error.
		}
	}
	if ($#input_err+1 > 0) {					# since there are errors, let's build
		foreach $err (@input_err) {			 # a string listing the errors
			$errstr .= "$err,";				 # and return it.
		}
		chop $errstr;
		return $errstr;
	}
	else {
		return "ok";							# no errors, return ok.
	}
}

sub join_encode {
# --------------------------------------------------------
# Takes a hash (ususally from the form input) and builds one 
# line to output into the database. It changes all occurrences
# of the database delimeter to '~~' and all newline chars to '``'.

	my (%hash) = @_;
	if (!%hash) { %hash = %in; }
	my ($tmp, $col, $output);   

	foreach $col (@db_cols) {			   
		$tmp = $hash{$col};
		$tmp =~ s/^\s+//g;	  # Trim leading blanks...
		$tmp =~ s/\s+$//g;	  # Trim trailing blanks...
		$tmp =~ s/\Q$db_delim\E/~~/g;   # Change delimeter to ~~ symbol.
		$tmp =~ s/\n/``/g;			  # Change newline to `` symbol.
		$tmp =~ s/\r//g;				# Remove linefeed character.
		if ($tmp =~ /^\s*$/g) {
			$tmp = $db_null;			# Set to null char if empty field.
		}
		$output .= $tmp . $db_delim;	# Build Output.
	}
	chop $output;	   # remove extra delimeter.
	$output .= "\n";	# add linefeed char.
	return $output;
}

sub split_decode {
# --------------------------------------------------------
# Takes one line of the database as input and returns an
# array of all the values. It replaces special mark up that 
# join_encode makes such as replacing the '``' symbol with a 
# newline and the '~~' symbol with a database delimeter.

	my ($input) = $_[0];
	my (@array) = split (/\Q$db_delim\E/, $input);
	for ($i = 0; $i <= $#array; $i++) {
		$array[$i] =~ s/~~/$db_delim/g;	 # Retrieve Delimiter..
		$array[$i] =~ s/``/\n/g;			# Change '' back to newlines..
		if ($array[$i] eq $db_null) {
			$array[$i] = '';				# Make empty array if NULL..
		}
	}   
	return @array;
}

sub build_select_field {
# --------------------------------------------------------
# Builds a SELECT field based on information found
# in the database definition. Parameters are the column to build,
# a default value, a default name, whether to allow multiple selections,
# and the size of the box.

	my ($column, $value, $name, $mult, $size) = @_;
	my (@fields, @values, $ouptut);
	
	$name || ($name = $column);
	$size || ($size = 1);
	
	if ($mult) { @values = split (/\Q$db_delim\E/,$value); }
	else	   { @values = ($value); }

	@fields = split (/\,/, $db_select_fields{$column});
	if (! exists ($db_select_fields{$column})) {
		$output = "error building select field: no fields specified/unkown field ($column)!";
	}
	else {
		$output = qq|<SELECT NAME="$name" $mult SIZE=$size><OPTION>---|;
		foreach $field (sort @fields) {
			if (grep $_ eq $field, @values) {
				$output .= "<OPTION SELECTED>$field\n";
			}
			else {
				$output .= "<OPTION>$field";
			}
		}
		$output .= "</SELECT>";
	}

	return $output;
}

sub build_select_field_from_db {
# --------------------------------------------------------
# Builds a SELECT field from the database. 

	my ($column, $value, $name) = @_;
	my (@fields, $field, @selectfields, @lines, $line, $ouptut);
	my ($fieldnum, $found, $i) = 0;
	
	$name || ($name = $column);
	
	for ($i = 0; $i <= $#db_cols; $i++) {
		if ($column eq $db_cols[$i]) {
			$fieldnum = $i; $found = 1;
			last;
		}
	}
	if (!$found) {
		return "error building select field: no fields specified!";
	}

	open (DB, "<$db_file_name") or &cgierr("unable to open $db_file_name. Reason: $!");
		@lines = <DB>;
	close DB;

	LINE: foreach $line (@lines) {
		if ($line =~ /^#/) { next LINE; }	   # Skip comment lines.   
		chomp ($line);					   
		
		@fields = &split_decode ($line);
		if (!(grep $_ eq $fields[$fieldnum], @selectfields)) {
			push (@selectfields, $fields[$fieldnum]);
		}
	}
	$output = qq|<SELECT NAME="$name"><OPTION>---|;
	foreach $field (sort @selectfields) {
		if ($field eq $value) {
			$output .= "<OPTION SELECTED>$field";
		}
		else {
			$output .= "<OPTION>$field";
		}
	}
	$output .= "</SELECT>";

	return $output;
}

sub build_checkbox_field {
# --------------------------------------------------------
# Builds a CHECKBOX field based on information found
# in the database definition. Parameters are the column to build and
# whether it should be checked or not.

	my ($column, $on, $name) = @_;
	my ($output);
	
	$name || ($name = $column);
	if ($on eq $db_checkbox_fields{$column}) {
		$output = qq|<INPUT TYPE="CHECKBOX" NAME="$name" VALUE="$db_checkbox_fields{$column}" CHECKED>|;
	}
	else {
		$output = qq|<INPUT TYPE="CHECKBOX" NAME="$name" VALUE="$db_checkbox_fields{$column}">|;
	}
	
	return $output;
}

sub build_radio_field {
# --------------------------------------------------------
# Builds a RADIO Button field based on information found
# in the database definition. Parameters are the column to build
# and a default value (optional).

	my ($column, $value, $name) = @_;
	my (@buttons, $button, $output);

	@buttons = split (/,/, $db_radio_fields{$column});
	$name || ($name = $column);
	
	if ($#buttons == -1) {
		$output = "error building radio buttons: no fields specified!";
	}
	else {
		foreach $button (@buttons) {
			if ($value =~ /^\Q$button\E$/) {
				$output .= qq|<INPUT TYPE="RADIO" NAME="$name" VALUE="$button" CHECKED> $button \n|;
			}
			else {
				$output .= qq|<INPUT TYPE="RADIO" NAME="$name" VALUE="$button"> $button \n|;
			}
		}
	}
	
	return $output;
}

sub get_category_list {
# --------------------------------------------------------
# Returns the form field neccessary for modifying the category list.

	my ($name, $value) = @_;
	my ($output) = "";
	my (@full_cat) = &category_list;	   # Get's the list of every category.

# Now let's load the category descriptions and related categories.
	open (CAT, "<$db_category_name") or &cgierr ("unable to open category description file: $db_category_name. Reason: $!");
	LINE: while (<CAT>) {
		next LINE if (/^#/);
		next LINE if (/^\s*$/);
		chomp;
		($cat, $des, @rel) = split (/\Q$db_delim\E/);
		$descriptions{$cat} = $des;
		@{$related{$cat}} = @rel;
	}
	close CAT;

	$output = "<table border=0>";
	$output .= "<tr><td><strong>Category Name</strong><td><strong>Description<strong></td><td><strong>Related Categories</strong></td></tr>";

# First let's build a select list for the related categories:	
foreach $cat (@full_cat) {
		$select_list = qq|<select name="Rel$cat" multiple size=3>|;
		foreach $cat2 (@full_cat) {
			if (grep $cat2 eq $_, @{$related{$cat}}) {
				$select_list .= "<option selected>$cat2";
			}
			else {
				$select_list .= "<option>$cat2";
			}
		}
		$select_list .= "</select>";		

# Now let's build the rest of the form.		
		$output .= qq|
<tr><td>$cat</td>
	<td><input name="Des$cat" value="$descriptions{$cat}"></td>
	<td>$select_list</td>
</tr>
|;
	}
	$output .= "</table>";
	return $output;	
}	

sub category_list {
# --------------------------------------------------------
# Returns a list of all categories in the database.
	my (@list, @fields);

	open (DB, "<$db_category_name") or &cgierr("unable to open $db_file_name. Reason: $!");
		@lines = <DB>;
	close DB;

	LINE: foreach $line (@lines) {
		if ($line =~ /^#/) { next LINE; }	   # Skip comment lines.   
		chomp ($line);					   
		
		@fields = &split_decode ($line);
		if (!(grep $_ eq $fields[$db_main_category], @list)) {
			push (@list, $fields[$db_main_category]);
		}
	}
	
	@list = sort @list;

	return @list;
}

sub array_to_hash {
# --------------------------------------------------------
# Converts an array to a hash using db_cols as the field names.

	my($hit, @array) = @_;
	my(%hash);
	
	for ($j = 0; $j <= $#db_cols; $j++) {
		$hash{$db_cols[$j]} = $array[$hit * ($#db_cols+1) + $j];
	}   
	return %hash;
}

sub parse_form {
# --------------------------------------------------------
# Parses the form input and returns a hash with all the name
# value pairs. Removes SSI and any field with "---" as a value 
# (as this denotes an empty SELECT field.

	my (@pairs, %in);
	my ($buffer, $pair, $name, $value); 

	if ($ENV{'REQUEST_METHOD'} eq 'GET') {
		@pairs = split(/&/, $ENV{'QUERY_STRING'});
	}
	elsif ($ENV{'REQUEST_METHOD'} eq 'POST') {
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
		@pairs = split(/&/, $buffer);
	}
	else {
		&cgierr('error in parse_form. reason: unkown request_method.');
	}
	PAIR: foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		if (length($value) > $db_max_field_length) {
			&cgierr('value field too large!');
		}
		if (length($name) > $db_max_field_length) {
			&cgierr('name field too large!');
		}	   
		 
		$name =~ tr/+/ /;
		$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		$value =~ s/<!--(.|\n)*-->//g;
		if ($value eq "---") { next PAIR; } 
		if (($name =~ /^New_(.*)/) && !($value =~ /^\s*$/)) { $name = $1; }
		if (exists($in{$name})) { $in{$name} .= "$db_delim$value"; }
		else { $in{$name} = $value; }
	}
	return %in;
}

sub get_date {
# --------------------------------------------------------
# Returns the current date.

	return &unix_to_date (time());
}

sub get_time {
# --------------------------------------------------------
# Returns the time in the format "hh-mm-ss".
	
	my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime (time);
	
	if ($hour < 10) { $hour = "0" . $hour; }
	if ($min < 10) {  $min  = "0" . $min; }
	if ($sec < 10) {  $sec =  "0" . $sec; }
	
	return "$hour:$min:$sec";
}

sub compare_dates {
# --------------------------------------------------------
# Returns 1 if date a is greater then date b, otherwise returns 0.
	my ($time1) = &date_to_unix ($_[0]);
	my ($time2) = &date_to_unix ($_[1]);
	
	return $time1 > $time2;
}

sub days_old {
# --------------------------------------------------------
# Returns the number of days from a given day to today (number of days 
# old.
	
	my ($time1) = &date_to_unix ($_[0]);
	my ($time2) = time();
	
	my ($difference) = $time2 - $time1;
	
	if ($difference >= 0) {
		return int($difference / 86400);
	}
	else {
		return -1;
	}
}

sub build_clean {
# --------------------------------------------------------
	my ($input) = $_[0];
	$input =~ s/_/ /g;
	$input =~ s,/, : ,g;
	return $input;
}

sub build_sorthit {
# --------------------------------------------------------
# This function sorts a list of links. It has been modified to sort
# new links first, then cool links, then the rest alphabetically. By modifying
# the sort function below, you can sort the links however you like (by date,
# or random, etc.).
#
	 my (@unsorted) = @_;
	 my ($num) = ($#unsorted+1) / ($#db_cols+1);
	 my (%sortby, %isnew, %iscool, $hit, $i, @sorted);

	 for ($i = 0; $i < $num; $i++) {
		 $sortby{$i} = $unsorted[$db_sort_links + ($i * ($#db_cols+1))];
		 if ($unsorted[$db_isnew + ($i * ($#db_cols+1))] eq "Yes")  { $isnew{$i}  = 1; }
		 if ($unsorted[$db_ispop + ($i * ($#db_cols+1))] eq "Yes")  { $iscool{$i} = 1; }
	 }
	 foreach $hit (sort { 
							 if ($isnew{$b}  and !$isnew{$a})  { return 1; }
							 if ($isnew{$a}  and !$isnew{$b})  { return -1; }
							 if ($iscool{$b} and !$iscool{$a}) { return 1; }
  						  	 if ($iscool{$a} and !$iscool{$b}) { return -1; }  
							 if ($isnew{$a}  and  $isnew{$b})  { return lc($sortby{$a}) cmp lc($sortby{$b}); }							 
							 if ($iscool{$a} and  $iscool{$b}) { return lc($sortby{$a}) cmp lc($sortby{$b}); }							 							 
  						   	 return lc($sortby{$a}) cmp lc($sortby{$b});
  		 				} (keys %sortby)) {
		 $first = ($hit * $#db_cols) + $hit;
		 $last = ($hit * $#db_cols) + $#db_cols + $hit;		  
		 push (@sorted, @unsorted[$first .. $last]);
	 }   
	 return @sorted;
 }


	
sub urlencode {
# --------------------------------------------------------
	my($toencode) = @_;
	$toencode=~s/([^a-zA-Z0-9_\-.])/uc sprintf("%%%02x",ord($1))/eg;
	$toencode=~s/\%2F/\//g;
	return $toencode;
}

sub html_print_headers {
# --------------------------------------------------------
# Print out the headers if they haven't already been printed.

	if (!$html_headers_printed) {   
		print "HTTP/1.0 200 OK\n"				if ($db_iis or $nph);
		print "Pragma: no-cache\n"				if ($db_nocache);
		print "Content-type: text/html\n\n";
		$html_headers_printed = 1;
	}
}

sub cgierr {
# --------------------------------------------------------
# Displays any errors and prints out FORM and ENVIRONMENT 
# information. Useful for debugging.

	&html_print_headers;
	
	print "<PRE>\nCGI Error: $!\n";
	print "Message: $_[0]\n\n";
	print "_________Form Variables __________\n";
	foreach $key (sort keys %in) {
		print "$key: \t$in{$key}\n";
	}

	print "\n_________Environment Variables__________\n";
	foreach $env (sort keys %ENV) {
		print "$env: \t$ENV{$env}\n";
	}
	print "\n</PRE>";
	exit;
}

1;