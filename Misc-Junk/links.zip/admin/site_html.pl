#!/usr/bin/perl
#
#               -------------
#				   Links
#               -------------
#               Links Manager
#
#         File: site_html.pl
#  Description: This library contains all the HTML that will be generated in
#               the finished directory.
#       Author: Alex Krohn
#        Email: alex@gossamer-threads.com
#          Web: http://www.gossamer-threads.com/
#      Version: 1.11
#
# COPYRIGHT NOTICE:
#
# Copyright 1997 Gossamer Threads Inc.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program 
# you agree to indemnify Gossamer Threads Inc. from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.
# =====================================================================

##########################################################
##					  Globals					     ##
##########################################################
# You can put variables here that you would like to use throughout
# the site.

$date = &get_date;
$time = &get_time;

$font_new       = 'font face="arial, helvetica" size=2 color="#CC0000"';
$font_pop       = 'font face="arial, helvetica" size=2 color="#000000"';
$font_date      = 'font face="arial, helvetica" size=1 color="#000000"';
$font_title     = 'font face="arial, helvetica" size=4 color="#000000"';
$font_subtitle  = 'font face="arial, helvetica" size=3 color="#000000"';
$font_menu      = 'font face="verdana, arial" size=1 color="#000000"';
$font_link      = 'font face="arial, helvetica" size=2 color="#000000"';
$font_category  = 'font face="arial, helvetica" size=2 color="#000000"';
$font           = 'font face="arial, helvetica" size=2 color="#000000"';

$site_hr = 'hr noshade color="#008080"';

$site_body = 'body bgcolor="#FFFFFF" text="#000000" link="#024AC9"';

$site_title = "Webmaster's Reference";

$site_menu = qq~
<$font_menu>|
    <A HREF="$build_root_url">Home</A> |
    <A HREF="$build_add_url">Add a Resource</A> |
	<A HREF="$build_modify_url">Modify a Resource</A> |
    <A HREF="$build_new_url">What's New</A> |
    <A HREF="$build_cool_url">What's Cool</A> |
    <A HREF="$build_jump_url?$db_key=random">Random Link</A> |
    <A HREF="$build_search_url">Search</A> |
</font>
~;

# I'd really appreciate a link back, but you are not obligated to.
$site_footer = qq~
	<form action="$build_search_url" method="GET">
		<center>
			<hr size=1 width=600>	
			<$font>
			Looking for something in particular? 
			<p><input type=text size=15 name="query"> <input type=submit value="Search!"><br>
			<a href="$build_search_url">More Options</a>
			</font>
			<hr size=1 width=600>
		</center>			
	</form>
	<table border=0 width="100%">
		<tr><td align=left><a href="http://www.gossamer-threads.com"><img src="http://www.gossamer-threads.com/images/powered.gif" width=100 height=31 alt="Gossamer Threads Inc." border=0 align=left></a></td>
			<td  align=right><$font>Pages Updated On: $date</font><br>
							<$font>Links Engine 1.1 By: <a href="http://www.gossamer-threads.com/">Gossamer Threads Inc.</a></font></td>			
		</tr>
	</table>			
~;


##########################################################
##					  A Link					      ##
##########################################################

sub site_html_link {
# --------------------------------------------------------
# This routine is used to display what a link should look
# like. It's a little complex looking just because we have to 
# check for blank entries..

my (%rec) = @_;

$output = qq|
	<ul type=disc><li><$font><a href="$build_jump_url?$db_key=$rec{$db_key}">$rec{'Title'}</a></font>|;

if ($rec{'Description'})        { $output .= qq| <$font>- $rec{'Description'}</font>\n|; }
if ($rec{'isNew'} eq "Yes")     { $output .= qq| <$font_new><i><b>new</b></i></font>|; }
if ($rec{'isPopular'} eq "Yes") { $output .= qq| <$font_pop><i><b>pop</b></i></font>|; }

$output .= qq| <$font_date><em>(Added: $rec{'Date'} Hits: $rec{'Hits'})</em></font><br>
	</ul>
|;

return $output;
}

##########################################################
##					  Home Page					   ##
##########################################################

sub site_html_home {
# --------------------------------------------------------
# This routine will build a home page. It is not meant to have any 
# links on it, only subcategories.
#
#   $category       : The list of subcategories.
#   $time           : The current time.
#   $date           : The current date.
#   $grand_total    : The total number of links.
#

my ($output);

$output = qq~ 
<html>

<head>
<title>$site_title</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P><hr size=1 width=600>
		<$font_title>$site_title</font><BR>
		<$font><em>actually it's just an old bookmark file I found ;)</em></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<P><$font_subtitle><strong><center>Categories:</center></strong></font>
					<$font_category><strong>$category</strong></font>
					<P align=center><$font>There are <strong>$grand_total</strong> links for you to choose from!</font></p>
            	</td></tr>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;

return $output;
}

##########################################################
##					  What's New Page				 ##
##########################################################

sub site_html_new {
# --------------------------------------------------------
# This routine will build a what's new page. You can use the following
# variables
#
#   $time           : The current time.
#   $date           : The current date.
#   $total          : The total number of new links.
#   $grand_total    : The total number of links.
#   $link_results   : The list of new links.
#	$title_linked
#

$output = qq~ 
<html>

<head>
<title>$site_title: What's New</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P><hr size=1 width=600>
		<$font_subtitle><strong>$site_title: What's New</strong></font><BR>
		<$font><strong>$title_linked</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<$font_subtitle><strong><center>$total New Links:</center></strong></font><br>
					<$font_category>$link_results</font></td></tr>				
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;

return $output;
}

##########################################################
##					  What's Cool Page				##
##########################################################

sub site_html_cool {
# --------------------------------------------------------
# This routine will build a what's new page. You can use the following
# variables
#
#   $time           : The current time.
#   $date           : The current date.
#   $total          : The total number of new links.
#   $grand_total    : The total number of links.
#   $percent        : The cool percent cutoff (top 3%, etc).
#   $link_results   : The list of cool links.
#

# Your Title and Header.
$output = qq~ 
<html>

<head>
<title>$site_title: What's Cool</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P><hr size=1 width=600>
		<$font_subtitle><strong>$site_title: What's Cool - The Top $percent%!</strong></font><BR>
		<$font><strong>$title_linked</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<$font_subtitle><strong><center>$total Cool Links:</center></strong></font><br>
					<$font_category>$link_results</font>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;

return $output;
}

##########################################################
##					  Category Pages				  ##
##########################################################

sub site_html_category {
# --------------------------------------------------------
# This rountine will build a page based for the current category.
# Insert the following variables in the appropriate place.
#
#   $category       : The list of subcategories.
#   $links          : The list of links in this category.
#   $time           : The current time.
#   $date           : The current date.
#   $title_linked   : A linked version of the title bar.
#   $title          : An unlinked version of the title bar.
#   $total          : The total number of links in this category.
#   $grand_total    : The total number of links.
#   $category_name  : The category name.
#   $category_name_escaped  : The category name URL escaped (used for the Add function)
#   $category_clean : The category name with _ and / removed.
#
# The following will work assuming you haven't changed the order of the
# category database. If you have, or have added new fields, you can access
# any of the information by using $category{$category_name}[field_num] where 
# field number is the number (indexed from 0) of the field you want. Otherwise
# you can just use the following:
#
#   $description	: Category Description
#	$meta_name		: Meta Description Tag
#	$meta_keywords	: Meta Keywords Tag
#	$header			: Custom Header
#	$footer			: Custom Footer
#	$related		: A <li> list of related categories.
#

my ($output);

$output = qq~
<html>

<head>
<title>$site_title: $category_clean</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: $category_clean</strong></font><BR>
		<$font><strong>$title_linked</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">
				<tr><td>
~; if ($header) { $output .= qq~<p><$font size=5>$header</font></p>
~; }
if ($category) { $output .= qq~
					<$font_subtitle><strong>Categories:</strong></font>
					<p><$font_category>$category</font>
~; } 
if ($links) {$output .= qq~          
					<$font_subtitle><strong>Links:</strong></font><br>
					<$font_category>$links</font>
~; }
if ($related) {
$output .= qq~
					<p><$font_subtitle><strong>Related Categories:</strong></font>
					<ul><$font_category>$related</font></ul>
~; }

if ($prev or $next) { $output .= qq~<p align=center>~; }
if ($prev)   { $output .= qq~<$font><strong><a href="$prev">Prev $build_links_per_page</a></strong></font> ~; }
if ($next)   { $output .= qq~<$font><strong><a href="$next">Next $build_links_per_page</a></strong></font> ~; }
if ($prev or $next) { $output .= qq~</p>~; }

if ($footer) { $output .= qq~<p>$footer</p>~; }

$output .= qq~
			</td></tr></table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;

return $output;
}

##########################################################
##					  Category Listings               ##
##########################################################

sub site_html_print_cat {
# --------------------------------------------------------
# This routine determines how the list of categories will look.
# We now use a table to split the category name up into two columns.
# For each category you can use the following variables:
#
#   $url        : The URL to go to that category
#   $category_name : The category name with _ and / removed.
#	$category_descriptions{$subcat}: The category description (if any).
#   $numlinks   : The number of links inside that category (and subcategories).
#   $mod        : The newest link inside of that category.
#

    my (@subcat) = @_; 
    my ($url, $numlinks, $mod, $subcat, $category_name, $description, $output, $i);
    my ($half) = int (($#subcat+2) / 2);
	
    # Print Header.
	$output = qq|<CENTER><TABLE BORDER=0 WIDTH="100%"><TR><TD VALIGN=TOP WIDTH="50%">\n|;
    
    foreach $subcat (sort @subcat) { 
		($description) = @{$category{$subcat}}[2];
		
# First let's get the name, number of links, and last modified date...	
        $url = "$build_root_url/" . &urlencode($subcat) . "/";
        if ($subcat =~ m,.*/([^/]+)$,) { $category_name = &build_clean($1); } else { $category_name = &build_clean($subcat); }
        $numlinks = $stats{"$subcat"}[0]; 
        $mod = $stats{"$subcat"}[1];

# We check to see if we are half way through, if so we stop this table cell
# and begin a new one (this lets us have category names in two columns).		
		if ($i == $half) {
			$output .= qq|</UL></TD><TD VALIGN=TOP WIDTH="50%">\n|;
		}
		$i++;
		
        
# Then we print out the name linked, new if it's new, and popular if its popular.
        $output .= qq|<dl><dt><$font><strong><A HREF="$url">$category_name</A></strong> ($numlinks) </font>|;
		$output .= qq|<$font_new><strong>new</strong></font>| if (&days_old($mod) < $db_new_cutoff);
		$output .= qq|</dt>|;
		$output .= qq|<dd><$font>$description </font></dd>| if (!($description =~ /^[\s\n]*$/));
		$output .= qq|</dl>|;
        
    }
    
# Don't forget to end the unordered list..
    $output .= "</TD></TR></TABLE></CENTER>\n";
    return $output;
}

##########################################################
##					  Add Resources				   ##
##########################################################

sub site_html_add_form {
# --------------------------------------------------------
# This routine determines how the add form page will look like. 
#
    &html_print_headers;
    
    print qq~   
<html>

<head>
<title>$site_title: Add a Resource</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Add a Resource</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<FORM ACTION="$build_add_url" METHOD="POST">
					<p><$font>Please fill out the form completely, and we'll add your resource as soon as possible.</font>
						<table border = 0 bgcolor="#FFFFDF">
							<tr><td align=right valign=top><$font>Title:</font></td>
								<td><INPUT NAME="Title" VALUE="$in{'Title'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>URL:</font></td>
								<td><INPUT NAME="URL" VALUE="$in{'URL'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>Category:</font></td>
								<td>~; $db_select_fields{'Category'} = join (",", &category_list); print &build_select_field ("Category", "$in{'Category'}"); print qq~</td></tr>
							<tr><td align=right valign=top><$font>Description:</font></td>
								<td><TEXTAREA NAME="Description" VALUE="$in{'Description'}" ROWS=3 COLS=42>$in{'Description'}</TEXTAREA></td></tr>
							<tr><td align=right valign=top><$font>Contact Name:</font></td>
								<td><INPUT NAME="Contact Name" VALUE="$in{'Contact Name'}" SIZE=40></td></tr>					           
							<tr><td align=right valign=top><$font>Contact Email:</font></td>
								<td><INPUT NAME="Contact Email" VALUE="$in{'Contact Email'}" SIZE=40></td></tr>					           
							<tr><td colspan=2><Center><INPUT TYPE="SUBMIT" VALUE="Add Resource"></Center></td></tr>
						</table>
					</form>
				</td></tr>
           	</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;
}

sub site_html_add_success {
# --------------------------------------------------------
# This routine determines how the add failure page will look like. You have
# access to the following variables:
#
#   %in     : the variables used to add the link, useful in confirming what was
#             added.
#

    &html_print_headers;
    print qq~
<html>

<head>
<title>$site_title: Resource Added</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Resource Added</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<$font>We have received the following link:</font>
<PRE><strong>          Title:  $in{'Title'}
            URL:  $in{'URL'}
    Description:  $in{'Description'}
   Contact Name:  $in{'Contact Name'}
  Contact Email:  $in{'Contact Email'}
       Category:  $in{'Category'}
</strong></PRE>
					<P><$font>Thank you! We will send you an email once your link has been validated.</font>
				</tr></td>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;
}

sub site_html_add_failure {
# --------------------------------------------------------
# This routine determines how the add failure page will look like. You have
# access to the following variables:
#
#   $errormsg       : A bulleted list of the problems.
#   %in             : variables used in adding the form. Useful for recreating
#					 the form
#

    my ($errormsg) = $_[0];

    &html_print_headers;
    print qq~
<html>

<head>
<title>$site_title: Error Adding Resource.</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Error Adding Resource</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td colspan=2>
					<FORM ACTION="$build_add_url" METHOD="POST">					    
						<$font>There were the following errors trying to add your resource:
						<font color="red">
							$errormsg
						</font>
						<P>Please make any changes and try again!</font>
						<table border=0 bgcolor="#FFFFDF">
							<tr><td align=right valign=top><$font>Title:</font></td>
								<td><INPUT NAME="Title" VALUE="$in{'Title'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>URL:</font></td>
								<td><INPUT NAME="URL" VALUE="$in{'URL'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>Category:</font></td>
								<td>~; $db_select_fields{'Category'} = join (",", &category_list); print &build_select_field ("Category", "$in{'Category'}"); print qq~</td></tr>
							<tr><td align=right valign=top><$font>Description:</font></td>
								<td><TEXTAREA NAME="Description" VALUE="$in{'Description'}" ROWS=3 COLS=42>$in{'Description'}</TEXTAREA></td></tr>
							<tr><td align=right valign=top><$font>Contact Name:</font></td>
								<td><INPUT NAME="Contact Name" VALUE="$in{'Contact Name'}" SIZE=40></td></tr>					           
							<tr><td align=right valign=top><$font>Contact Email:</font></td>
								<td><INPUT NAME="Contact Email" VALUE="$in{'Contact Email'}" SIZE=40></td></tr>					           
							<tr><td colspan=2><Center><INPUT TYPE="SUBMIT" VALUE="Add Resource"></Center></td></tr>
						</table>
					</form>
				</td></tr>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;

}

##########################################################
##					  Modify Resources				   ##
##########################################################

sub site_html_modify_form {
# --------------------------------------------------------
# This routine determines how the modify form page will look like. 
# You should include a text field for the URL to be modified as well
# as a new form for the new link information.
#
    &html_print_headers;
    
    print qq~   
<html>

<head>
<title>$site_title: Modify a Resource</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Modify a Resource</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<FORM ACTION="$build_modify_url" METHOD="POST">
						<p><$font>Please enter the URL of the link you wish to update. Make sure it is identical to the one already in the database:</font>
						<input name="Current URL" size=30>
						<p><$font>Now enter the new information (all of it, not just the changes) below:
						<table border=0 bgcolor="#FFFFDF">
							<tr><td align=right valign=top><$font>Title:</font></td>
								<td><INPUT NAME="Title" VALUE="$in{'Title'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>URL:</font></td>
								<td><INPUT NAME="URL" VALUE="$in{'URL'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>Category:</font></td>
								<td>~; $db_select_fields{'Category'} = join (",", &category_list); print &build_select_field ("Category", "$in{'Category'}"); print qq~</td></tr>
							<tr><td align=right valign=top><$font>Description:</font></td>
								<td><TEXTAREA NAME="Description" VALUE="$in{'Description'}" ROWS=3 COLS=42>$in{'Description'}</TEXTAREA></td></tr>
							<tr><td align=right valign=top><$font>Contact Name:</font></td>
								<td><INPUT NAME="Contact Name" VALUE="$in{'Contact Name'}" SIZE=40></td></tr>					           
							<tr><td align=right valign=top><$font>Contact Email:</font></td>
								<td><INPUT NAME="Contact Email" VALUE="$in{'Contact Email'}" SIZE=40></td></tr>					           		           
							<tr><td colspan=2><Center><INPUT TYPE="SUBMIT" VALUE="Modify Resource"></Center></td></tr>
						</table>
					</form>
				</td></tr>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;
}

sub site_html_modify_success {
# --------------------------------------------------------
# This routine determines how the modify failure page will look like. You have
# access to the following variables:
#
#   %in     : the variables used to modify the link, useful in confirming what was
#             modified.
#

    &html_print_headers;
    print qq~
<html>

<head>
<title>$site_title: Resource Modified</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Resource Modified</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<$font>We have received the following link:</font>
<PRE><strong>          Title:  $in{'Title'}
            URL:  $in{'URL'}
    Description:  $in{'Description'}
   Contact Name:  $in{'Contact Name'}
  Contact Email:  $in{'Contact Email'}
       Category:  $in{'Category'}
</strong></PRE>				
					<P><$font>Thank you! We will send you an email once your record has been validated.</font>
				</tr></td>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;
}

sub site_html_modify_failure {
# --------------------------------------------------------
# This routine determines how the modify failure page will look like. You have
# access to the following variables:
#
#   $errormsg       : A bulleted list of the problems.
#   %in             : variables used in modifying the form. Useful for recreating
#					 the form
#

    my ($errormsg) = $_[0];

    &html_print_headers;
    print qq~
<html>

<head>
<title>$site_title: Error Modifying Resource.</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Error Modifying Resource</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td colspan=2>
					<FORM ACTION="$build_modify_url" METHOD="POST">
						<p align=center><$font>There were the following errors trying to modify your resource:<br>
						<font color="red"><strong>
							$errormsg
						</strong></font>
						<p>Please make any changes and try again!</font>
						<p><$font>Please enter the URL of the link you wish to update. Make sure it is identical to the one already in the database:</font>
						<input name="Current URL" value="$in{'Current URL'}" size=30>
						<p><$font>Now enter the new information (all of it, not just the changes) below:
						<table border=0 bgcolor="#FFFFDF" width="80%">
							<tr><td align=right valign=top><$font>Title:</font></td>
								<td><INPUT NAME="Title" VALUE="$in{'Title'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>URL:</font></td>
								<td><INPUT NAME="URL" VALUE="$in{'URL'}" SIZE=50></td></tr>
							<tr><td align=right valign=top><$font>Category:</font></td>
								<td>~; $db_select_fields{'Category'} = join (",", &category_list); print &build_select_field ("Category", "$in{'Category'}"); print qq~</td></tr>
							<tr><td align=right valign=top><$font>Description:</font></td>
								<td><TEXTAREA NAME="Description" VALUE="$in{'Description'}" ROWS=3 COLS=42>$in{'Description'}</TEXTAREA></td></tr>
							<tr><td align=right valign=top><$font>Contact Name:</font></td>
								<td><INPUT NAME="Contact Name" VALUE="$in{'Contact Name'}" SIZE=40></td></tr>					           
							<tr><td align=right valign=top><$font>Contact Email:</font></td>
								<td><INPUT NAME="Contact Email" VALUE="$in{'Contact Email'}" SIZE=40></td></tr>				           
							<tr><td colspan=2><Center><INPUT TYPE="SUBMIT" VALUE="Modify Resource"></Center></td></tr>
						</table>
					</form>
				</td></tr>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;

}

##########################################################
##					  Search Results				  ##
##########################################################

sub site_html_search_results {
# --------------------------------------------------------
# This routine displays the search results.
# 

my (@hits) = @_;
    
    &html_print_headers;    
    print qq~
<html>

<head>
<title>$site_title: Search Results</title>
</head>

<$site_body>

<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Search Results</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<center>
						<$font>Your search returned <strong>$cat_hits</strong> categories and <strong>$link_hits</strong> Links.</font>
					</center>
~;
if ($next) {
	my (@lang) = ("first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eigth");
	print qq~
					<center>	
						<$font><br>Here is the $lang[$in{'nh'}] set of $maxhits hits. Get the next <strong><a href="$next">$next_hits</a></strong> hits?</font>
					</center>
~;
}
if ($category_results) {
	print qq~
					<p><$font_subtitle><strong>Categories:</strong></font><BR>
					<$font_category>$category_results</font>
~;
}
if ($link_results) {
	print qq~   
					<p><$font_subtitle><strong>Links</strong></font><br>
					<$font_link>$link_results</font>
~;
}
if ($next) {
	print qq~
					<p>
					<center>
						<$font>Get the next <strong><a href="$next">$next_hits</a></strong> hits?</font>
					</center>
~;
    }   
    print qq~
				</td></tr>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;
}

sub site_html_search_failure {
# --------------------------------------------------------
# This routine displays a failed search page with error in $error.
#
    my ($error) = $_[0];
    &html_print_headers;
    
    print qq~
<html>

<head>
<title>$site_title: Search Failed</title>
</head>

<$site_body>
<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Search Failed</strong></font><BR>
		<hr size=1 width=600>
			$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td>
					<p><$font>Error: <font color=red>$error</font>
					<form action="$build_search_url" method="GET">					  
						<center>
							<$font>
							<p>Search Again? <input type=text size=15 name="query"> <input type=submit value="Search!"><br>
							<a href="$build_search_url">More Options</a>
							</font>
						</center>
					</form>
				</td></tr>
			</table>
		</center>
		$site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;
}
    

sub site_html_search_form {
# --------------------------------------------------------
# This routine displays the search form.

    &html_print_headers;
    print qq~
<html>

<head>
<title>$site_title: Search Options</title>
</head>

<$site_body>
<center>
<a href="/"><img src="/images/gos_banner.jpg" border=0 width=476 height=54></a>
<table border="0" width="600">
	<tr><td valign="top">
		<P>
		<hr size=1 width=600>
		<$font_subtitle><strong>$site_title: Search Options</strong></font><BR>
		<hr size=1 width=600>
		$site_menu
		<hr size=1 width=600>
		<center>
			<table border=1 bgcolor="#FFFFDF" width="80%">            
				<tr><td><center>
					<form action="$build_search_url" method="GET">
						<$font>
						Search: <INPUT TYPE="TEXT" NAME="query" SIZE=30> <INPUT TYPE="Submit" VALUE="Search"><BR>
						Number of Results: <SELECT NAME="mh"><OPTION>10<OPTION SELECTED>25<OPTION>50<OPTION>100</SELECT><BR>
						As Keywords: <INPUT TYPE="RADIO" NAME="type" VALUE="keyword" CHECKED> As Phrase: <INPUT TYPE="RADIO" NAME="type" VALUE="phrase"><BR>
						AND connector: <INPUT TYPE="RADIO" NAME="bool" VALUE="and" CHECKED> OR connector: <INPUT TYPE="RADIO" NAME="bool" VALUE="or">
						</font>
					</form>
				</center></td></tr>
			</table>
		</center>
	    $site_footer
	</td></tr>
</table>
</center>
</body>
</html>
~;
}

1;