#!/usr/bin/perl
#
#               -------------
#				   Links
#               -------------
#               Links Manager
#
#         File: bookmark.pl
#  Description: This program converts a Netscape bookmark file into a links database.
#       Author: Alex Krohn
#        Email: alex@gossamer-threads.com
#          Web: http://www.gossamer-threads.com/
#      Version: 1.11
#
# COPYRIGHT NOTICE:
#
# Copyright 1997 Gossamer Threads Inc.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified free of charge for personal, academic, government or non-profit
# use, so long as this copyright notice and the header above remain intact.
# Any commercial use should be registered.  Please also send me an email,
# and let me know where you are using this script. By using this program 
# you agree to indemnify Gossamer Threads Inc. from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain written permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# Please check the README file for full details on registration.
# =====================================================================

# Converts a netscape bookmark file into a database suitable for Links. 
# PLEASE NOTE:
#     * DOES NOT currently support inserting comments.
#     * ASSUMES default installation. If you've changed fields, you'll have
#       to edit the script.

# Set the default Subscriber name, and Subscriber email.
$sub = "Alex Krohn";
$subemail = "alex\@gossamer-threads.com";

# Usage: bookmark.pl <name of bookmark file>
if ($#ARGV != 0) {
    die "usage: bookmark.pl input.htm\n";
}

open (BM, "<$ARGV[0]") or die "unable to find bookmark file: $ARGV[0]. Reason: $!";

$id = 0;
LINE: while (<BM>) {
    s/\|/~~/g;
    $line = $_; 
    if ($line =~ m,</DL>,i) {
        pop (@cat);
        $category = join ("/", @cat);
    }
    if ($line =~ m,<h3[^>]*>([^<]*)</h3>,i) {
        $cat = $1;
        $cat =~ s/\s/_/g;
        $cat =~ s/[^\w\s]//g;
        push (@cat, $cat);
        $category = join ("/", @cat);
    }
    if ($line =~ m,<A HREF="([^"]*)"([^>]*)>([^<]*),i) {
        $id++;
        ($url, $dates, $name) = ($1, $2, $3);
        if ($dates =~ m,ADD_DATE="(\d*)",ig) {
            ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
				localtime($1);
            if ($day < 10) { $day = "0$day"; }
            if ($mon < 10) { $mon = "0$mon"; }
            $date = "$mday-$mon-$year";
        }
        else {
            $date = "29-10-97";
        }
        print "$id|$name|$url|Web|NULL|$date|$category|NULL|$sub|$subemail|0|No|No\n";
    }

}
close BM;