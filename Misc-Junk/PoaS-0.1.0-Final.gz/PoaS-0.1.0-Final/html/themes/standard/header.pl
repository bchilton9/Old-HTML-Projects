###############################################################################
###############################################################################
# header.pl - prints the top of each page                                     #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)			    #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: header.pl, Last modified: 20:23 09/15/2002			      # ###############################################################################
###############################################################################

	print "Content-type: text/html\n\n";
	print qq~<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>$pagetitle</title>
<meta name="Generator" content="$scriptname $scriptver">
$mtag
<link rel="stylesheet" href="$themesurl/standard/style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="3" topmargin="3" background="$themesurl/standard/images/globeback.gif">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="18%"><img src="$themesurl/standard/images/logo.gif" width="176" height="87" alt="$pagename"><br>
    &nbsp;$shortdate&nbsp;</td>
    <td width="82%" align="center">
      
        <table width="80%" border="1" cellspacing="1" cellpadding="3" bgcolor="#2979BD" class=banner>
          <tr> 
            <td bgcolor="#FFFFFF">
              <div align="center">
~;

require "$scriptdir/config.pl";
if ($showban eq 1) {

require "$sourcedir/ads.pl";
check_ads_setting();
	if ($top_ads eq 1) {
		OutputAd();
	}
}

if ($showban eq 0) {

print qq~
		<b><br>
                Your Banner Here<br>
                </b>
~;
}
print qq~
		</div>
            </td>
          </tr>
        </table>
      
    </td>
  </tr>
</table>
<table width="100%" border="1" cellspacing="2" cellpadding="3" class=top_menu bordercolor="#57A6CC">
  <tr bgcolor="#C6E7F7"> 
    <td> 
      <div align="center">&nbsp;<a href="$pageurl/$cgi" class="nav">$nav{'002'}</a>&nbsp;</div>
    </td>
    <td> 
      <div align="center">&nbsp;<a href="$pageurl/$cgi?action=forum&amp;board=" class="nav">$nav{'003'}</a>&nbsp;</div>
    </td>
    <td> 
      <div align="center">&nbsp;<a href="$pageurl/$cgi?action=topics" class="nav">$nav{'004'}</a>&nbsp;</div>
    </td>
    <td> 
      <div align="center">&nbsp;<a href="$pageurl/$cgi?action=stats" class="nav">$nav{'006'}</a>&nbsp;</div>
    </td>
    <td> 
      <div align="center">&nbsp;<a href="$pageurl/$cgi?action=recommend" class="nav">$nav{'008'}</a>&nbsp;</div>
    </td>
    <td> 
      <div align="center">&nbsp;<a href="$pageurl/$cgi?action=downloads" class="nav">$nav{'056'}</a>&nbsp;</div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="16%" valign="top"> 
      <table width="150" border="0" cellspacing="0" cellpadding="0">
~;
        $top_block_separator = qq~<tr><td>~;
	$bottom_block_separator = qq~</td></tr>~;
	$block_separator = qq~<tr><td height="6"></td></tr>~;

	require "$sourcedir/block.pl";
	block_left();

	print qq~
	<tr>
	  <td>
	  <table border="0" cellpadding="0" cellspacing="0" width="150">
	  <tr>
	  <td align="center">
	  <table border="0" cellpadding="3" cellspacing="0">
	  <tr>
	  <td align="center">&nbsp;</td>
	  </tr>
	  <tr>
	  <td align="center"><a href="http://validator.w3.org/check/referer" target="_blank"><img border="0" src="$imagesurl/valid-html401.gif" alt="Valid HTML 4.01!" height="31" width="88"></a></td>
	  </tr>
	  <tr>
	  <td align="center"><a href="http://jigsaw.w3.org/css-validator" target="_blank"><img width="88"height="31" border="0" src="$imagesurl/vcss.gif" alt="Valid CSS!"></a></td>
	  </tr>
	  </table>
	  </td>
          </tr>
          </table>
	  </td>
	</tr>
      </table>
    </td>
    <td width="68%" valign="top" valign="top">
      <table width="100%" border="1" cellspacing="2" cellpadding="3" bordercolor="#57A6CC" class=isi>
        <tr> 
          <td bgcolor="#C6E7F7"> <b>&nbsp;Home $navbar </b></td>
        </tr>
        <tr> 
          <td>
~;

1; # return true
