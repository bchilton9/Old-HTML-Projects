###############################################################################
###############################################################################
# footer.pl - prints the bottom of each page                                  #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)	                      #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: footer.pl, Last modified: 23:23 09/15/2002			      #
###############################################################################
###############################################################################

print qq~
            </td>
        </tr>
      </table></td>
    <td width="16%" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
~;
        $top_block_separator = qq~<tr><td>~;
	$bottom_block_separator = qq~</td></tr>~;
	$block_separator = qq~<tr><td height="6"></td></tr>~;

	require "$sourcedir/block.pl";
	block_right();

print qq~
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan="3" align="center">&nbsp;<font size="2">This web site was made with <a href="http://poas.netfirms.com">PoaS</a>, a lightweight web portal system written in Perl by Luck.<br>
Poas is Free Software released under the <a href="http://www.gnu.org">GNU/GPL license</a>, version 2 or later.<br> Template Design By <a href="http://kudus.cybermuslim.net">Wilga</a></font>
<script language="JavaScript">
<!--
function setCookie(NameOfCookie, value, expirehours) {
var ExpireDate = new Date ();
ExpireDate.setTime(ExpireDate.getTime() + (expirehours * 3600 * 1000));
document.cookie = NameOfCookie + "=" + escape(value) +
((expirehours == null) ? "" : "; expires=" + ExpireDate.toGMTString()) +

"; path=/;" ;
}
if (document.cookie.indexOf('AdPopUpC11')==-1)
{
  setCookie('AdPopUpC11','yes',1);
 document.write('<'+'SCRIPT LANGUAGE="JavaScript" SRC="');
 document.write('http://adserv.adbonus.com/cgi-bin/track.cgi?');
 document.write('c=getmedia&pid=53363">'+'<'+'/SCRIPT>');

}
// -->
</script>
<script language="JavaScript">
window.focus();
</script>
 </td>
  </tr>
</table>
</body>
</html>

~;
1;
