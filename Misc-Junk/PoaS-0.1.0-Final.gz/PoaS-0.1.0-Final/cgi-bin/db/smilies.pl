###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# smilies.pl - prints out a list of the little smilies we all love            #
# based on YaWPS 							      #
#                                                                             #
# Copyright (C) 2001 by Luck (luckie_aria@excite.com)                         #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: smilies.pl, Last modified: 17:38 12/30/2001                           #
###############################################################################
###############################################################################


require "$themesdir/$usertheme/theme.pl"; getvars();

print "Content-type: text/html\n\n";
print qq~<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
    
<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>$pagename - Smilies</title>
<link rel="stylesheet" href="$themesurl/$usertheme/style.css" type="text/css">
<script language="javascript" type="text/javascript">
<!--
function addCode(anystr) { 
opener.document.creator.message.value+=anystr;
}
// -->
</script>

</head>


<body bgcolor="#ffffff" text="#000000">

<table align="center" border="0" bgcolor="$windowbg" cellspacing="1" cellpadding="0" width="99%">
<tr>
<td>
<table border="0" cellspacing="1" cellpadding="2" width="100%">
<tr>
<td bgcolor="$windowbg3" valign="top" width="50%"><b>Code</b></td>
<td bgcolor="$windowbg3" valign="top" width="50%"><b>Smilie</b></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[bones]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[bones]')"><img src="$imagesurl/forum/smilies/bones.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[bounce]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[bounce]')"><img src="$imagesurl/forum/smilies/bounce.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:-?</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':-?')"><img src="$imagesurl/forum/smilies/confused.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[confused]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[confused]')"><img src="$imagesurl/forum/smilies/confused.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">8)</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('8)')"><img src="$imagesurl/forum/smilies/cool.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">8-)</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('8-)')"><img src="$imagesurl/forum/smilies/cool.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[cool]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[cool]')"><img src="$imagesurl/forum/smilies/cool.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[cry]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[cry]')"><img src="$imagesurl/forum/smilies/cry.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:o</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':o')"><img src="$imagesurl/forum/smilies/eek.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:-o</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':-o')"><img src="$imagesurl/forum/smilies/eek.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[eek]]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[eek]')"><img src="$imagesurl/forum/smilies/eek.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[evil]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[evil]')"><img src="$imagesurl/forum/smilies/evil.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:(</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':(')"><img src="$imagesurl/forum/smilies/frown.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:-(</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':-(')"><img src="$imagesurl/forum/smilies/frown.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[frown]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[frown]')"><img src="$imagesurl/forum/smilies/frown.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:D</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':D')"><img src="$imagesurl/forum/smilies/grin.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:-D</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':-D')"><img src="$imagesurl/forum/smilies/grin.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[grin]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[grin]')"><img src="$imagesurl/forum/smilies/grin.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[lol]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[lol]')"><img src="$imagesurl/forum/smilies/lol.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:x</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':x')"><img src="$imagesurl/forum/smilies/mad.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:-x</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':-x')"><img src="$imagesurl/forum/smilies/mad.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[mad]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[mad]')"><img src="$imagesurl/forum/smilies/mad.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[ninja]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[ninja]')"><img src="$imagesurl/forum/smilies/ninja.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[nonsense]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[nonsense]')"><img src="$imagesurl/forum/smilies/nonsense.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[oops]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[oops]')"><img src="$imagesurl/forum/smilies/oops.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[rolleyes]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[rolleyes]')"><img src="$imagesurl/forum/smilies/rolleyes.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:)</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':)')"><img src="$imagesurl/forum/smilies/smile.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:-)</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':-)')"><img src="$imagesurl/forum/smilies/smile.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[smile]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[smile]')"><img src="$imagesurl/forum/smilies/smile.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:P</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':P')"><img src="$imagesurl/forum/smilies/tongue.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">:-P</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(':-P')"><img src="$imagesurl/forum/smilies/tongue.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[tongue]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[tongue]')"><img src="$imagesurl/forum/smilies/tongue.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">;)</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(';)')"><img src="$imagesurl/forum/smilies/wink.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">;-)</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode(';-)')"><img src="$imagesurl/forum/smilies/wink.gif" border="0" alt=""></a></td>
</tr>
<tr>
<td bgcolor="$windowbg2" valign="top" width="50%">[wink]</td>
<td bgcolor="$windowbg2" valign="top" width="50%"><a href="javascript:addCode('[wink]')"><img src="$imagesurl/forum/smilies/wink.gif" border="0" alt=""></a></td>
</tr>
</table>
</td>
</tr>
</table>
<br>
<center>[<a href="javascript:window.close();">$nav{'045'}</a>]</center>
<br>

</body>

</html>
~;

exit; # return true
