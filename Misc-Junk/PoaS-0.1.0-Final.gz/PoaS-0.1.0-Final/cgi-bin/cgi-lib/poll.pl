###############################################################################
###############################################################################
# PoaS - Peronall Site                                                       #
#-----------------------------------------------------------------------------#
# poll.pl - this code displays the voting table and the result page of polls  #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                        #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: poll.pl, Last modified: 18:51 08/04/2002                              #
###############################################################################
###############################################################################


##########
sub poll {
##########
	open(FILE, "$datadir/polls/polls.txt");
	@polls = <FILE>;
	close(FILE);

	$rpol = @polls;
	$rid = int(rand $rpol);

	($id[$rid], $name[$rid]) = split(/\|/, $polls[$rid]);


	if (@polls == 0) {
		print qq~<tr>
<td align="center" class="cat">$msg{'153'}</td>
</tr>
~;
	}
	else {
		print qq~<tr>
<td class="cat">
~;
		open(FILE, "$datadir/polls/$id[$rid]_q.dat");
		chomp(@data = <FILE>);
		close(FILE);

		print qq~<form action="$pageurl/$cgi?action=pollit" method="post">
<table cellpadding="0" cellspacing="0" border="0" align="center" width="100%">
<tr>
<td align="center" class="cat">$name[$rid]</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
~;
		for ($i = 0; $i < @data; $i++) {
			print qq~<tr>
<td valign="top" class="cat"><input type="radio" name="answer" value="$i">$data[$i]</td>
</tr>
~;
		}
		print qq~<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="center"><input type="hidden" name="id" value="$id[$rid]">
<input type="hidden" name="submitted" value="1">
<input type="submit" value="$btn{'002'}"><br>
<div class="cat"><a href="$pageurl/$cgi?action=pollit2&amp;id=$id[$rid]" class="menu">$nav{'013'}</a></div></td>
</tr>
</table>
</form>
</td>
</tr>
~;
	}
}

##########
sub poll2 {
##########
require "$sourcedir/security.pl";
	open(FILE3, "$datadir/polls/polls.txt");
	@polls3 = <FILE3>;
	close(FILE3);

	check_hash($info{'ido'});
	($id3[$info{'ido'}], $name3[$info{'ido'}]) = split(/\|/, $polls3[$info{'ido'}]);

$navbar = "$admin{'btn2'} $nav{'041'}";

print_top();

		print qq~<table><tr>
<td class="cat" align="center">
~;
		open(FILE3, "$datadir/polls/$id3[$info{'ido'}]_q.dat");
		chomp(@data3 = <FILE3>);
		close(FILE3);

		print qq~<form action="$pageurl/$cgi?action=pollit" method="post">
<table cellpadding="0" cellspacing="0" border="0" align="center" width="100%">
<tr>
<td align="center" class="cat">$msg{'064'} $name3[$info{'ido'}]</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
~;
		for ($i = 0; $i < @data3; $i++) {
			print qq~<tr>
<td valign="top" class="cat"><input type="radio" name="answer" value="$i">$data3[$i]</td>
</tr>
~;
		}
		print qq~<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align="center"><input type="hidden" name="id" value="$id3[$info{'ido'}]">
<input type="hidden" name="submitted" value="1">
<input type="submit" value="$btn{'002'}"><br>
<div class="cat"><a href="$pageurl/$cgi?action=pollit2a&amp;ido=$id3[$info{'ido'}]" class="menu">$nav{'013'}</a></div></td>
</tr>
</table>
</form>
</td>
</tr></table>
~;
	
print_bottom();
}

############
sub pollit {
############
	check_ip();
	if ($input{'answer'} eq "") { error("$err{'019'}"); }

	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	@polls = <FILE>;
	close(FILE);

	open(FILE, "$datadir/polls/$input{'id'}_a.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_a.dat");
	chomp(@data = <FILE>);
	close(FILE);

	open(FILE, ">$datadir/polls/$input{'id'}_a.dat") || error("$err{'016'} $datadir/polls/$input{'id'}_a.dat");
	lock(FILE);
	for ($i = 0; $i < @data; $i++) {
		if ($i == $input{'answer'}) {
			$count = $data[$i] + 1;
			print FILE "$count\n";
		}
		else { print FILE "$data[$i]\n"; }
	}
	unlock(FILE);
	close(FILE);

	open(LOG, ">>$datadir/polls/$input{'id'}_ip.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_ip.dat");
	lock(LOG);
	print LOG "$ENV{'REMOTE_ADDR'}|$ENV{'REMOTE_HOST'}\n";
	unlock(LOG);
	close(LOG);

	print "Location: $pageurl/$cgi\?action=pollit2\&id=$input{'id'}\n\n";
}

#############
sub pollit2 {
#############
	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	@polls = <FILE>;
	close(FILE);

	($id[$info{'id'}], $name[$info{'id'}]) = split(/\|/, $polls[$info{'id'}]);

	open(FILE, "$datadir/polls/$info{'id'}_q.dat") || error("$err{'001'} $datadir/polls/$info{'id'}_q.dat!");
	chomp(@questions = <FILE>);
	close(FILE);

	open(FILE, "$datadir/polls/$info{'id'}_a.dat") || error("$err{'001'} $datadir/polls/$info{'id'}_a.dat!");
	chomp(@answers = <FILE>);
	close(FILE);

	$totalvotes = 0;
	for ($x = 0; $x < @answers; $x++) {
		$totalvotes = $totalvotes + $answers[$x];
	}

	$navbar = "$admin{'btn2'} $nav{'013'}";
	print_top();
	print qq~<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr>
<td colspan="2" align="center"><b>$msg{'064'} $name[$info{'id'}]</b></td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
~;
	for ($i = 0; $i < @answers; $i++) {
		if ($totalvotes ne 0) {
			$pixels = int((($answers[$i]/$totalvotes) * 100)/2);
			$procent = ($answers[$i]/$totalvotes) * 100;
			$c = int(10*($procent*10 - int($procent*10)));
			$b = int(10*($procent - int($procent)));
			$a = int($procent);
			if ($c >= 5) { $b++ }
		} else { 
			$a = 0; 
			$b = 0;
		}
		$procent = $a.".".$b;

		print qq~<tr>
<td>$questions[$i]:</td>
<td><img src="$imagesurl/leftbar.gif" width="7" height="14" alt=""><img src="$imagesurl/mainbar.gif" width="$pixels" height="14" alt=""><img src="$imagesurl/rightbar.gif" width="7" height="14" alt="">&nbsp;&nbsp;($procent%)</td>
</tr>
~;
	}
	print qq~<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" align="center">$msg{'065'} $totalvotes</td>
</tr>
</table>
~;
	if (@polls == 0) { }
	else {
		print qq~<br><br>
<table align="center" cellspacing="2">
<tr>
<td align="center"><b>$msg{'150'}</b></td>
</tr>
~;
		foreach $line (@polls) {
			@item = split(/\|/, $line);
			print qq~<tr>
<td>$item[1]</td>
<td align="right"><a href="$pageurl/$cgi?action=poll2&amp;ido=$item[0]">$btn{'002'}</a></td>
<td align="right"><a href="$pageurl/$cgi?action=pollit2&amp;id=$item[0]">$nav{'013'}</a></td>
</tr>
~;
		}
		print "</table>\n";
	}
	print_bottom();
	exit;
}


##############
sub check_ip {
##############
	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	@polls = <FILE>;
	close(FILE);

	($id[0], $name[0]) = split(/\|/, $polls[0]);
	$usersip = $ENV{'REMOTE_ADDR'};

	open('LOG', "$datadir/polls/$id[0]_ip.dat") || error("$err{'001'} $datadir/polls/$id[$rpolls]_ip.dat");
	@entries = <LOG>;
	close(LOG);

	foreach $curentry (@entries) {
		$curentry =~ s/\n//g;
		$curentry =~ s/\r//g;
		($ip, $host) = split(/\|/, $curentry);
		if ($usersip eq "$ip") { error("$err{'020'}") }
	}
}

1; # return true
