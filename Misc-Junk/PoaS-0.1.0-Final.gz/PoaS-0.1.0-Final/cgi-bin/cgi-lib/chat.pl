###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# chat.pl - this code handles the chat function                               #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                             #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: chat.pl, Last modified: 22:54 08/04/2002                             #
###############################################################################
###############################################################################

#################
sub chatoption {
#################
$navbar = "$admin{'btn2'} Chat";
print_top();
print qq~<center><b><big><big>$pagetitle - Chat</big></big></b></center><p>
Please Choose Chat Type:<br>
<a href="$pageurl/$cgi?action=chat">Internal Chat</a> - Light (Members Only)<br>
<a href="$pageurl/$cgi?action=cgiircchat">CGI::IRC Chat</a> - Heavy (Public)<br>
~;
print_bottom();
}

################
sub chat {
################
require "$sourcedir/security.pl";

if ($username eq $anonuser) { print_top(); error ("$chat{'only_registered'}"); print_bottom();}

if ($info{'chataction'} eq "privmsg") { private_message();}
if ($info{'chataction'} eq "clear") { clearchat();}
if ($info{'chataction'} eq "logout") { print "Location: $pageurl/$cgi\?action=chatout\n\n"; }
if ($info{'chataction'} eq "refresh") { print "Location: $pageurl/$cgi\?action=chat\n\n"; }
if ($info{'chataction'} eq "whois") { whois(); }

if ($info{'message'} ne "") {

	getdate();
	$timenow = "$hour\:$min\:$sec";	
	check_hash($info{'action'});

	open (CHAT, ">>$datadir/autopage/chat/$info{'action'}.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write message]");
	lock (CHAT);
	print CHAT "[$username $timenow] $info{'message'}<br>";
	unlock (CHAT);
	close (CHAT);

	open (CHATL, "$datadir/autopage/chat/$info{'action'}.dat") || error("Can't open $datadir/autopage/chat/chat.dat [open temp]");
	$tempchat = <CHATL> ;
	close (CHATL);

		if (length($tempchat) > 600) {
			$tmpwrite = substr($tempchat, 250);
			open (CHATW, ">$datadir/autopage/chat/$info{'action'}.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write temp]");
			lock (CHATW);
			print CHATW "$tmpwrite";
			unlock (CHATW);
			close (CHATW);
		}

	open (CHATL, "$datadir/autopage/chat/privatemsg/$username.msg") || error("Can't open $datadir/autopage/chat/privatemsg/$username.msg [open user msg temp]");
	$tempchat = <CHATL> ;
	close (CHATL);

		if (length($tempchat) > 300) {
			$tmpwrite = substr($tempchat, 125);
			open (CHATW, ">$datadir/autopage/chat/$info{'action'}.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write temp]");
			lock (CHATW);
			print CHATW "$tmpwrite";
			unlock (CHATW);
			close (CHATW);
		}

	print "Location: $pageurl/$cgi\?action=chat\n\n";
}

$chat_header = "<center><big><big>$pagename chat</big></big></center><p><table align=center border=1 wraping=\"yes\"><td wraping=\"yes\" width=80%> ";
$new_mtag = "<meta http-equiv=\"refresh\" content=\"60; charset=$charset; url=\"$pageurl/$cgi\?action=chat;\"> ";
$use_mtag = 1;

	check_hash($info{'action'});
	open(AUTOPC, "$datadir/autopage/chat/$info{'action'}.dat") || error("Can't open $datadir/autopage/chat/chat.dat [open view]");
	$chat_content = <AUTOPC>;
	close(AUTOPC);

	write_chat_user();

	open(AUTOPC, "$datadir/autopage/chat/privatemsg/$username.msg") || error("Can't open $datadir/autopage/chat/privatemsg/$username.msg [open view]");
	$priv_chat_content = <AUTOPC>;
	close(AUTOPC);

	$navbar = "$admin{'btn2'} $chat{'chat'}";
	if ($use_mtag eq 1) { $mtag = $new_mtag };
	print_top();
	if ($username eq $anonuser) { error ("$chat{'only_registered'}");}

	opendir(DIRCO, "$datadir/autopage/chat/online");
	@contentsco = readdir(DIRCO);
	closedir(DIRCO);

     	FILECO: foreach $lineco (sort @contentsco) {

        	next FILECO if ($lineco eq '.');
        	next FILECO if ($lineco eq '..');
        	next FILECO if ($lineco eq '.htaccess');
		next FILECO if ($lineco eq 'online.cnt');
		next FILECO if ($lineco eq 'ONLINE.CNT');

		($name, $extension) = split (/\./, $lineco);
		$daf_online .= "<option>$name</option>";

	}

	print "$chat_header <p>\n";
	print "$chat_content <p>\n";
	print qq~</td></table><br><table align=center width=80% border=2><td>
	<center><u><b>PRIVATE MESSAGE</b></u><br></center>
	$priv_chat_content</td></table>
	<br><table align=center width=80% border=2><td align=center>
	<form action=\"$pageurl/$cgi" method=\"GET\"><input type=\"hidden\" name=\"action\" value=\"chat\">
	$chat{'command'} :<select name=\"chataction\"><option value=\"refresh\">$chat{'refresh'}</option>
	<option value=\"logout\">$chat{'logout'}</option><option value=\"privmsg\">Private</option><option value=\"whois\">Whois</option>~;
	if ($settings[7] eq "Administrator") { print qq~ <option value=\"clear\">$chat{'clear'}</option>~; }
	print qq~
	</select> To -> OL Chatter : <select name=\"tooluser\">$daf_online</select><br>
	<input type=\"hidden\" name=\"fromuser\" value=\"$username\">
	<input type=\"text\" class=\"text\" name=\"message\" size=\"30\" maxlength=\"200\" value=\"\"><input type=\"submit\" value=\"$chat{'send'}\">
	</form></td></table> <p> $chat{'online_chatter'} : <br> <select>~;

	print qq~$daf_online</select>~;
	print_bottom();

$chat_header = "";
$chat_footer = "";



}

################
sub clearchat {
################
require "$sourcedir/security.pl";
if ($username eq $anonuser) { error ("You can't do this action"); }

	$timenow = "$hour\:$min\:$sec";	
	check_user_permission();
	check_hash($info{'action'});

	open (CHAT, ">$datadir/autopage/chat/$info{'action'}.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write message]");
	lock (CHAT);
	print CHAT "** System ** Chat room has been cleared by $username at $timenow<br>";
	unlock (CHAT);
	close (CHAT);

	print "Location: $pageurl/$cgi\?action=chat\n\n";
	exit();
}

#####################
sub write_chat_user {
#####################
if ($username eq $anonuser) { error ("You can't do this action"); }
	
	$chatunow = $mday.$min;

		open (CHATU, "$datadir/autopage/chat/online/$username.ol") || writechatnow();
		print CHATU "$chatunow";
		close (CHATU);
	
		open (CHATU, ">$datadir/autopage/chat/online/$username.ol") || error("Can't open $datadir/autopage/chat/online/$username.ol [write message]");
		lock (CHATU);
		print CHATU "$chatunow";
		unlock (CHATU);
		close (CHATU)
}

##############
sub chatout {
##############
if ($username eq $anonuser) { error ("You can't do this action"); }

			$timenow = "$hour\:$min\:$sec";

			unlink ("$datadir/autopage/chat/online/$info{'user'}.ol");
			unlink ("$datadir/autopage/chat/privatemsg/$info{'user'}.msg");

			open (CHATUMCNT, "$datadir/autopage/chat/online/online.cnt") || error("Can't open $datadir/autopage/chat/online/online.cnt");
			$chatucountm=<CHATUMCNT>;
			close (CHATUMCNT);

			$chatucountm--;

			if ($chatucountm < 0) { $chatucountm = 1; }

			open (CHATUMCNT,">$datadir/autopage/chat/online/online.cnt");
			lock (CHATUMCNT);
			print CHATUMCNT $chatucountm;
			unlock (CHATUMCNT);
			close (CHATUMCNT);

			open (CHATD, ">>$datadir/autopage/chat/chat.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write message]");
			lock (CHATD);
			print CHATD "** System ** $username Has Left Chat Room at $shortdate - $timenow<br>";
			unlock (CHATD);
			close (CHATD);

			open (CHATLOG, ">>$datadir/members/$username.log");
			lock (CHATLOG);
			print CHATLOG "chat|$writedate";
			unlock (CHATLOG);
			close (CHATLOG);

			print "Location: $pageurl/$cgi\n\n";

}

####################
sub writechatnow {
####################
require "$sourcedir/security.pl";

	$chatunow = $mday.$min;

		open (CHATU, ">$datadir/autopage/chat/online/$username.ol") || error("Can't open $datadir/autopage/chat/online/$username.ol");
		lock (CHATU);
		print CHATU "$chatunow";
		unlock (CHATU);
		close (CHATU);

		open (CHATU, ">$datadir/autopage/chat/privatemsg/$username.msg") || error("Can't open $datadir/autopage/chat/online/$username.ol");
		lock (CHATU);
		print CHATU "";
		unlock (CHATU);
		close (CHATU);

		open (CHATUCNT, "$datadir/autopage/chat/online/online.cnt") || error("Can't open $datadir/autopage/chat/online/online.cnt");
		$chatucount=<CHATUCNT>;
		close (CHATUCNT);

		$chatucount++;

		if ($chatucount < 0) { $chatucount = 1; }

		open (CHATUCNT,">$datadir/autopage/chat/online/online.cnt");
		lock (CHATUCNT);
		print CHATUCNT $chatucount;
		unlock (CHATUCNT);
		close (CHATUCNT);

		check_hash($info{'action'});
		open (CHAT, ">>$datadir/autopage/chat/$info{'action'}.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write message]");
		lock (CHAT);
		print CHAT "** System ** $username has enter chat room<br>";
		unlock (CHAT);
		close (CHAT);


	opendir(DIRCO, "$datadir/autopage/chat/online");
	@contentsco = readdir(DIRCO);
	closedir(DIRCO);

     	FILECO: foreach $lineco (sort @contentsco) {

        	next FILECO if ($lineco eq '.');
        	next FILECO if ($lineco eq '..');
        	next FILECO if ($lineco eq '.htaccess');
		next FILECO if ($lineco eq 'online.cnt');

		($name, $extension) = split (/\./, $lineco);
		next FILECO if ($extension ne 'ol');

		open (CHATO, "$datadir/autopage/chat/online/$name.ol") || error ("Can't open file");
		chomp($chatocon = <CHATO>);
		close (CHATO);

		$ctimenowc = $mday.$min;
		$chatoconnow = $chatocon +5;			
		if ($chatocon+5 < $ctimenowc) {
			unlink ("$datadir/autopage/chat/online/$lineco");
			unlink ("$datadir/autopage/chat/privatemsg/$name.msg");

			open (CHATUMCNT, "$datadir/autopage/chat/online/online.cnt") || error("Can't open $datadir/autopage/chat/online/online.cnt");
			$chatucountm=<CHATUMCNT>;
			close (CHATUMCNT);

			$chatucountm--;

			open (CHATUMCNT,">$datadir/autopage/chat/online/online.cnt");
			lock (CHATUMCNT);
			print CHATUMCNT $chatucountm;
			unlock (CHATUMCNT);
			close (CHATUMCNT);

			open (CHAT, ">>$datadir/autopage/chat/chat.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write message]");
			lock (CHAT);
			print CHAT "** System ** $name Has Left Chat Room (Timeout)<br>";
			unlock (CHAT);
			close (CHAT);

		}
	}

######################
sub private_message {
######################
if ($username eq $anonuser) { error ("You can't do this action"); }


open (PRIV, ">>$datadir/autopage/chat/privatemsg/$info{'tooluser'}.msg");
lock (PRIV);
print PRIV "[ $info{'fromuser'} ] $info{'message'} <br>";
unlock (PRIV);
close (PRIV); 

open (MYPRIV, ">>$datadir/autopage/chat/privatemsg/$info{'fromuser'}.msg");
lock (MYPRIV);
print MYPRIV "->[ $info{'tooluser'}] $info{'message'}<br>";
unlock (MYPRIV);
close (MYPRIV);

print "Location: $pageurl/$cgi\?action=chat\n\n";
}

############
sub whois {
############

if ($username eq $anonuser) { error ("You can't do this action"); }

open (MYPRIV, ">>$datadir/autopage/chat/privatemsg/$info{'fromuser'}.msg");
lock (MYPRIV);
print MYPRIV "[$info{'fromuser'}] whois $info{'tooluser'}<br>";
unlock (MYPRIV);
close (MYPRIV);

open(FILE, "$memberdir/$info{'tooluser'}.dat") || error("$err{'010'}");
chomp(@memsettings = <FILE>);
close(FILE);

$whoisemail = "Email $memsettings[2]";
if ($memsettings[4] ne "") {
	$whoiswebsite = qq~Website <a href="$memsettings[4]">$memsettings[4]</a>~;
}
else { $whoiswebsite = ""; }

if ($memsettings[8] ne "") {
	$whoisicq = qq~ICQ <a href="http://www.icq.com/$memsettings[8]" target="_blank"><img src="http://wwp.icq.com/scripts/online.dll?icq=$memsettings[8]&amp;img=5" alt="$memsettings[8]" border="0"></a>~;
}
else { $whoisicq = ""; }

open (MYPRIV, ">>$datadir/autopage/chat/privatemsg/$info{'fromuser'}.msg");
lock (MYPRIV);
print MYPRIV "** System ** Whois result for $info{'tooluser'}<br>$whoisemail<br>$whoiswebsite<br>$whoisicq<br> >>End $info{'tooluser'} whois<< <br>";
unlock (MYPRIV);
close (MYPRIV);

}

	print "Location: $pageurl/$cgi\?action=chat\n\n";

}

################
sub cgiircchat{
################

$irc_nick = "PoaS????";
$irc_nick =~ s/\?/int rand 10/eg;

$navbar = "$admin{'btn2'} CGI::IRC Chat";
print_top();

print qq~
<form name="form" method="post" action="$pageurl/$cgi?action=cgiircchat2">

<input type="hidden" name="interface" value="nonjs">
<table border="0" cellpadding="5" cellspacing="0">
<tr><td colspan="2" align="center" bgcolor="#c0c0dd"><b>CGI:IRC
Login</b></td></tr>
<tr><td align="right" bgcolor="#f1f1f1">Nickname</td><td align="left"
bgcolor="#f1f1f1"><input type="text" name="Nickname" value="$irc_nick"></td></tr>
<tr><td align="right" bgcolor="#f1f1f1">Server</td><td align="left"
bgcolor="#f1f1f1"><input type="text" name="Server" value="irc.blitzed.org"></td></tr>
<tr><td align="right" bgcolor="#f1f1f1">Channel</td><td align="left"
bgcolor="#f1f1f1"><input type="text" name="Channel" value="#poas"></td></tr>
<tr><td align="left" bgcolor="#d9d9d9">
<small><a href="$pageurl/cgiirc/irc.cgi?adv=1">Advanced..</a></small>
</small></td><td align="right" bgcolor="#d9d9d9">
<input type="submit" value="Login" style="background-color: #d9d9d9">
</td></tr></table></form>

<small id="ietest"><a href="http://cgiirc.sourceforge.net/">CGI:IRC</a> 0.5<br />
&copy;David Leadbeater 2000-2002
</small>
~;
print_bottom();
}

################
sub cgiircchat2 {
################

$navbar = "$admin{'btn2'} CGI::IRC Chat";
print_top();
print qq~
<iframe align=center width=620 height=450 src="$pageurl/cgiirc/irc.cgi?interface=ie&Nickname=$input{'Nickname'}&Server=$input{'Server'}&Channel=$input{'Channel'}">
</iframe>
~;
print_bottom();

}

1;
