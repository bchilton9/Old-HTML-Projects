###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                     #
#-----------------------------------------------------------------------------#
# instantmessage.pl - this code displays the instant messaging pages          #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                            #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: instantmessage.pl, Last modified: 18:45 05/20/2002                    #
###############################################################################
###############################################################################


#############
sub imindex {
#############
	if ($username eq "$anonuser") { error("$err{'011'}"); }

	open(FILE, "$memberdir/$username.msg");
	@imessages = <FILE>;
	close(FILE);

	open(FILE, "$memberdir/membergroups.dat");
	@membergroups = <FILE>;
	close(FILE);
	
	open(CENSOR, "$boardsdir/censor.txt");
	@censored = <CENSOR>;
	close(CENSOR);

	$navbar = "$admin{'btn2'} $nav{'028'}";	
	print_top();
	print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg"><b>$msg{'049'}</b></td>
<td bgcolor="$windowbg"><b>$msg{'037'}</b></td>
</tr>
~;

	if (@imessages == 0) {
		print qq~<tr>
<td colspan="2" bgcolor="$windowbg2">$msg{'050'}</td>
</tr>
~;
	}
	$second = "$windowbg3";
	for ($a = 0; $a < @imessages; $a++) {
		if ($second eq "$windowbg2") { $second="$windowbg3"; }
		else { $second="$windowbg2"; }
		
		($musername[$a], $msub[$a], $mdate[$a], $mmessage[$a], $messageid[$a]) = split(/\|/, $imessages[$a]);
                
                if ($messageid[$a] < 100) { $messageid[$a] = $a; }
		$subject = "$msub[$a]";
		if ($subject eq "") { $subject="---"; }
		
		$mmessage[$a] =~ s/\n//g;
		$mmessage[$a] =~ s/\r//g;
		$message="$mmessage[$a]";
		$name = "$mname[$a]";
		$date = "$mdate[$a]";
		$ip = "$mip[$a]";
		$postinfo = "";
		$signature = "";
		$viewd = "";
		$icq = "";
		$star = "";

		open(FILE, "$memberdir/$musername[$a].dat");
		@memset = <FILE>;
		close(FILE);
		
		$ranking = $memset[6]+$memset[11]+$memset[12];
		
		$postinfo = qq~$msg{'021'} $memset[6]<br>
$msg{'022'} $memset[11]<br>
$msg{'023'} $memset[12]<br>
~;
		$viewd = qq~&nbsp;&nbsp;<a href="$pageurl/$cgi\?action=viewprofile&username=$musername[$a]"><img src="$imagesurl/forum/profile.gif" alt="$msg{'051'} $musername[$a]" border="0"></a>~;
		$memberinfo = "$membergroups[2]";
		$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		if ($ranking > 25) {
			$memberinfo = "$membergroups[3]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 50) {
			$memberinfo = "$membergroups[4]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 75) {
			$memberinfo = "$membergroups[5]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 100) {
			$memberinfo = "$membergroups[6]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 250) {
			$memberinfo = "$membergroups[7]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 500) {
			$memberinfo = "$membergroups[8]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($boardmoderator eq "$musername[$a]") { $memberinfo = "$membergroups[1]"; }
		if ($memset[7] ne "\n") { $memberinfo = "$memset[7]"; }
		if ($memberinfo eq "Administrator") { $memberinfo = "$membergroups[0]"; }
		$signature = "$memset[5]";
		$signature =~ s/\&\&/<br>/g;
		$signature = qq~<br><br><br>
-----------------<br>
$signature
~;
		$memset[8] =~ s/\n//g;
		$memset[8] =~ s/\r//g;
		if ($memset[8] ne "") {
	                if (!($memset[8] =~ /\D/)) { 
				$icq = qq~&nbsp;&nbsp;<a href="http://www.icq.com/$memset[8]" target="_blank"><img src="http://wwp.icq.com/scripts/online.dll?icq=$memset[8]&amp;img=5" alt="$msg{'052'} $memset[8]" border="0"></a>~;
			}
		}
		$message = "$message\n$signature";

		if ($enable_ubbc) { doubbc(); }

		$url = "";
		if ($memset[3] ne "\n" && $musername[$a] ne "$anonuser") {
			$url = qq~<a href="$memset[4]" target="_blank"><img src="$imagesurl/forum/www.gif" alt="$msg{'053'} $musername[$a]" border="0"></a>&nbsp;&nbsp;~;
		}

		foreach $censor (@censored) {
			$censor =~ s/\n//g;
			($word, $censored) = split(/\=/, $censor);
			$message =~ s/$word/$censored/g;
			$subject =~ s/$word/$censored/g;
		}
		print qq~<tr>
<td bgcolor="$second" width="140" valign="top" rowspan="2"><b>$memset[1]</b><br>
$memberinfo<br>
$star<br><br>
$postinfo<br>
</td>
<td bgcolor="$second" valign="top">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr>
<td width="100%">&nbsp;<b>$subject</b></td>
<td align="right" nowrap><b>$msg{'054'}</b> $date</td>
</tr>
</table>
<hr noshade="noshade" size="1">
$message
</td>
</tr>
<tr>
<td bgcolor="$second">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr>
<td>$url<a href="mailto:$memset[2]"><img src="$imagesurl/forum/email.gif" alt="$msg{'055'} $musername[$a]" border="0"></a>$viewd$icq</td>
<td align="right"><a href="$pageurl/$cgi?action=imsend&num=$a&quote=1&to=$musername[$a]"><img src="$imagesurl/forum/quote.gif" alt="$msg{'056'}" border="0"></a>&nbsp;&nbsp;<a href="$pageurl/$cgi?action=imsend&to=$musername[$a]&num=$a"><img src="$imagesurl/forum/modify.gif" alt="$msg{'057'}" border="0"></a>&nbsp;&nbsp;<a href="$forum&action=modify2&thread=$viewnum&id=$a&d=1"></a><a href="$pageurl/$cgi?action=imremove&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></td>
</tr>
</table>
</td>
</tr>
~;
	}
	print qq~</table>
</td>
</tr>
</table>
<br>
<a href="$pageurl/$cgi?action=imsend">$nav{'029'}</a>
~;

	print_bottom();
	exit;
}

##############
sub imremove {
##############
	if ($username eq "$anonuser") { error("$err{'011'}"); }

	open(FILE, "$memberdir/$username.msg");
	@imessages = <FILE>;
	close(FILE);

	open(FILE, ">$memberdir/$username.msg");
	lock(FILE);
	for ($a = 0; $a < @imessages; $a++) {
		($musername, $msub, $mdate, $mmessage, $messageid) = split(/\|/, $imessages[$a]);
		if ($messageid < 100 ) {
			if($a ne $info{'id'}) { print FILE "$imessages[$a]"; }
		}
		else {
			if(!($messageid =~ /$info{'id'}/)) { print FILE "$imessages[$a]"; }
		}
	}
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$cgi\?action=im\n\n";
}

############
sub impost {
############
        $mid = time; 
	if ($username eq "$anonuser") { error("$err{'011'}"); }

	open(FILE, "$memberdir/$username.msg");
	@imessages = <FILE>;
	close(FILE);

	if ($info{'num'} ne "") {
		($mfrom, $msubject, $mdate, $mmessage) = split(/\|/, $imessages[$info{'num'}]);
		$msubject =~ s/Re: //g;
		$form_subject = "Re: $msubject";

		if ($info{'quote'} == 1) {
			$form_message =~ s/\[quote\](\S+?)\[\/quote\]//isg;
			$form_message =~ s/\[(\S+?)\]//isg;
			$mmessage = htmltotext($mmessage);
			$form_message = "\n\n\[quote\]$mmessage\[/quote\]";
		}
	}

	$navbar = "$admin{'btn2'} $nav{'029'}";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="0" cellpadding="1">
<tr>
<td><form action="$pageurl/$cgi?action=imsend2" method="post">
<input name="messageid" value="$mid" type="hidden">
<table border="0" cellspacing="1">
<tr>
<td><b>$msg{'059'}</b></td>
~;
	if ($info{'to'} ne "") {
		print qq~<td><input type="text" name="to" value="$info{'to'}" size="20" maxlength="50"></td>~;
	}
	else {
		print qq~<td><select name="to">
~;
		open(MEM, "$memberdir/memberlist.dat");
		@members = <MEM>;
		close(MEM);

		for ($i = 0; $i < @members; $i++) {
			$members[$i] =~ s/\n//g;
			$members[$i] =~ s/\r//g;
			print qq~<option value="$members[$i]">$members[$i]</option>\n~;
		}
	print qq~</select></td>
~;
	}
	print qq~</tr>
<tr>
<td><b>$msg{'037'}</b></td>
<td><input type="text" name="subject" value="$form_subject" size="40" maxlength="50"></td>
</tr>
<tr>
<td valign="top"><b>$msg{'038'}</b></td>
<td><textarea name="message" rows="10" cols="40">$form_message</textarea></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="$btn{'008'}">
<input type="reset" value="$btn{'009'}"></td>
</tr>
</table>
</form>
</td>
</tr>
</table>
~;

	print_bottom();
	exit;
}

#############
sub impost2 {
#############
	error("$err{'014'}") unless($input{'subject'});
	error("$err{'015'}") unless($input{'message'});

	$messageid = $input{'messageid'};
	$subject = htmlescape($input{'subject'});
	$message = htmlescape($input{'message'});

	if (-e("$memberdir/$input{'to'}.dat")) { } else { error("$err{'010'}"); }

	open (FILE, "$memberdir/$input{'to'}.msg");
	@imessages = <FILE>;
	close (FILE);

	open (FILE, ">$memberdir/$input{'to'}.msg");
	lock(FILE);
	print FILE "$username|$subject|$date|$message|$messageid\n";
	foreach $curm (@imessages) { print FILE "$curm"; }
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$cgi\?action=im\n\n";
	exit;
}

1; # return true
