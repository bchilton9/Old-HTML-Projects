###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# block.pl - this code handles the block displaying                           #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                       #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: block.pl, Last modified: 22:54 09/15/2002                             #
###############################################################################
###############################################################################


################
sub block_left {
################
use Pee::FileRunner;
use CGI::SSI_Parser;

	open(FILE, "$datadir/blocks/blockleft.dat");
	$blockl = <FILE>;
	close(FILE);

	@iteml = split(/\|/, $blockl);
	chomp(@iteml);

	$i = 0;
	foreach (@iteml) {
		next if ($i eq "10");
		if($iteml[$i] ne "off") {
			
			open(FILE, "$datadir/blocks/id/$iteml[$i].txt");
			chomp(@iteml_cont = <FILE>);
			close(FILE);

			@set_iteml_cont = split(/\|/, $iteml_cont[0]);
			chomp(@set_iteml_cont);

			if($set_iteml_cont[1] eq "standard") {
				$i++;
				print "$top_block_separator";
	        		boxheader(150, "$set_iteml_cont[0]", "#737b9c", "#ffffff");
				print qq~<tr><td>$set_iteml_cont[2]</td></tr>~;
				boxfooter();
				print "$bottom_block_separator";
				print "$block_separator";
			}

			if($set_iteml_cont[1] eq "pee") {
				$i++;
				$pee_session = time;
				open(FILE, ">$datadir/temp/left$pee_session$iteml.tmp") || error ("Unable to create $datadir/temp/left$pee_session$iteml.tmp temp file");
				lock (FILE);
				print FILE $set_iteml_cont[2];
				unlock (FILE);
				close(FILE);

				my $runner = Pee::FileRunner->new("$datadir/temp/left$pee_session$iteml.tmp");

				print qq~$top_block_separator~;
	        		boxheader(150, "$set_iteml_cont[0]", "#737b9c", "#ffffff");

				if (!$runner->compile()) {
  					print "Error compiling template: $datadir/temp/left$pee_session$iteml.tmp\n";
  					print "<br>$runner->{errmsg}\n";
				}

				if (!$runner->run('main')) {
  					print "<p>Error running template: $datadir/temp/left$pee_session$iteml.tmp\n";
  					print "<br>$runner->{errmsg}\n";
				}			

				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";

				unlink("$datadir/temp/left$pee_session$iteml.tmp");
			}
			if($set_iteml_cont[1] eq "ssi") {
				$i++;
				$ssi_session = time;
				open(FILE, ">$datadir/temp/left$ssi_session$iteml.tmp") || error ("Unable to create $datadir/temp/left$pee_session$iteml.tmp temp file");
				lock (FILE);
				print FILE $set_iteml_cont[2];
				unlock (FILE);
				close(FILE);

				$CGI::SSI_Parser::recursive = 1;
				print qq~$top_block_separator~;
	        		boxheader(150, "$set_iteml_cont[0]", "#737b9c", "#ffffff");
				fssi("$datadir/temp/left$ssi_session$iteml.tmp");
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";

				unlink("$datadir/temp/left$ssi_session$iteml.tmp");
			}

			if($iteml[$i] eq "mainmenu") {
				$i++;
				print qq~$top_block_separator~;
	        		boxheader(150, "Main Menu", "#737b9c", "#ffffff");
				menuitem("links", "$nav{'005'}");
				menuitem("stats", "$nav{'006'}");
				menuitem("recommend", "$nav{'008'}");
				menuitem("downloads", "$nav{'056'}");
				menuitem("chatoption", "Chat");
				menuitem("top", "Top 10");

				new_menu_item();
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($iteml[$i] eq "search") {
				$i++;
				print qq~$top_block_separator~;
			#	$width, $title, $titlecolor, $bgcolor
	        		boxheader(150, "Search", "#737b9c", "#ffffff");
				print qq~
                   <p align="center"><center>
		    <form method="POST" action="$pageurl/$cgi?action=search"> 
                    <input type="text" name="keyword" class=form size="14">
                    <input type="submit" name="Submit" value="&lt;&lt; Search  ! &gt;&gt;" class=form>
		    </form></center>
                  </p>
				~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($iteml[$i] eq "userpanel") {
				$i++;
				print qq~$top_block_separator~;
			#	$width, $title, $titlecolor, $bgcolor
	        		boxheader(150, "My PoaS", "#737b9c", "#ffffff");
				print qq~<tr><td>~;
				userpanel();
				print qq~</td></tr>~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($iteml[$i] eq "userstatus") {
				$i++;
				print qq~$top_block_separator~;
			#	$width, $title, $titlecolor, $bgcolor
	        		boxheader(150, "User Status", "#737b9c", "#ffffff");
				userstatus();
				require "$sourcedir/onlinemember.pl";
				view_online_members();
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($iteml[$i] eq "addonsleft") {
				$i++;
				require "$sourcedir/addons.pl";
				addons_blockl();
			}

			if($iteml[$i] eq "language") {
				$i++;
				if ($username ne $anonuser) {
					require "$sourcedir/subs.pl";
					print qq~$top_block_separator~;
					languages_menu();
					print qq~$bottom_block_separator~;
					print "$block_separator";
				}
			}

			if($iteml[$i] eq "addonsmenu") {
				$i++;
				require "$sourcedir/addons.pl";
				addons_menu();
				addons_blockl();
			}

			if($iteml[$i] eq "top10") {
				$i++;
				require "$sourcedir/subs.pl";
				print qq~$top_block_separator~;
				boxheader(150, "Top 10", "#737b9c", "#ffffff");
				print qq~<tr><td class="cat">~;
				top10_block();
				print qq~</td></tr>~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($iteml[$i] eq "poll") {
				$i++;
				print qq~$top_block_separator~;
				boxheader(150, "$nav{'041'}", "#737b9c", "#ffffff");
				require "$sourcedir/poll.pl"; poll();
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($iteml[$i] eq "addonsright") {
				$i++;
				require "$sourcedir/addons.pl";
				addons_blockr();
			}

			if($iteml[$i] eq "information") {
				$i++;
				print qq~$top_block_separator~;
				boxheader(150, "Information", "#737b9c", "#ffffff");

				print qq~<tr>
					<td align="center" class="cat"><a href="http://www.perl.com/" target="_blank"><img alt="Powered by Perl!" border="0" height="31" src="$imagesurl/pb_perl.gif" width="88"></a></td>
					</tr>
					<tr>
					<td align="center" class="cat"><a href="http://www.gnu.org/" target="_blank"><img alt="Licensed under the GNU GPL!" border="0" height="31" src="$imagesurl/pb_gnugpl.gif" width="88"></a></td>
					</tr>
					<tr>
					<td align="center" class="cat"><a href="http://www.sourceforge.net/" target="_blank"><img alt="Hosted by Sourceforge!" border="0" height="31" src="http://sourceforge.net/sflogo.php?group_id=29456" width="88"></a></td>
					</tr>
					~;

				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

		}
		
	}
}

################
sub block_right {
################
use Pee::FileRunner;
use CGI::SSI_Parser;

	open(FILE, "$datadir/blocks/blockright.dat");
	@blockr = <FILE>;
	close(FILE);

	@itemr = split(/\|/, $blockr[0]);

	$i = 0;
	foreach (@iteml) {
		next if ($i eq "10");
		if($itemr[$i] ne "off") {
			open(FILE, "$datadir/blocks/id/$itemr[$i].txt");
			chomp(@itemr_cont = <FILE>);
			close(FILE);

			@set_itemr_cont = split(/\|/, $itemr_cont[0]);
			chomp(@set_itemr_cont);

			if($set_itemr_cont[1] eq "standard") {
				print qq~$top_block_separator~;
	        		boxheader(150, "$set_itemr_cont[0]", "#737b9c", "#ffffff");
				print qq~<tr><td>$set_itemr_cont[2]</td></tr>~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($set_itemr_cont[1] eq "pee") {
				$pee_session = time;
				open(FILE, ">$datadir/temp/right$pee_session$itemr.tmp") || error ("Unable to create $datadir/temp/right$pee_session$itemr.tmp temp file");
				lock (FILE);
				print FILE $set_itemr_cont[2];
				unlock (FILE);
				close(FILE);

				my $runner = Pee::FileRunner->new("$datadir/temp/right$pee_session$itemr.tmp");

				print qq~$top_block_separator~;
	        		boxheader(150, "$set_itemr_cont[0]", "#737b9c", "#ffffff");
				print qq~<tr><td>~;

				if (!$runner->compile()) {
  					print "Error compiling template: $datadir/temp/right$pee_session$itemr.tmp\n";
  					print "<br>$runner->{errmsg}\n";
				}

				if (!$runner->run('main')) {
  					print "<p>Error running template: $datadir/temp/right$pee_session$itemr.tmp\n";
  					print "<br>$runner->{errmsg}\n";
				}			

				print qq~</td></tr>~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";

				unlink("$datadir/temp/right$pee_session$itemr.tmp");
			}
			if($set_itemr_cont[1] eq "ssi") {

				$ssi_session = time;
				open(FILE, ">$datadir/temp/right$ssi_session$itemr.tmp") || error ("Unable to create $datadir/temp/right$ssi_session$itemr.tmp temp file");
				lock (FILE);
				print FILE $set_itemr_cont[2];
				unlock (FILE);
				close(FILE);

				$CGI::SSI_Parser::recursive = 1;
				print qq~$top_block_separator~;
	        		boxheader(150, "$set_itemr_cont[0]", "#737b9c", "#ffffff");
				print qq~<tr><td>~;
				fssi("$datadir/temp/right$ssi_session$itemr.tmp");
				print qq~</td></tr>~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";

				unlink("$datadir/temp/right$ssi_session$itemr.tmp");
			}

			if($itemr[$i] eq "mainmenu") {
				print qq~$top_block_separator~;
	        		boxheader(150, "Main Menu", "#737b9c", "#ffffff");
				menuitem("links", "$nav{'005'}");
				menuitem("stats", "$nav{'006'}");
				menuitem("recommend", "$nav{'008'}");
				menuitem("downloads", "$nav{'056'}");
				menuitem("chatoption", "Chat");
				menuitem("top", "Top 10");
				menuitem("faqs", "FAQS");

				new_menu_item();
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($itemr[$i] eq "search") {
				print qq~$top_block_separator~;
			#	$width, $title, $titlecolor, $bgcolor
	        		boxheader(150, "Search", "#737b9c", "#ffffff");
				print qq~
                   <p align="center"><center>
		    <form method="POST" action="$pageurl/$cgi?action=search"> 
                    <input type="text" name="keyword" class=form size="14">
                    <input type="submit" name="Submit" value="&lt;&lt; Search  ! &gt;&gt;" class=form>
		    </form></center>
                  </p>
				~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($itemr[$i] eq "userpanel") {
				print qq~$top_block_separator~;
			#	$width, $title, $titlecolor, $bgcolor
	        		boxheader(150, "My PoaS", "#737b9c", "#ffffff");
				userpanel();
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($itemr[$i] eq "userstatus") {
				print qq~$top_block_separator~;
			#	$width, $title, $titlecolor, $bgcolor
	        		boxheader(150, "User Status", "#737b9c", "#ffffff");
				userstatus();
				require "$sourcedir/onlinemember.pl";
				view_online_members();
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($itemr[$i] eq "addonsleft") {
				require "$sourcedir/addons.pl";
				addons_blockl();
			}

			if($itemr[$i] eq "language") {
				if ($username ne $anonuser) {
					require "$sourcedir/subs.pl";
					print qq~$top_block_separator~;
					languages_menu();
					print qq~$bottom_block_separator~;
					print "$block_separator";
				}
			}

			if($itemr[$i] eq "addonsmenu") {
				require "$sourcedir/addons.pl";
				addons_menu();
			}

			if($itemr[$i] eq "top10") {
				require "$sourcedir/subs.pl";
				print qq~$top_block_separator~;
				boxheader(150, "Top 10", "#737b9c", "#ffffff");
				print qq~<tr><td class="cat">~;
				top10_block();
				print qq~</td></tr>~;
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($itemr[$i] eq "poll") {
				print qq~$top_block_separator~;
				boxheader(150, "$nav{'041'}", "#737b9c", "#ffffff");
				require "$sourcedir/poll.pl"; poll();
				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}

			if($itemr[$i] eq "addonsright") {
				require "$sourcedir/addons.pl";
				addons_blockr();
			}

			if($itemr[$i] eq "information") {
				print qq~$top_block_separator~;
				boxheader(150, "Information", "#737b9c", "#ffffff");

				print qq~<tr>
					<td align="center" class="cat"><a href="http://www.perl.com/" target="_blank"><img alt="Powered by Perl!" border="0" height="31" src="$imagesurl/pb_perl.gif" width="88"></a></td>
					</tr>
					<tr>
					<td align="center" class="cat"><a href="http://www.gnu.org/" target="_blank"><img alt="Licensed under the GNU GPL!" border="0" height="31" src="$imagesurl/pb_gnugpl.gif" width="88"></a></td>
					</tr>
					<tr>
					<td align="center" class="cat"><a href="http://www.sourceforge.net/" target="_blank"><img alt="Hosted by Sourceforge!" border="0" height="31" src="http://sourceforge.net/sflogo.php?group_id=29456" width="88"></a></td>
					</tr>
					~;

				boxfooter();
				print qq~$bottom_block_separator~;
				print "$block_separator";
			}
			
		}
		$i++;
	}
}

##################
sub random_block {
##################

use Pee::FileRunner;

open (RBDAT,"<$datadir/blocks/randomblock.dat");
@rbbuffer=<RBDAT>;
close (RBDAT);

$rblock = @rbbuffer;

$rbroll= int(rand $rblock);
($rbnum, $rbcont, $rbstat) = split('\|',$rbbuffer[$rbroll]);

		open(FILE, ">$datadir/temp/blockrandom$rbroll.tmp") || error ("Unable to create $datadir/temp/blockrandom$rbroll.tmp temp file");
		lock (FILE);
		print FILE $rbcont;
		unlock (FILE);
		close(FILE);

		

print qq~<table border=0 width="100%" height="100%"><tr><td>~;

			if (!$runner->compile()) {
  				print "Error compiling template: $datadir/temp/blockrandom$rbroll.tmp\n";
  				print "<br>$runner->{errmsg}\n";
			}

			if (!$runner->run('main')) {
  				print "<p>Error running template: $datadir/temp/blockrandom$rbroll.tmp\n";
  				print "<br>$runner->{errmsg}\n";
			}	

print qq~</td></tr></table>~;

unlink("$datadir/temp/blockrandom$rbroll.tmp");
}

#######################
sub check_rb_setting {
#######################

	open(FILERB, "$datadir/banners/rbsetting.dat");
	chomp(@setrb = <FILERB>);
	close(FILERB);

	foreach $linerb (@setrb) {
		@itemrb = split(/\|/, $linerb);
		if ($itemrb[0] eq "Top") {
			if ($itemrb[1] eq 1) {
			$top_rb = 1;
			}
			else  {
				$top_rb = 0;
			}
		}
		if ($itemrb[0] eq "Middle") {
			if ($itemrb[1] eq 1) {
			$middle_rb = 1;
			}
			else  {
				$middle_rb = 0;
			}
		}
		if ($itemrb[0] eq "Bottom") {
			if ($itemrb[1] eq 1) {
			$bottom_rb = 1;
			}
			else  {
				$bottom_rb = 0;
			}
		}
	}
}

1;
