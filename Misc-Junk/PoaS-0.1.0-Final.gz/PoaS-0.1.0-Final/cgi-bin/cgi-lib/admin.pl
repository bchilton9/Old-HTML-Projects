##############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# admin.pl - this code handles the admin section based on YaWPS               #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                             #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: admin.pl, Last modified: 22:54 08/28/2002                             #
###############################################################################
###############################################################################


###############
sub siteadmin {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();
	$navbar = "$admin{'btn2'} $nav{'042'}";
	print_top();
	print qq~
<b>$nav{'042'}</b><br>
<a href="$pageurl/$admin&amp;op=siteconfig">$admin{'001'}</a><br>
<a href="$pageurl/$admin&amp;op=welcomemsg">$admin{'002'}</a><br>
<a href="$pageurl/admin/fileman/fileman.cgi">$admin{'004'}</a><br>
<a href="$pageurl/admin/logs/view.cgi">$admin{'005'}</a><br>
<a href="$pageurl/$admin&amp;op=userranks">Edit UserRanks</a><br>
<br>
<b>$admin{'006'}</b><br>
~;
require "$sourcedir/addons.pl";
addons_admin();

print qq~
<br>
<b>$admin{'007'}</b><br>
<a href="$pageurl/$cgi\?action=newautopage">$admin{'008'}</a><br>
<a href="$pageurl/$cgi\?action=removeautopage">$admin{'009'}</a><br>
<br>
<b>$admin{'010'}</b><br>
<a href="$pageurl/$admin&amp;op=banneradmin\&command=view">$admin{'011'}</a><br>
<a href="$pageurl/$admin&amp;op=banneradmin\&command=pview">$admin{'012'}</a><br>
<br>
<b>$admin{'013'}</b><br>
<a href="$pageurl/$admin&amp;op=blockadmin\&command=displaylist">Block Listing (Edit Block)</a><br>
<a href="$pageurl/$admin&amp;op=blockadmin\&command=editlist\&blockside=blockleft">Edit Left Block</a><br>
<a href="$pageurl/$admin&amp;op=blockadmin\&command=editlist\&blockside=blockright">Edit Right Block</a><br>
<br>
<b>$nav{'043'}</b><br>
<a href="$pageurl/$admin&amp;op=managecats">$admin{'018'}</a><br>
<a href="$pageurl/$admin&amp;op=manageboards">$admin{'019'}</a><br>
<a href="$pageurl/$admin&amp;op=setcensor">$admin{'020'}</a><br>
<br>
<b>FAQ Administration</b><br>
<a href="$admin&amp;op=fcatadmin">FAQ Category</a><br>
<a href="$admin&amp;op=editfaqs">Edit FAQ</a><br>
<b>$admin{'021'}</b><br>
<br>
<a href="$admin&amp;op=editdownloadcats">$admin{'022'}</a><br>
<a href="$admin&amp;op=editdownloads">$admin{'023'}</a><br>
<a href="$admin&amp;op=brokendadmin">$admin{'broken_download'} </a><br>
<br>
<b>$admin{'024'}</b><br>
<a href="$admin&amp;op=editlinkcats">$admin{'025'}</a><br>
<a href="$admin&amp;op=editlinks">$admin{'026'}</a><br>
<a href="$admin&amp;op=brokenladmin">$admin{'broken_link'}</a><br>
<br>
<b>$nav{'024'}</b><br>
<a href="$pageurl/$admin&amp;op=verifynews">$admin{'027'}</a><br>
<a href="$pageurl/$admin&amp;op=modifynews">$admin{'028'}</a><br>
<a href="$pageurl/$admin&amp;op=topicadmin">$admin{'029'}</a><br>
<br>
<b>$nav{'044'}</b><br>
<a href="$pageurl/$admin&amp;op=polladmin">$admin{'030'}</a><br>
<br>
~;


	print_bottom();
	exit;

}

################
sub siteconfig {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$scriptdir/config.pl") || error("$err{'001'} $scriptdir/config.pl");
	chomp(@config = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'042'} $admin{'btn2'} $admin{'001'}";
	print_top();
	print qq~<form action="$admin&amp;op=siteconfig2" method="post">
<table border="0" width="100%" cellpading="0" cellspacing="0">
<tr>
<td colspan="2"><b>$admin{'031'} :</b></td>
</tr>
<tr>
<td>$admin{'page_name'}</td>
<td><input type="text" name="pagename" value="$pagename" size="30"></td>
</tr>
<tr>
<td>$admin{'page_url'}</td>
<td><input type="text" name="pageurl" value="$pageurl" size="30"></td>
</tr>
<tr>
<td>$admin{'page_title'}</td>
<td><input type="text" name="pagetitle" value="$pagetitle" size="30"></td>
</tr>
<tr>
<td>$admin{'script_filename'}</td>
<td><input type="text" name="cgi" value="$cgi" size="30"></td>
</tr>
<tr>
<td>$admin{'username_cookie'}</td>
<td><input type="text" name="cookieusername" value="$cookieusername" size="30"></td>
</tr>
<tr>
<td>$admin{'password_cookie'}</td>
<td><input type="text" name="cookiepassword" value="$cookiepassword" size="30"></td>
</tr>
<tr>
<td>$admin{'theme_cookie'}</td>
<td><input type="text" name="cookieusertheme" value="$cookieusertheme" size="30"></td>
</tr>
<tr>
<td>$admin{'lang_cookie'}</td>
<td><input type="text" name="cookieuserclang" value="$cookieuserclang" size="30"></td>
</tr>
<tr>
<td>$admin{'mailer_type'}</td>
<td>
<input type="radio" name="mailtype" value="0" ~; 
if ($mailtype eq 0) { print "CHECKED";} print qq~>sendmail
<input type="radio" name="mailtype" value="1" ~;
if ($mailtype eq 1) { print "CHECKED";} print qq~>SMTP
<input type="radio" name="mailtype" value="2" ~;
if ($mailtype eq 2) { print "CHECKED";} print qq~>blatmail
<input type="radio" name="mailtype" value="3" ~;
if ($mailtype eq 3) { print "CHECKED"; } print qq~>Qmail
</td>
</tr>
<tr>
<td>$admin{'path_mailprogram'}</td>
<td><input type="text" name="mailprogram" value="$mailprogram" size="30"></td>
</tr>
<tr>
<td>SMTP-Server</td>
<td><input type="text" name="smtp_server" value="$smtp_server" size="30"></td>
</tr>
<tr>
<td>$admin{'webmaster_email'}</td>
<td><input type="text" name="master_email" value="$master_email" size="30"></td>
</tr>
<tr>
<td>$admin{'path_rootdir'}</td>
<td><input type="text" name="basedir" value="$basedir" size="30"></td>
</tr>
<tr>
<td>$admin{'main_url'}</td>
<td><input type="text" name="baseurl" value="$baseurl" size="30"></td>
</tr>
<tr>
<td>$admin{'main_scripturl'}</td>
<td><input type="text" name="scripturl" value="$scripturl" size="30"></td>
</tr>
<tr>
<td>$admin{'main_scriptdir'}</td>
<td><input type="text" name="scriptdir" value="$scriptdir" size="30"></td>
</tr>
<tr>
<td>$admin{'main_scriptsource'}</td>
<td><input type="text" name="sourcedir" value="$sourcedir" size="30"></td>
</tr>
<tr>
<td>$admin{'main_datadir'}</td>
<td><input type="text" name="datadir" value="$datadir" size="30"></td>
</tr>
<tr>
<td>$admin{'members_dir'}</td>
<td><input type="text" name="memberdir" value="$memberdir" size="30"></td>
</tr>
<tr>
<td>$admin{'images_dir'}</td>
<td><input type="text" name="imagesdir" value="$imagesdir" size="30"></td>
</tr>
<tr>
<td>$admin{'themes_dir'}</td>
<td><input type="text" name="themesdir" value="$themesdir" size="30"></td>
</tr>
<tr>
<td>$admin{'images_url'}</td>
<td><input type="text" name="imagesurl" value="$imagesurl" size="30"></td>
</tr>
<tr>
<td>$admin{'themes_url'}</td>
<td><input type="text" name="themesurl" value="$themesurl" size="30"></td>
</tr>
<tr>
<td>$admin{'lang_dir'}</td>
<td><input type="text" name="langsdir" value="$langsdir" size="30"></td>
</tr>
<tr>
<td>$admin{'lang_name'}</td>
<td><input type="text" name="langname" value="$langname" size="30"></td>
</tr>
<tr>
<td>$admin{'banner_display'}</td>
<td><input type="radio" name="showban" value="1" ~; 
if ($showban eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="showban" value="0" ~;
if ($showban eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td colspan="2"><b>$admin{'news_setting'}</b></td>
</tr>
<tr>
<td>$admin{'topics_dir'}</td>
<td><input type="text" name="topicsdir" value="$topicsdir" size="30"></td>
</tr>
<tr>
<td>$admin{'max_news'}</td>
<td><input type="text" maxlength="2" name="maxnews" value="$maxnews" size="1"></td>
</tr>
<tr>
<td>$admin{'max_topics'}</td>
<td><input type="text" maxlength="2" name="maxtopics" value="$maxtopics" size="1"></td>
</tr>
<tr>
<td>$admin{'allow_userpost'}</td>
<td><input type="radio" name="enable_userarticles" value="1" ~; 
if ($enable_userarticles eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="enable_userarticles" value="0" ~;
if ($enable_userarticles eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<td>$admin{'allow_html'}</td>
<td><input type="radio" name="allow_html" value="1" ~; 
if ($allow_html eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="allow_html" value="0" ~;
if ($allow_html eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td colspan="2"><b>$admin{'forum_setting'}</b></td>
</tr>
<tr>
<td>$admin{'forum_dir'}</td>
<td><input type="text" name="boardsdir" value="$boardsdir" size="30"></td>
</tr>
<tr>
<td>$admin{'messages_dir'}</td>
<td><input type="text" name="messagedir" value="$messagedir" size="30"></td>
</tr>
<tr>
<td>$admin{'enable_guestposting'}</td>
<td><input type="radio" name="enable_guestposting" value="1" ~; 
if ($enable_guestposting eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="enable_guestposting" value="0" ~;
if ($enable_guestposting eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td>$admin{'enable_notification'}</td>
<td><input type="radio" name="enable_notification" value="1" ~; 
if ($enable_notification eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="enable_notification" value="0" ~;
if ($enable_notification eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td>$admin{'max_forumtopics'}</td>
<td><input type="text" maxlength="2" name="maxdisplay" value="$maxdisplay" size="1"></td>
</tr>
<tr>
<td>$admin{'max_forummessages'}</td>
<td><input type="text" maxlength="2" name="maxmessagedisplay" value="$maxmessagedisplay" size="1"></td>
</tr>
<tr>
<td>$admin{'insert_original'}</td>
<td><input type="radio" name="insert_original" value="1" ~; 
if ($insert_original eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="insert_original" value="0" ~;
if ($insert_original eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td>$admin{'enable_ubbc'}</td>
<td><input type="radio" name="enable_ubbc" value="1" ~; 
if ($enable_ubbc eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="enable_ubbc" value="0" ~;
if ($enable_ubbc eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td>$admin{'max_agelog'}</td>
<td><input type="text" maxlength="3" name="max_log_days_old" value="$max_log_days_old" size="1"></td>
</tr>
<tr>
<td colspan="2"><b>$admin{'stats_setting'}</b></td>
</tr>
<tr>
<td>$admin{'stats_dir'}</td>
<td><input type="text" name="logdir" value="$logdir" size="30"></td>
</tr>
<tr>
<td>$admin{'time_logging'}</td>
<td><input type="text" maxlength="3" name="ip_time" value="$ip_time" size="1"></td>
</tr>
<tr>
<td>$admin{'show_topbrowser'}</td>
<td><input type="radio" name="top_browsers" value="1" ~; 
if ($top_browsers eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="top_browsers" value="0" ~;
if ($top_browsers eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td>$admin{'show_topos'}</td>
<td><input type="radio" name="top_os" value="1" ~; 
if ($top_os eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="top_os" value="0" ~;
if ($top_os eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td colspan="2"><b>$admin{'link_setting'} </b></td>
</tr>
<tr>
<td>$admin{'links_dir'}</td>
<td><input type="text" name="linksdir" value="$linksdir" size="30"></td>
</tr>
<tr>
<td>$admin{'max_link'}</td>
<td><input type="text" maxlength="2" name="maxlinks" value="$maxlinks" size="1"></td>
</tr>
<tr>
<td colspan="2"><b>$admin{'download_setting'}</b></td>
</tr>
<tr>
<td>$admin{'download_dir'}</td>
<td><input type="text" name="downloadsdir" value="$downloadsdir" size="30"></td>
</tr>
<tr>
<td>$admin{'max_download'}</td>
<td><input type="text" maxlength="2" name="maxdownloads" value="$maxdownloads" size="1"></td>
</tr>
<tr>
<td colspan="2"><b>$admin{'fileman_setting'}</b></td>
</tr>
<tr>
<td>$admin{'max_webspace'}</td>
<td><input type="text" name="awebspace" value="$awebspace" size="30"></td>
</tr>
<tr>
<td>$admin{'max_upload'}</td>
<td><input type="text" name="maxufile" value="$maxufile" size="10"></td>
</tr>
<tr>
<td>$admin{'give_webspace'}</td>
<td><input type="radio" name="giveuserspace" value="1" ~; 
if ($giveuserspace eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="giveuserspace" value="0" ~;
if ($giveuserspace eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td>$admin{'path_userspace'}</td>
<td><input type="text" name="userspacedir" value="$userspacedir" size="10"></td>
</tr>
<tr>
<td>$admin{'user_webpace'}</td>
<td><input type="text" name="userwebspace" value="$userwebspace" size="10"></td>
</tr>
<tr>
<td>$admin{'max_userupload'}</td>
<td><input type="text" name="usermaxufile" value="$usermaxufile" size="10"></td>
</tr>
<tr>
<td>$admin{'user_url'}</td>
<td><input type="text" name="userurl" value="$userurl" size="10"></td>
</tr>
<tr>
<td colspan="2"><b>FAQ Settings</b></td>
</tr>
<tr>
<td>FAQ directory path</td>
<td><input type="text" size="10" name="faqsdir" value="$faqsdir"></td>
</tr>
<tr>
<td>Max FAQ</td>
<td><input type="text" size="10" name="maxfaqs" value="$maxfaqs"></td>
</tr>
<tr>
<td colspan="2"><b>$admin{'other_setting'}</b></td>
</tr>
<tr>
<td>Admin IP</td>
<td><input type="text" maxlength="2" name="admin_ip" value="$admin_ip" size="1"></td>
</tr>
<tr>
<td>$admin{'time_difference'}</td>
<td><input type="text" maxlength="2" name="timeoffset" value="$timeoffset" size="1"></td>
</tr>
<tr>
<td>$admin{'max_height_pic'}</td>
<td><input type="text" maxlength="3" name="memberpic_height" value="$memberpic_height" size="1"></td>
</tr>
<tr>
<td>$admin{'max_width_pic'}</td>
<td><input type="text" maxlength="3" name="memberpic_width" value="$memberpic_width" size="1"></td>
</tr>
<tr>
<td>$admin{'file_locking'}</td>
<td><input type="radio" name="use_flock" value="1" ~; 
if ($use_flock eq 1) { print "CHECKED";} print qq~>$admin{'yes'}
<input type="radio" name="use_flock" value="0" ~;
if ($use_flock eq 0) { print "CHECKED";} print qq~>$admin{'no'}
</td>
</tr>
<tr>
<td>$admin{'lock_ex'}</td>
<td><input type="text" maxlength="2" name="LOCK_EX" value="$LOCK_EX" size="1"></td>
</tr>
<tr>
<td>$admin{'lock_un'}</td>
<td><input type="text" maxlength="2" name="LOCK_UN" value="$LOCK_UN" size="1"></td>
</tr>
<tr>
<td>$admin{'iis'}</td>
<td><input type="text" maxlength="1" name="IIS" value="$IIS" size="1"> <small>$admin{'iis1'}</small></td>
</tr>
<tr>
<td align="center" colspan="2"><input type="submit" value="$admin{'065'}"></td>
</tr>
</table>
</form>
~;
	print_bottom();
	exit;
}

#################
sub siteconfig2 {
#################
check_user_permission();
	open(FILE, ">$scriptdir/config.pl") || error("$err{'016'} $scriptdir/config.pl");
	lock(FILE);
	print FILE qq~###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# config.pl - the main config file based on YaWPS                             #
#                                                                             #
# Copyright (C) 2002 by Luckie (perl_oas\@yahoo.com)                         #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: config.pl, Last modified: $date                                       #
###############################################################################
###############################################################################


##################
# General Settings
##################
\$pagename = "$input{'pagename'}";
\$pageurl = "$input{'pageurl'}";
\$pagetitle = "$input{'pagetitle'}";

\$cgi = "$input{'cgi'}";
\$cookieusername = "$input{'cookieusername'}";
\$cookiepassword = "$input{'cookiepassword'}";
\$cookieusertheme = "$input{'cookieusertheme'}";
\$cookieuserclang = "$input{'cookieuserclang'}";

\$mailtype = "$input{'mailtype'}";
\$mailprogram = "$input{'mailprogram'}";
\$smtp_server =  "$input{'smtp_server'}";
\$master_email = '$input{'master_email'}';

\$basedir   = "$input{'basedir'}";
\$baseurl   = "$input{'baseurl'}";
\$scriptdir = "$input{'scriptdir'}";
\$scripturl = "$input{'scripturl'}";
\$sourcedir = "$input{'sourcedir'}";
\$datadir   = "$input{'datadir'}";
\$memberdir = "$input{'memberdir'}";
\$imagesdir = "$input{'imagesdir'}";
\$themesdir = "$input{'themesdir'}";

\$imagesurl = "$input{'imagesurl'}";
\$themesurl = "$input{'themesurl'}";

\$langsdir  = "$input{'langsdir'}";
\$langname  = "$input{'langname'}";
\$lang 	    = "$langsdir/$langname";

\$showban = "$input{'showban'}";

########################
# News Specific Settings
########################
\$topicsdir = "$input{'topicsdir'}";
\$maxnews = $input{'maxnews'};
\$maxtopics = $input{'maxtopics'};
\$enable_userarticles = $input{'enable_userarticles'};
\$allow_html = $input{'allow_html'};

##########################
# Forums Specific Settings
##########################
\$boardsdir = "$input{'boardsdir'}";
\$messagedir = "$input{'messagedir'}";

\$enable_guestposting = $input{'enable_guestposting'};
\$enable_notification = $input{'enable_notification'};
\$maxdisplay = $input{'maxdisplay'};
\$maxmessagedisplay = $input{'maxmessagedisplay'};
\$insert_original = $input{'insert_original'};
\$enable_ubbc = $input{'enable_ubbc'};
\$max_log_days_old = $input{'max_log_days_old'};

#########################
# Stats Specific Settings
#########################
\$logdir = "$input{'logdir'}";

\$ip_time = 5;

\$top_browsers = $input{'top_browsers'};
\$top_os = $input{'top_os'};

#########################
# Links Specific Settings
#########################
\$linksdir = "$input{'linksdir'}";
\$maxlinks = "$input{'maxlinks'}";

#########################
# Downloads Specific Settings
#########################
\$downloadsdir = "$input{'downloadsdir'}";
\$maxdownloads = "$input{'maxdownloads'}";

################################
# File Manager Specific Settings
################################
\$awebspace = "$input{'awebspace'}";
\$maxufile = "$input{'maxufile'}";
\$giveuserspace = "$input{'giveuserspace'}";
\$userspacedir = "$input{'userspacedir'}";
\$userwebspace = "$input{'userwebspace'}";
\$usermaxufile = "$input{'usermaxufile'}";
\$userurl   = "$input{'userurl'}";

########################
# FAQ Specific Settings
########################
\$faqsdir = "$input{'faqsdir'}";
\$maxfaqs = "$input{'maxfaqs'}";

################
# Other Settings
################
\$admin_ip = "$input{'admin_ip'}";
\$timeoffset = $input{'timeoffset'};

\$memberpic_height = $input{'memberpic_height'}; 
\$memberpic_width = $input{'memberpic_width'};

\$use_flock = $input{'use_flock'};
\$LOCK_EX = $input{'LOCK_EX'};
\$LOCK_UN = $input{'LOCK_UN'};

\$IIS =  $input{'IIS'};

1; #return true
~;
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin\&op=siteconfig\n\n";
	exit;
}

################
sub welcomemsg {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/welcomemsg.txt") || error("$err{'001'} $datadir/welcomemsg.txt");
	chomp(@lines = <FILE>);
	close(FILE);

	$subject = htmltotext($lines[0]);
	$message = $lines[1];

	$navbar = "$admin{'btn2'} $nav{'042'} $admin{'btn2'} $admin{'032'}";
	print_top();
	print qq~<form action="$pageurl/$admin&amp;op=welcomemsg2" method="post">
<table border="0" width="100%" cellpading="0" cellspacing="0">
<tr>
<td>
$admin{'033'} :<br>
<input type="text" name="subject" value="$subject" size="40">
</td>
</tr>
<tr>
<td>
$admin{'034'} :<br>
<textarea name="message" cols="40" rows="10">$message</textarea>
</td>
</tr>
<tr>
<td><input type="submit" value="Save"><input type="reset" value="Reset"></td>
</tr>
</table>
</form>
~;
	print_bottom();
	exit;
}

#################
sub welcomemsg2 {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();
	error("$err{'014'}") unless ($input{'subject'});
	error("$err{'015'}") unless ($input{'message'});

	chomp($input{'subject'});
	chomp($input{'message'});

	$subject = htmlescape($input{'subject'});
	$message = $input{'message'};

	open(FILE, ">$datadir/welcomemsg.txt") || error("$err{'016'} $datadir/welcomemsg.txt");
	lock(FILE);
	print FILE "$subject\n";
	print FILE "$message\n";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin\&op=welcomemsg\n\n";
}

################
sub managecats {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$boardsdir/cats.txt") || error("$err{'001'} $boardsdir/cats.txt");
	chomp(@categories = <FILE>);
	close(FILE);

	$catsdropdown = "";
	$catlist = "";
	foreach $curcat (@categories) {
		$catsdropdown = "$catsdropdown<option>$curcat</option>";
		$catlist = "$catlist\n$curcat";
	}

	$navbar = "$admin{'btn2'} $nav{'043'} $admin{'btn2'} $admin{'035'}";

	print_top();
	print qq~<table border="0" width="100%" cellpading="0" cellspacing="0">
<tr>
<td valign="top">
<form action="$admin&amp;op=reordercats" method="post">
<b>$admin{'036'} :</b><br>
<textarea name="cats" cols="40" rows="4">$catlist</textarea><br>
<input type="submit" value="$admin{'037'}">
</form>
<form action="$pageurl/$admin&amp;op=removecat" method="post">
<b>$admin{'038'} :</b><br>
<select name="cat">
$catsdropdown
</select>
<input type=submit value="$admin{'039'}">
</form>
<form action="$pageurl/$admin&amp;op=createcat" method="post">
<b>$admin{'040'} :</b><br>
ID:<br>
<input type="text" size="15" name="catid"><br>
$admin{'041'} :<br>
<input type="text" size="40" name="catname"><br>
$admin{'042'} :<br>
<input type="text" size="40" name="memgroup"><br>
$admin{'043'}<br>
<input type="submit" value="$admin{'044'}">
</form>
</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

#################
sub reordercats {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	$input{'cats'} =~ s/\r//g;
	open(FILE, ">$boardsdir/cats.txt") || error("$err{'016'} $boardsdir/cats.txt");
	lock(FILE);
	print FILE "$input{'cats'}";
	unlock(FILE);
	close(FILE);
	print "Location: $pageurl/$admin\&op=managecats\n\n";
	exit;
}

###############
sub removecat {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$boardsdir/cats.txt") || error("$err{'001'} $boardsdir/cats.txt");
	chomp(@categories = <FILE>);
	close(FILE);

	$newcatlist = "";
	foreach $curcat (@categories) {
		if ($curcat ne "$input{'cat'}") { $newcatlist = "$newcatlist$curcat\n"; }
	}

	open(FILE, ">$boardsdir/cats.txt") || error("$err{'016'} $boardsdir/cats.txt");
	lock(FILE);
	print FILE "$newcatlist";
	unlock(FILE);
	close(FILE);

	$curcat = "$input{'cat'}";
	
	open(FILE, "$boardsdir/$curcat.cat") || error("$err{'001'} $boardsdir/$curcat.cat");
	chomp(@catinfo = <CAT>);
	close(CAT);

	$curcatname = "$catinfo[0]";

	$navbar = "$admin{'btn2'} $nav{'043'} $admin{'btn2'} $admin{'045'}";
	print_top();

	foreach $curboard (@catinfo) {
		if ($curboard ne "$catinfo[0]") {
			open(BOARDDATA, "$boardsdir/$curboard.txt");
			@messages = <BOARDDATA>;
			close(BOARDDATA);

			foreach $curmessage (@messages) {
				($id, $dummy) = split(/\|/, $curmessage);
				unlink("$messagedir/$id\.txt");
				unlink("$messagedir/$id\.mail");
				print "$admin{'046'} $id...<br>";
			}
		}
		unlink("$boardsdir/$curboard.txt");
		unlink("$boardsdir/$curboard.mail");
		unlink("$boardsdir/$curboard.dat");
		print "$admin{'047'}<br>";
	}
	print "$admin{'048'}<br>";
	unlink("$boardsdir/$curcat.cat");
	print "$admin{'049'}";
	print_bottom();
	exit;
}

###############
sub createcat {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	$catid = "$input{'catid'}";

	open(FILE, "$boardsdir/cats.txt") || error("$err{'001'} $boardsdir/cats.txt");
	chomp(@categories = <FILE>);
	close(FILE);

	open(FILE, ">$boardsdir/cats.txt") || error("$err{'016'} $boardsdir/cats.txt");
	lock(FILE);
	foreach $curcat (@categories) {
		print FILE "$curcat\n";
	}
	print FILE "$catid";
	unlock(FILE);
	close(FILE);

	open(FILE, ">$boardsdir/$catid.cat");
	lock(FILE);
	print FILE "$input{'catname'}\n";
	print FILE "$input{'memgroup'}\n";
	unlock(FILE);
	close(FILE);
	print "Location: $pageurl/$admin\&op=managecats\n\n";
	exit;
}

##################
sub manageboards {
##################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$boardsdir/cats.txt") || error("$err{'001'} $boardsdir/cats.txt");
	chomp(@categories = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'043'} $admin{'btn2'} $admin{'050'}";
	print_top();

	print qq~<table border="0" cellspacing="1">
<tr>
<td><b>$admin{'051'}</b></td>
<td><b>$admin{'052'}</b></td>
<td><b>$admin{'053'}</b></td>
</tr>
~;
	foreach $curcat (@categories) {
		open(CAT, "$boardsdir/$curcat.cat");
		chomp(@catinfo = <CAT>);
		close(CAT);

		$curcatname = "$catinfo[0]";

		print qq~<tr>
<td colspan="3"><a href="$pageurl/$admin&amp;op=reorderboards&cat=$curcat"><b>$curcatname</b></a></td>
</tr>
~;
		foreach $curboard (@catinfo) {
			if ($curboard ne "$catinfo[0]" && $curboard ne "$catinfo[1]") {
				open(BOARD, "$boardsdir/$curboard.dat");
				@boardinfo = <BOARD>;
				close(BOARD);

				$curboardname = "$boardinfo[0]";
				$descr = "$boardinfo[1]";

				open(BOARDDATA, "$boardsdir/$curboard.txt");
				@messages = <BOARDDATA>;
				close(BOARDDATA);

				$moderator = "$modprop[1]";

				print qq~<tr>
<td valign="top"><form action="$pageurl/$admin&amp;op=modifyboard" method="post">
<input type="hidden" name="id" value="$curboard">
<input type="hidden" name="cat" value="$curcat">
<input type="text" name="boardname" value="$curboardname" size="20"><br>
<textarea name="descr" cols="30" rows="3">$descr</textarea>
</td>
<td valign="top"><input type=text name="moderator" value="$boardinfo[2]" size="10"></td>
<td valign="top">
<input type="submit" name="moda" value="$admin{'054'}">
<input type="submit" name="moda" value="$admin{'055'}">
</form>
</td>
</tr>
~;
			}
		}
		print qq~<tr>
<td colspan="3"><hr size="1"></td>
</tr>
<tr>
<td valign="top"><form action="$pageurl/$admin&amp;op=createboard" method="post">
<table>
<tr>
<td>ID:</td>
<td><input type="text" name="id" value="" size="15"></td>
</tr>
<tr>
<td>$admin{'056'} :</td>
<td><input type="text" name="boardname" size="20"></td>
</tr>
<tr>
<td colspan="2">$admin{'057'} :<br>
<textarea name="descr" cols="30" rows="3"></textarea></td>
</tr>
</table>
</td>
<td valign="top"><input type="text" name="moderator" value="" size="10"><input type="hidden" name="cat" value="$curcat"></td>
<td valign="top"><input type="submit" value="$admin{'058'}">
</form>
</td>
</tr>
~;
	}
	print "</table>";
	print_bottom();
	exit;
}

###################
sub reorderboards {
###################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$boardsdir/$info{'cat'}.cat") || error("$err{'001'} $boardsdir/$info{'cat'}.cat");
	chomp(@allboards = <FILE>);
	close(FILE);

	$boardlist = "";
	foreach $cboard (@allboards) {
		if ($cboard ne "$allboards[0]" && $cboard ne "$allboards[1]") { $boardlist = "$boardlist\n$cboard"; }
	}

	$navbar = "$admin{'btn2'} $nav{'043'} $admin{'btn2'} $admin{'050'} $admin{'btn2'} $admin{'059'}";

	print_top();
	print qq~<table border="0" width="100%" cellpading="0" cellspacing="0">
<tr>
<td valign="top"><form action="$pageurl/$admin&amp;op=reorderboards2" method="post">
<b>$admin{'060'} :</b><br>
<textarea name="boards" cols="30" rows="4">$boardlist</textarea><br>
<input type="hidden" name="firstline" value="$allboards[0]">
<input type="hidden" name="secondline" value="$allboards[1]">
<input type="hidden" name="cat" value="$info{'cat'}">
<input type="submit" value="$admin{'061'}">
</form>
</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

####################
sub reorderboards2 {
####################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	$input{'boards'} =~ s/\r//g;
	$input{'firstline'} =~ s/\n//g;
	$input{'secondline'} =~ s/\n//g;

	open(FILE, ">$boardsdir/$input{'cat'}.cat") || error("$err{'016'} $boardsdir/$input{'cat'}.cat");
	lock(FILE);
	print FILE "$input{'firstline'}\n";
	print FILE "$input{'secondline'}\n";
	print FILE "$input{'boards'}";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin\&op=reorderboards\&cat=$input{'cat'}\n\n";
	exit;
}

#################
sub modifyboard {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
require "$sorcedir/security.pl";
	check_user_permission();
	check_hash($input{'id'});

	if ($input{'moda'} eq "Modify") {
		$input{'descr'} =~ s/\n/ /g;
		$input{'descr'} =~ s/\r//g;

		open(FILE, ">$boardsdir/$input{'id'}.dat");
		lock(FILE);
		print FILE "$input{'boardname'}\n";
		print FILE "$input{'descr'}\n";
		print FILE "$input{'moderator'}\n";
		unlock(FILE);
		close(FILE);

		print "Location: $pageurl/$admin\&op=manageboards\n\n";
	}
	else {
		open(FILE, "$boardsdir/$input{'cat'}.cat");
		@categories = <FILE>;
		close(FILE);

		$newcatlist="";
		foreach $curboard (@categories) {
			$curboard =~ s/\n//g;
			if($curboard ne "$input{'id'}") { $newcatlist="$newcatlist$curboard\n"; }
		}
		open(FILE, ">$boardsdir/$input{'cat'}.cat");
		lock(FILE);
		print FILE "$newcatlist";
		unlock(FILE);
		close(FILE);
	
		$curboard="$input{'id'}";
		open(BOARDDATA, "$boardsdir/$curboard.txt");
		chomp(@messages = <BOARDDATA>);
		close(BOARDDATA);

		$navbar = "$admin{'btn2'} $nav{'043'} $admin{'btn2'} $admin{'062'}";
		print_top();

		foreach $curmessage (@messages) {
			($id, $dummy) = split(/\|/, $curmessage);
			unlink("$messagedir/$id\.txt");
			unlink("$messagedir/$id\.mail");
			print "$admin{'046'} $id...<br>";
		}
		print "$admin{'047'} ...<br>";
		unlink("$boardsdir/$curboard.dat");
		unlink("$boardsdir/$curboard.txt");
		print "$admin{'049'}";
		print_bottom();
	}
	exit;
}

#################
sub createboard {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($input{'id'});

	$id = "$input{'id'}";
	$input{'descr'} =~ s/\n/ /g;
	$input{'descr'} =~ s/\r//g;
	if ($input{'moderator'} eq "") { $input{'moderator'} eq "admin"; }

	open(FILE, "$boardsdir/$input{'cat'}.cat");
	chomp(@categories = <FILE>);
	close(FILE);

	open(FILE, ">$boardsdir/$input{'cat'}.cat");
	lock(FILE);
	foreach $curboard (@categories) {
		print FILE "$curboard\n";
	}
	print FILE "$id";
	unlock(FILE);
	close(FILE);

	open(FILE, ">$boardsdir/$id.dat");
	lock(FILE);
	print FILE "$input{'boardname'}\n";
	print FILE "$input{'descr'}\n";
	print FILE "$input{'moderator'}\n";
	unlock(FILE);
	close(FILE);

	open(FILE, ">$boardsdir/$id.txt");
	lock(FILE);
	print FILE "";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin\&op=manageboards\n\n";
	exit;
}

###############
sub setcensor {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$boardsdir/censor.txt") || error("$err{'001'} $boardsdir/censor.txt");
	@censored = <FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'043'} $admin{'btn2'} $admin{'063'}";

	print_top();

	print qq~<table border="0" width="100%" cellpading="0" cellspacing="0">
<tr>
<td><form action="$pageurl/$admin&amp;op=setcensor2" method="post">
$admin{'064'}<br>
<textarea cols="30" rows="6" name="censored">
~;
	foreach $cur (@censored) {
		print "$cur";
	}

	print qq~</textarea><br>
<input type="submit" value="$admin{'065'}">
</form>
</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

################
sub setcensor2 {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, ">$boardsdir/censor.txt") || error("$err{'016'} $boardsdir/censor.txt");
	lock(FILE);
	print FILE "$input{'censored'}";
	unlock(FILE);
	close(FILE);
	print "Location: $admin\&op=setcensor\n\n";
	exit;
}

###############
sub polladmin {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	@data = <FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} $admin{'066'}";
	print_top();

	if (@data == 0) { }
	else {
		print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg"><b>$admin{'067'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'068'}</b></td>
~;
		foreach $line (@data) {
			@item = split(/\|/, $line);
			print qq~<tr>
<td bgcolor="$windowbg2"><a href="$pageurl/$cgi?action=pollit2&amp;id=$item[$0]">$item[1]</a></td>
<td bgcolor="$windowbg2">[<a href="$pageurl/$admin&amp;op=editpoll&amp;id=$item[$0]">$admin{'069'}</a>] [<a href="$admin&amp;op=deletepoll&amp;id=$item[$0]">$admin{'070'}</a>] [<a href="$admin&amp;op=resetpoll&amp;id=$item[$0]">$admin{'071'}</a>]</td>
</tr>
~;
		}
		print qq~</table>
</td>
</tr>
</table>
<br><br>
~;
	}
	($num, $name) = split(/\|/, $data[0]);
	$num++;

	print qq~<a href="$pageurl/$admin&amp;op=createpoll&amp;newid=$num"><b>$admin{'072'}</b></a>~;
	print_bottom();
	exit;

}

################
sub createpoll {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	@polls = <FILE>;
	close(FILE);

	open(FILE, ">$datadir/polls/polls.txt") || error("$err{'016'} $datadir/polls/polls.txt");
	lock(FILE);
	print FILE "$info{'newid'}|Welcome to the Pollbooth\n";
	print FILE @polls;
	unlock(FILE);
	close(FILE);


	open(FILE, ">$datadir/polls/$info{'newid'}_q.dat") || error("$err{'016'} $datadir/polls/$info{'newid'}_q.dat");
	lock(FILE);
	print FILE "Option 1\n";
	unlock(FILE);
	close(FILE);

	open(FILE, ">$datadir/polls/$info{'newid'}_a.dat") || error("$err{'016'} $datadir/polls/$info{'newid'}_a.dat");
	lock(FILE);
	print FILE "0\n";
	unlock(FILE);
	close(FILE);

	open(FILE, ">$datadir/polls/$info{'newid'}_ip.dat") || error("$err{'016'} $datadir/polls/$info{'newid'}_ip.dat");
	lock(FILE);
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin\&op=editpoll\&id=$info{'newid'}\n\n";
}

##############
sub editpoll {
##############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	chomp(@polls = <FILE>);
	close(FILE);

	for ($x = 0; $x < @polls; $x++) {
		($id, $name) = split(/\|/, $polls[$x]);
		if ($info{'id'} == $id) { $question = $name; }
	}

	open(FILE, "$datadir/polls/$info{'id'}_q.dat") || error("$err{'001'} $datadir/polls/$info{'id'}_q.dat!");
	@data = <FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} $admin{'066'} $admin{'btn2'} $admin{'073'}";
	print_top();
	print qq~<table>
<form action="$pageurl/$admin&amp;op=editpoll2" method="post">
<tr>
<td>$admin{'074'} :</td>
<td><input type="text" name="question" size="40" value="$question"></td>
<td><input type="hidden" name="id" value="$info{'id'}">
<input type="submit" name="moda" value="$btn{'015'}"></td>
</tr>
</form>
~;
	for ($i = 0; $i < @data; $i++) {
		print qq~<form action="$pageurl/$admin&amp;op=editpoll2a" method="post">
<tr>
<td>$admin{'075'} $i:</td>
<td><input type="text" name="answer" size="40" value="$data[$i]"></td>
<td><input type="hidden" name="id" value="$info{'id'}">
<input type="hidden" name="num" value="$i">
<input type="submit" name="moda" value="$btn{'015'}"><input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
</form>
~;
	}
	print qq~</table>
</form>
<hr size="1">
<form action="$pageurl/$admin&amp;op=editpoll3" method="post">
<table>
<tr>
<td>$admin{'076'} : <input type="text" name="newanswer" size="40">
<input type="hidden" name="id" value="$info{'id'}">
<input type="submit" name="moda" value="$admin{'058'}"></td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

###############
sub editpoll2 {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	@polls = <FILE>;
	close(FILE);

	open(FILE, ">$datadir/polls/polls.txt") || error("$err{'016'} $datadir/polls/polls.txt!");
	lock(FILE);
	for ($i = 0; $i < @polls; $i++) {
		($id, $name) = split(/\|/, $polls[$i]);
		if ($input{'id'} eq $id) { print FILE "$id|$input{'question'}\n"; }
		else { print FILE "$polls[$i]"; }
	}
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin\&op=editpoll\&id=$input{'id'}\n\n";
}

################
sub editpoll2a {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/$input{'id'}_q.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_q.dat!");
	@questions = <FILE>;
	close(FILE);

	open(FILE, "$datadir/polls/$input{'id'}_a.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_a.dat!");
	@answers = <FILE>;
	close(FILE);

	if ($input{'moda'} eq $btn{'016'}) {
		open(FILE, ">$datadir/polls/$input{'id'}_q.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_q.dat!");
		lock(FILE);
		for ($i = 0; $i < @questions; $i++) {
			if ($input{'num'} eq $i) { }
			else { print FILE "$questions[$i]"; }
		}
		unlock(FILE);
		close(FILE);

		open(FILE, ">$datadir/polls/$input{'id'}_a.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_a.dat!");
		lock(FILE);
		for ($i = 0; $i < @answers; $i++) {
			if ($input{'num'} eq $i) { }
			else { print FILE "$answers[$i]"; }
		}
		unlock(FILE);
		close(FILE);
	}
	else {
		open(FILE, ">$datadir/polls/$input{'id'}_q.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_q.dat!");
		lock(FILE);
		for ($i = 0; $i < @questions; $i++) {
			if ($input{'num'} eq $i) { print FILE "$input{'answer'}\n"; }
			else { print FILE "$questions[$i]"; }
		}
		unlock(FILE);
		close(FILE);
	}

	print "Location: $pageurl/$admin\&op=editpoll\&id=$input{'id'}\n\n";
}

###############
sub editpoll3 {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/$input{'id'}_q.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_q.dat!");
	@questions = <FILE>;
	close(FILE);

	open (FILE, ">$datadir/polls/$input{'id'}_q.dat") || error("$err{'016'} $datadir/polls/$input{'id'}_q.dat!");
	lock(FILE);
	print FILE @questions;
	print FILE "$input{'newanswer'}\n";
	unlock(FILE);
	close(FILE);

	open(FILE, "$datadir/polls/$input{'id'}_a.dat") || error("$err{'001'} $datadir/polls/$input{'id'}_a.dat!");
	@answers = <FILE>;
	close(FILE);

	open (FILE, ">$datadir/polls/$input{'id'}_a.dat") || error("$err{'016'} $datadir/polls/$input{'id'}_a.dat!");
	lock(FILE);
	print FILE @answers;
	print FILE "0\n";
	unlock(FILE);
	close(FILE);


	print "Location: $pageurl/$admin\&op=editpoll\&id=$input{'id'}\n\n";
}

###############
sub resetpoll {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/$info{'id'}_a.dat") || error("$err{'001'} $datadir/polls/$info{'id'}_a.dat!");
	chomp(@answers = <FILE>);
	close(FILE);

	open (FILE, ">$datadir/polls/$info{'id'}_a.dat") || error("$err{'016'} $datadir/polls/$info{'id'}_a.dat!");
	lock(FILE);
	foreach $line (@answers) { print FILE "0\n"; }
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin\&op=polladmin\n\n";
}

################
sub deletepoll {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	chomp(@polls = <FILE>);
	close(FILE);

	open(FILE, ">$datadir/polls/polls.txt") || error("$err{'001'} $datadir/polls/polls.txt");
	lock(FILE);
	for ($x = 0; $x < @polls; $x++) {
		($id, $name) = split(/\|/, $polls[$x]);
		if ($info{'id'} == $id) { }
		else { print FILE "$polls[$x]\n"; }
	}
	unlock(FILE);
	close(FILE);

	unlink("$datadir/polls/$info{'id'}_q.dat");
	unlink("$datadir/polls/$info{'id'}_a.dat");
	unlink("$datadir/polls/$info{'id'}_ip.dat");

	print "Location: $pageurl/$admin\&op=polladmin\n\n";
}

################
sub verifynews {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(TMPDATA, "<$topicsdir/newarticles.dat");
	chomp(@tmpdatas = <TMPDATA>);
	close(TMPDATA);

	open(FILE, "$topicsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);


	for ($a = 0; $a < @tmpdatas; $a++) {
		($id[$a], $cat[$a], $subject[$a], $nick[$a], $postername[$a], $email[$a], $postdate[$a], $message[$a], $showfp[$a]) = split(/\|/, $tmpdatas[$a]);
	}


	$navbar = "$admin{'btn2'} $nav{'024'} $admin{'btn2'} $admin{'077'}";
	print_top();

	if (@tmpdatas == 0) { print "$msg{'036'}"; }
	else {
		print qq~<table border="0" cellpadding="5" cellspacing="0" width="100%">
<tr>
<td align="center"><b>$msg{'035'}</b></td>
</tr>
</table>
~;
		if ($info{'start'} eq "") { $start = 0; }
		else { $start = "$info{'start'}"; }

		$numshown = 0;
		for ($b = 0; $b < @tmpdatas; $b++) {
			$numshown++;
			$catsdropdown[$b] = "";
			foreach $catslist (@cats) {
				chomp($catslist);
				($name, $link) = split(/\|/, $catslist);
				if ($cat[$b] eq $link) { $sel[$b] = " selected"; }
				else { $sel[$b] = ""; }
				$catsdropdown[$b] = qq~$catsdropdown[$b]\n<option value="$link" $sel[$b]>$name~;
			}

			$message[$b] = htmltotext($message[$b]);

			print qq~<form action="$pageurl/$admin&amp;op=verifynews2" method="post">
<hr noshade="noshade" size="1">
<table>
<tr>
<td colspan="2"><b>$admin{'078'} $postdate[$b]:</b><input type="hidden" name="postdate" value="$postdate[$b]"></td>
</tr>
<tr>
<td>$msg{'013'}</td>
<td>$nick[$b]<input type="hidden" name="posternick" value="$nick[$b]"></td>
</tr>
<tr>
<td>$msg{'007'}</td>
<td>$email[$b]<input type="hidden" name="posteremail" value="$email[$b]"></td>
</tr>
<tr>
<td>$msg{'034'}</td>
<td>
<select name="cat">$catsdropdown[$b]
</select>
</td>
</tr>
<td>$msg{'037'}</td>
<td><input type="text" name="subject" size="40" maxlength="50" value="$subject[$b]"></td>
</tr>
<tr>
<td valign="top">$msg{'038'}</td>
<td>Show in Front Page = $showfp[$b]<br>
<textarea name="message" rows="10" cols="40">$message[$b]</textarea><br>
</td>
</tr>
<td colspan="2" align="center">
<input type="hidden" value="$id[$b]" name="id">
<input type="hidden" name="postername" value="$postername[$b]">
<input type="hidden" name="showfp" value="$showfp[$b]">
<input type="submit" name="moda" value="$btn{'010'}"><input type="submit" name="moda" value="$btn{'011'}">
</td>
</tr>
</table>
</form>
~;
			if ($numshown >= $maxtopics) { $b = @tmpdatas; }
		}
		if ($numshown >= $maxtopics) {
			print qq~<hr noshade="noshade" size="1">
$msg{'039'} 
~;
			$numcontribs = @tmpdatas;
			$c = 0;
			while (($c*$maxtopics) < $numcontribs) {
				$viewc = $c+1;
				$strt = ($c*$maxtopics);
				if ($start == $strt) { print "$viewc "; }
				elsif ($strt == 0) { print qq~<a href="$pageurl/$admin&amp;op=verifynews">$viewc</a> ~; }
				else { print qq~<a href="$pageurl/$admin&amp;op=verifynews&amp;start=$strt">$viewc</a> ~; }
				$c++;
			}
		}
	}
	print_bottom();
	exit;
}

#################
sub verifynews2 {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();

	error("$err{'014'}") unless ($input{'subject'});
	error("$err{'015'}") unless ($input{'message'});

	$subj = htmlescape($input{'subject'});
	$mesg = htmlescape($input{'message'});

	if ($input{'moda'} eq "$btn{'010'}") {
		opendir (DIR, "$topicsdir/articles");
		@files = readdir(DIR);
		closedir (DIR);
		@files = grep(/txt/, @files);
		@files = reverse(sort { $a <=> $b } @files);
		$postnum = @files[0];
		$postnum =~ s/.txt//;
		$postnum++;

		open(DATA, "$topicsdir/newarticles.dat") || error("$err{'010'} $topicsdir/newarticles.dat");
		@data = <DATA>;
		close(DATA);

		$a = 0;
		while ($data[$a] ne '') { $a++; }

		$count = $a;
		$id = $count + 1;

		$i = 0;

BLOCKED:	while ($i < $count) {
			($id, $cat, $subject, $posternick, $postername, $posteremail, $postdate, $message) = split(/\|/, $data[$i]);
			if ($id eq $input{'id'}) {
				open(DATA2, "$topicsdir/$input{'cat'}.cat");
				chomp(@data2 = <DATA2>);
				close(DATA2);

				open(DATA2,">$topicsdir/$input{'cat'}.cat");
				lock(DATA2);
				print DATA2 "$postnum|$subj|$input{'posternick'}|$input{'postername'}|$input{'posteremail'}|$date|0\n";
				for ($x = 0; $x < @data2; $x++) {
					($oldnum, $subject, $posternick, $postername, $posteremail, $postdate, $comments) = split(/\|/, $data2[$x]);
					print DATA2 "$oldnum|$subject|$posternick|$postername|$posteremail|$postdate|$comments\n";
					print FILE "$data2[$x]\n";
				}
				unlock(DATA2);
				close(DATA2);

				if ($input{'showfp'} eq "no") { 
					open(FILE, ">$topicsdir/articles/$postnum.dat"); 
					lock (FILE);
					print FILE "0|0|0|0\n";
					unlock(FILE);
					close(FILE);
				}
				else {
					open(FILE, ">$topicsdir/articles/$postnum.dat"); 
					lock (FILE);
					print FILE "1|0|0|0\n";
					unlock(FILE);
					close(FILE);
				}
				open(FILE, ">$topicsdir/articles/$postnum.txt");
				lock(FILE);
				print FILE "$subj|$input{'posternick'}|$input{'postername'}|$input{'posteremail'}|$date|$mesg\n";
				unlock(FILE);
				close(FILE);
			}
			else { }
			$i++;
		}
		open(DATA, ">$topicsdir/newarticles.dat") || error("$err{'016'} $topicsdir/newarticles.dat");
		lock(DATA);
		for ($y = 0; $y < @data; $y++) {
			($id, $cat, $subject, $posternick, $postername, $posteremail, $postdate, $message, $showfp) = split(/\|/,$data[$y]);
			$message =~ s/[\n\r]//g;
			if ($id ne $input{'id'}) {
				print DATA "$data[$y]";
			}
		}
		unlock(DATA);
		close(DATA);

		check_hash($input{'postername'});
		open(MEMBERFILE, "$memberdir/$input{'postername'}.dat") || error("$err{'010'} $memberdir/$input{'postername'}.dat");
		chomp(@memsett = <MEMBERFILE>);
		close(MEMBERFILE);

		$memsett[11]++;

		open(MEMBERFILE, ">$memberdir/$input{'postername'}.dat") || error("$err{'016'} $memberdir/$input{'postername'}.dat");
		lock(MEMBERFILE);
		for ($i = 0; $i < @memsett; $i++) {
			print MEMBERFILE "$memsett[$i]\n";
		}
		unlock(MEMBERFILE);
		close(MEMBERFILE);
	}
	else {
		open(DATA, "<$topicsdir/newarticles.dat") || error("$err{'010'} $topicsdir/newarticles.dat");
		@data = <DATA>;
		close(DATA);

		$a = 0;
		while ($data[$a] ne '') { $a++; }

		$count = $a;
		$i = 0;
		$id = $count +1;

		$z = $count;
		$z--;

		open (DATA,">$topicsdir/newarticles.dat") || error("$err{'016'} $topicsdir/newarticles.dat");
		lock(DATA);
		while ($i < $count) {
			($id, $cat, $subject, $posternick, $postername, $posteremail, $postdate, $message, $showfp) = split(/\|/, $data[$i]);
			if ($id eq $input{'id'}) { }
			else {
				$message =~ s/[\n\r]//g;
				$id = $z;
				print DATA "$id|$cat|$subject|$posternick|$postername|$posteremail|$postdate|$message|$showfp\n";
				$z--;
			}
			$i++;
		}
		unlock(DATA);
		close(DATA);
	}
	print "Location: $pageurl/$admin&op=verifynews\n\n";
}

################
sub modifynews {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	undef @catnames;
	undef @catlinks;

	open(FILE, "$topicsdir/cats.dat") || error("$err{'001'} $topicsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'024'} $admin{'btn2'} $admin{'079'}";
	print_top();
	print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg"><b>ID</b></td>
<td bgcolor="$windowbg"><b>$admin{'080'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'081'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'082'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'083'}</b></td>
~;
	foreach (@cats) {
		@item = split(/\|/, $_);
		push(@catnames, $item[0]);
		push(@catlinks, $item[1]);
	}

	foreach $curcat (@catlinks) {
		if (-e("$topicsdir/$curcat.cat")) {
			foreach (@cats) {
				@item = split(/\|/, $_);
				if ($curcat eq "$item[1]") { $curcatname = "$item[0]"; }
			}

			open(FILE, "$topicsdir/$curcat.cat");
			chomp(@articles = <FILE>);
			close(FILE);

			for ($a = 0; $a < @articles; $a++) {
				($id, $subject, $nick, $poster, $email, $postdate, $comments) = split(/\|/, $articles[$a]);
				if ($second eq "$windowbg3") { $second="$windowbg2"; }
				else { $second="$windowbg3"; }

				print qq~<tr>
<td bgcolor="$second">$id</td>
<td bgcolor="$second"><a href="$pageurl/$admin&amp;op=modifynews2&amp;cat=$curcat&amp;id=$id">$subject</a></td>
<td bgcolor="$second">$curcatname</td>
<td bgcolor="$second">$postdate</td>
<td bgcolor="$second"><a href="mailto:$email">$nick</a></td>
</tr>
~;
			}
		}
	}
			print qq~</table>
</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

#################
sub modifynews2 {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$topicsdir/articles/$info{'id'}.txt") || error("$err{'001'} $topicsdir/articles/$info{'id'}.txt");
	chomp(@articles = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'024'} $admin{'btn2'} $admin{'079'}";
	print_top();
	print qq~<table width="100%">
~;

	for ($a = 0; $a < @articles; $a++) {
		($msub, $mname, $musername, $memail, $mdate, $mmessage) = split(/\|/, $articles[$a]);

		$mmessage = htmltotext($mmessage);

		print qq~<form action="$pageurl/$admin&amp;op=modifynews3" method="post">
<input type="hidden" name="cat" value="$info{'cat'}">
<input type="hidden" name="id" value="$info{'id'}">
<input type="hidden" name="viewnum" value="$a">
<tr>
<td valign="top"><a href="mailto:$memail">$mname</a><br>
$mdate</td>
<td><input type="text" name="subject" value="$msub" size="30"><br>
<textarea name="message" rows="3" cols="30">$mmessage</textarea></td>
<td><input type="submit" name="moda" value="$btn{'015'}"><br>
<input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
<tr>
<td colspan="3"><hr size="1"></td>
</tr>
</form>
~;
	}
	open(FILE, "$topicsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);

	foreach $catslist (@cats) {
		chomp($catslist);
		($name, $link) = split(/\|/, $catslist);
		if ($info{'cat'} eq $link) { $sel = "selected"; }
		else { $sel = ""; }
		$catsdropdown = qq~$catsdropdown\n<option value="$link" $sel>$name~;
	}
	print qq~<form action="$pageurl/$admin&amp;op=movetopic" method="post">
<tr>
<td colspan="3">$admin{'084'} : <select name="tocat">$catsdropdown
</select>
<input type="hidden" name="topic" value="$info{'id'}">
<input type="hidden" name="oldcat" value="$info{'cat'}"><input type="submit" value="$admin{'085'}"></td>
</tr>
</form>
</table>
~;
	print_bottom();
	exit;
}

#################
sub modifynews3 {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$topicsdir/articles/$input{'id'}.txt") || error("$err{'001'} $topicsdir/articles/$input{'id'}.txt");
	@data = <FILE>;
	close(FILE);

	for ($a = 0; $a < @data; $a++) { 
		($msub[$a], $mname[$a], $musername[$a], $museremail[$a], $mdate[$a], $mmessage[$a]) = split(/\|/, $data[$a]);
	}

	$count = $a;
	if ($input{'viewnum'} == 0 && $count > 1 && $input{'moda'} eq $btn{'016'}) { error("$err{'025'}"); }

	open(FILE, ">$topicsdir/articles/$input{'id'}.txt") || error("$err{'016'} $topicsdir/articles/$input{'id'}.txt");
	lock(FILE);
	for ($b = 0; $b < @data; $b++) {
		if ($input{'viewnum'} eq $b) {
			if ($input{'moda'} eq $btn{'015'}) {
				chomp($input{'subject'});
				chomp($input{'message'});

				$subj = htmlescape($input{'subject'});
				$mesg = htmlescape($input{'message'});

				if ($input{'viewnum'} == 0) {
					open(FILE2, "$topicsdir/$input{'cat'}.cat") || error("$err{'001'} $topicsdir/$input{'cat'}.cat");
					@data2 = <FILE2>;
					close(FILE2);

					open(FILE2, ">$topicsdir/$input{'cat'}.cat") || error("$err{'016'} $topicsdir/$input{'cat'}.cat");
					lock(FILE2);
					for ($a = 0; $a < @data2; $a++) {
						($oldnum, $subject, $posternick, $postername, $posteremail, $postdate, $comments) = split(/\|/, $data2[$a]);
						$comments =~ s/[\n\r]//g;
						if ($oldnum eq $input{'id'}) { 
							print FILE2 "$oldnum|$subj|$posternick|$postername|$posteremail|$postdate|$comments\n"; 
						}
						else { print FILE2 "$data2[$a]"; }
					}
					unlock(FILE2);
					close(FILE2);
				}
				print FILE "$subj|$mname[$b]|$musername[$b]|$museremail[$b]|$mdate[$b]|$mesg\n";
			}
			else {
				open (FILE2, "$topicsdir/$input{'cat'}.cat") || error("$err{'001'} $topicsdir/$input{'cat'}.cat");
				@data2 = <FILE2>;
				close (FILE2);

				open (FILE2, ">$topicsdir/$input{'cat'}.cat") || error("$err{'016'} $topicsdir/$input{'cat'}.cat");
				lock(FILE2);
				for ($a = 0; $a < @data2; $a++) {
					($oldnum, $subject, $posternick, $postername, $posteremail, $postdate, $comments) = split(/\|/, $data2[$a]);
					$comments =~ s/[\n\r]//g;
					$comments--;

					if ($oldnum == $input{'id'}) {
						print FILE2 "$oldnum|$subject|$posternick|$postername|$posteremail|$postdate|$comments\n";
					}
					else { print FILE2 "$data2[$a]"; }
				}
				unlock(FILE2);
				close(FILE2);

				open(MEMBERFILE, "$memberdir/$musername[$b].dat") || error("$err{'010'}");
				chomp(@memsett = <MEMBERFILE>);
				close(MEMBERFILE);

				if ($input{'viewnum'} == 0) {
					open(FILE2, "$topicsdir/$input{'cat'}.cat") || error("$err{'001'} $topicsdir/$input{'cat'}.cat");
					@data2 = <FILE2>;
					close(FILE2);

					open(FILE2, ">$topicsdir/$input{'cat'}.cat") || error("$err{'016'} $topicsdir/$input{'cat'}.cat");
					lock(FILE2);
					for ($a = 0; $a < @data2; $a++) {
						($oldnum, $subject, $posternick, $postername, $posteremail, $postdate, $comments) = split(/\|/, $data2[$a]);
						$comments =~ s/[\n\r]//g;
						if ($oldnum eq $input{'id'}) {	}
						else { print FILE2 "$data2[$a]"; }
					}
					unlock(FILE2);
					close(FILE2);

					$memsett[11]--;
					open(MEMBERFILE, ">$memberdir/$musername[$b].dat") || error("$err{'016'} $memberdir/$musername[$b].dat");
					lock(MEMBERFILE);
					for ($i = 0; $i < @memsett; $i++) {
						print MEMBERFILE "$memsett[$i]\n";
					}
					unlock(MEMBERFILE);
					close(MEMBERFILE);
				}
				else {
					$memsett[12]--;
					open(MEMBERFILE, ">$memberdir/$musername[$b].dat") || error("$err{'016'} $memberdir/$musername[$b].dat");
					lock(MEMBERFILE);
					for ($i = 0; $i < @memsett; $i++) {
						print MEMBERFILE "$memsett[$i]\n";
					}
					unlock(MEMBERFILE);
					close(MEMBERFILE);
				}
			}
		}
		else { print FILE "$data[$b]"; }
	}
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=modifynews\n\n";
	exit;
}

###############
sub movetopic {
###############
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open (FILE, "$topicsdir/$input{'oldcat'}.cat") || error("$err{'001'} $topicsdir/$input{'cat'}.cat");
	@topics = <FILE>;
	close (FILE);

	open (FILE, ">$topicsdir/$input{'oldcat'}.cat") || error("$err{'016'} $topicsdir/$input{'cat'}.cat");
	lock(FILE);
	for ($a = 0; $a < @topics; $a++) {
		($num, $subject, $posternick, $postername, $posteremail, $postdate, $comments) = split(/\|/,$topics[$a]);
		$comments  =~ s~[\n\r]~~g;
		if ($num ne $input{'topic'}) { print FILE "$topics[$a]"; }
		else { $linetowrite = "$topics[$a]"; }
	}
	unlock(FILE);
	close(FILE);

	open (FILE, "$topicsdir/$input{'tocat'}.cat");
	@topics = <FILE>;
	close (FILE);

	open (FILE, ">$topicsdir/$input{'tocat'}.cat");
	lock(FILE);
	print FILE "$linetowrite";
	foreach $line (@topics) {
		print FILE "$line";
	}
	unlock(FILE);
	close(FILE);
	
	print "Location: $pageurl/$admin&op=modifynews\n\n";
	exit;
}

################
sub topicadmin {
################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$topicsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'024'} $admin{'btn2'} $admin{'086'}";
	print_top();
	print qq~<table>
~;

	foreach $line (@cats) {
		@item = split(/\|/, $line);
		print qq~<form action="$admin&amp;op=topicadmin2" method="post">
<tr>
<td><img src="$imagesurl/topics/$item[1].gif" alt="$imagesurl/topics/$item[1].gif"></td>
<td valign="top">
<table>
<tr>
<td>$admin{'057'} :</td>
<td><input type="text" name="desc" value="$item[0]"></td>
</tr>
<tr>
<td>$admin{'081'} :</td>
<td><input type="text" name="cat" value="$item[1]"></td>
</tr>
</table>
</td>
<td valign="top"><input type="hidden" name="oldcat" value="$item[1]"><input type="submit" name="moda" value="$btn{'015'}"><br>
<input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
</form>
~;
	}
	print qq~<form action="$pageurl/$admin&amp;op=topicadmin3" method="post">
<tr>
<td colspan="2"><hr size="1">
<b>$admin{'087'}</b></td>
</tr>
<tr>
<td>$admin{'057'} :</td>
<td><input type="text" name="desc"></td>
</tr>
<tr>
<td>$admin{'081'} :</td>
<td><input type="text" name="cat"></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="$admin{'044'}"></td>
</tr>
</form>
</table>
~;
	print_bottom();
	exit;
}

#################
sub topicadmin2 {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$topicsdir/cats.dat") || error("$err{'001'} $topicsdir/cats.dat");
	@cats = <FILE>;
	close(FILE);

	if ($input{'moda'} eq $btn{'015'}) {
		chomp($input{'oldcat'});

		open(FILE, ">$topicsdir/cats.dat") || error("$err{'016'} $topicsdir/cats.dat");
		lock(FILE);
		foreach $line (@cats) {
			chomp($line);
			($name, $link) = split(/\|/, $line);
			if ($input{'oldcat'} eq $link) { print FILE "$input{'desc'}|$input{'cat'}\n"; }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

		open(FILE, "$topicsdir/$input{'oldcat'}.cat");
		chomp(@topics = <FILE>);
		close(FILE);

		open(FILE, ">$topicsdir/$input{'cat'}.cat");
		lock(FILE);
		foreach $line (@topics) {
			print FILE "$line\n";
		}
		unlock(FILE);
		close(FILE);

		unlink("$topicsdir/$input{'oldcat'}.cat");
	}
	if ($input{'moda'} eq $btn{'016'}) {
		open(FILE, "$topicsdir/$input{'cat'}.cat");
		@data = <FILE>;
		close(FILE);

		if (@data != 0) { error("$err{'025'}"); }
		chomp($input{'cat'});

		open(FILE, ">$topicsdir/cats.dat") || error("$err{'016'} $topicsdir/cats.dat");
		lock(FILE);
		foreach $line (@cats) {
			chomp($line);
			($name, $link) = split(/\|/, $line);
			if ($input{'cat'} eq $link) { }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

		unlink("$topicsdir/$input{'cat'}.cat");
	}

	print "Location: $pageurl/$admin&op=topicadmin\n\n";
	exit;
}

#################
sub topicadmin3 {
#################
#	if ($username ne "admin") { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$topicsdir/cats.dat") || error("$err{'001'} $topicsdir/cats.dat");
	@cats = <FILE>;
	close(FILE);

	open(FILE, ">$topicsdir/cats.dat") || error("$err{'016'} $topicsdir/cats.dat");
	lock(FILE);
	print FILE "$input{'desc'}|$input{'cat'}\n";
	print FILE @cats;
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=topicadmin\n\n";
	exit;
}

##################
sub editlinkcats {
##################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
	check_user_permission();

	open(FILE, "$linksdir/linkcats.dat") || error("$err{'001'} $linksdir/linkcats.dat");
	chomp(@linkcats = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $admin{'088'} $admin{'btn2'} $admin{'089'}";

	print_top();
	print qq~<table>
~;
	foreach $line (@linkcats) {
		@item = split(/\|/, $line);
		$item[2] = htmltotext($item[2]);
		print qq~<form action="$admin&amp;op=editlinkcats2" method="post">
<tr>
<td colspan="2" valign="top">
<table>
<tr>
<td>$admin{'090'} :</td>
<td><input type="text" name="name" value="$item[0]">
<input type="hidden" name="cat" value="$item[1]"></td>
</tr>
<tr>
<td valign="top">$admin{'057'} :</td>
<td><textarea name="desc" rows="10" cols="40">$item[2]</textarea></td>
</tr>
</table>
</td>
<td valign="top"><input type="hidden" name="oldcat" value="$item[1]">
<input type="submit" name="moda" value="$btn{'015'}"><br>
<input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
</form>
~;
	}
	print qq~<form action="$admin&amp;op=editlinkcats3" method="post">
<tr>
<td colspan="2"><hr size="1">
<b>$admin{'087'}</b></td>
</tr>
<tr>
<td>$admin{'090'} :</td>
<td><input type="text" name="name"></td>
</tr>
<tr>
<td>$admin{'091'} :</td>
<td><input type="text" name="cat"></td>
</tr>
<tr>
<td valign="top">$admin{'057'} :</td>
<td><textarea name="desc" rows="10" cols="40"></textarea></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="$admin{'044'}"></td>
</tr>
</form>
</table>
~;

	print_bottom();
	exit;
}

###################
sub editlinkcats2 {
###################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	
	error("$err{'006'} ") if (($input{'name'} eq "") || ($input{'desc'} eq ""));

	$input{'name'} = htmlescape($input{'name'});
	$input{'desc'} = htmlescape($input{'desc'});

	open(FILE, "$linksdir/linkcats.dat") || error("$err{'001'} $linksdir/linkcats.dat");
	@linkcats = <FILE>;
	close(FILE);

	if ($input{'moda'} eq $btn{'015'}) {
		chomp($input{'oldcat'});

		open(FILE, ">$linksdir/linkcats.dat") || error("$err{'016'} $linksdir/linkcats.dat");
		lock(FILE);
		foreach $line (@linkcats) {
			chomp($line);
			($name, $link, $desc) = split(/\|/, $line);
			if ($input{'oldcat'} eq $link) { print FILE "$input{'name'}|$input{'cat'}|$input{'desc'}\n"; }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

		check_hash($input{'oldcat'});
		open(FILE, "$linksdir/$input{'oldcat'}.dat");
		chomp(@links = <FILE>);
		close(FILE);

		open(FILE, "$linksdir/$input{'oldcat'}.cnt");
		$linkscnt = <FILE>;
		close(FILE);

		check_hash($input{'cat'});
		open(FILE, ">$linksdir/$input{'cat'}.dat");
		lock(FILE);
		foreach $line (@links) {
			print FILE "$line\n";
		}
		unlock(FILE);
		close(FILE);

		open(FILE, ">$linksdir/$input{'cat'}.cnt");
		lock(FILE);
		print FILE $linkscnt;
		unlock(FILE);
		close(FILE);

		unlink("$linksdir/$input{'oldcat'}.dat");
		unlink("$linksdir/$input{'oldcat'}.cnt");
	}
	if ($input{'moda'} eq $btn{'016'}) {
		chomp($input{'cat'});

		open(FILE, ">$linksdir/linkcats.dat") || error("$err{'016'} $linksdir/linkcats.dat");
		lock(FILE);
		foreach $line (@linkcats) {
			$line =~ s/[\n\r]//g;
			($name, $link, $desc) = split(/\|/, $line);
			if ($input{'cat'} eq $link) { }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

		open(FILE, "$linksdir/$input{'oldcat'}.cnt");
		chomp($linkscnt = <FILE>);
		close(FILE);

		open(FILE, "$linksdir/linkcats.cnt");
		chomp($linkscatscnt = <FILE>);
		close(FILE);

		$newcount = $linkscatscnt - $linkscnt;

		open(FILE, ">$linksdir/linkcats.cnt");
		lock(FILE);
		print FILE $newcount;
		unlock(FILE);
		close(FILE);

		unlink("$linksdir/$input{'oldcat'}.dat");
		unlink("$linksdir/$input{'oldcat'}.cnt");
	}

	print "Location: $pageurl/$admin&op=editlinkcats\n\n";
	exit;
}

###################
sub editlinkcats3 {
###################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
	check_user_permission();

	error("$err{'006'} ") if (($input{'name'} eq "") || ($input{'cat'} eq "" || $input{'cat'} !~ /^[0-9A-Za-z#%+,-\.:=?@^_]+$/ || $input{'cat'} eq "|") || ($input{'desc'} eq ""));

	$input{'name'} = htmlescape($input{'name'});
	$input{'desc'} = htmlescape($input{'desc'});

	open(FILE, "$linksdir/linkcats.dat") || error("$err{'001'} $linksdir/linkcats.dat");
	@linkcats = <FILE>;
	close(FILE);

	open(FILE, ">$linksdir/linkcats.dat") || error("$err{'016'} $linksdir/linkcats.dat");
	lock(FILE);
	print FILE @linkcats;
	print FILE "$input{'name'}|$input{'cat'}|$input{'desc'}\n";
	unlock(FILE);
	close(FILE);

	open(FILE, ">$linksdir/$input{'cat'}.cnt");
	lock(FILE);
	print FILE "0";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=editlinkcats\n\n";
	exit;
}

###############
sub editlinks {
###############
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($input{'cat'});

	open(FILE, "$linksdir/linkcats.dat") || error("$err{'001'} $linksdir/linkcats.dat");
	@linkcats = <FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} $admin{'088'} $admin{'btn2'} $admin{'092'}";

	print_top();
	print qq~<table>
<tr>
<td valign="top">$admin{'093'} : </td>
<td valign="top"><form action="$pageurl/$cgi?action=admin&amp;op=editlinks" method="post">
<select name="cat">
~;
	foreach $category (@linkcats) {
		chomp($line);
		($name, $link, $desc) = split(/\|/, $category);
		if ($input{'cat'} eq $link) { 
			print qq~<option value="$link" selected>$name</option>~; 
			$catname = $name;
		}
		else { print qq~<option value="$link">$name</option>~; }
	}
	print qq~</select>
<input type="submit" value="$btn{'014'}">
</form></td>
</tr>
</table><br>
~;
	if ($input{'cat'} ne "") {
		print qq~<b>$admin{'117'} "$catname":</b><br>
<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg"><b>ID</b></td>
<td bgcolor="$windowbg"><b>$admin{'090'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'057'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'082'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'083'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'094'}</b></td>
~;
		open(FILE, "$linksdir/$input{'cat'}.dat");
		@links = <FILE>;
		close(FILE);

		foreach $line (@links) {
			chomp($line);
			($id, $name, $url, $desc, $postdate, $linkposter, $hits) = split(/\|/, $line);

			open(FILE, "$memberdir/$linkposter.dat");
			@linkposter_settings = <FILE>;
			close(FILE);

			$linkposter_settings[1] =~ s/[\n\r]//g;

			print qq~<tr>
<td bgcolor="$windowbg2"><a href="$admin&amp;op=editlinks2&amp;cat=$input{'cat'}&amp;id=$id">$id</a></td>
<td bgcolor="$windowbg2"><a href="$url" target"_blank">$name</a></td>
<td bgcolor="$windowbg2">$desc</td>
<td bgcolor="$windowbg2">$postdate</td>
<td bgcolor="$windowbg2"><a href="$pageurl/$cgi?action=viewprofile&amp;username=$linkposter">$linkposter_settings[1]</a></td>
<td bgcolor="$windowbg2">$hits</td>
</tr>
~;
		}
		print qq~</td>
</tr>
</table>
</td>
</tr>
</table>
~;
	}
	print_bottom();
	exit;
}

################
sub editlinks2 {
################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($info{'cat'});

	open(FILE, "$linksdir/$info{'cat'}.dat") || error("$err{'001'} $linksdir/$info{'id'}.dat");
	chomp(@links = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'024'} $admin{'btn2'} $admin{'095'}";
	print_top();
	print qq~<table width="100%">
~;

	for ($a = 0; $a < @links; $a++) {
		($id, $name, $url, $desc, $postdate, $linkposter, $hits) = split(/\|/, $links[$a]);

		if ($info{'id'} eq $id) {
			open(FILE, "$memberdir/$linkposter.dat");
			@linkposter_settings = <FILE>;
			close(FILE);

			$linkposter_settings[1] =~ s/[\n\r]//g;

			$desc = htmltotext($desc);

			print qq~<form action="$admin&amp;op=editlinks3" method="post">
<input type="hidden" name="cat" value="$info{'cat'}">
<input type="hidden" name="id" value="$info{'id'}">
<tr>
<td valign="top">$admin{'096'} <a href="$pageurl/$cgi?action=viewprofile&amp;username=$linkposter">$linkposter_settings[1]</a>:<br>
($postdate)</td>
<td><input type="text" name="name" value="$name" size="30"><br>
<input type="text" name="url" value="$url" size="30"><br>
<textarea name="desc" rows="3" cols="30">$desc</textarea></td>
<td><input type="submit" name="moda" value="$btn{'015'}"><br>
<input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
<tr>
<td colspan="3"><hr size="1"></td>
</tr>
</form>
~;
		}
	}
	open(FILE, "$linksdir/linkcats.dat");
	chomp(@linkcats = <FILE>);
	close(FILE);

	foreach $category (@linkcats) {
		chomp($category);
		($name, $link, $desc) = split(/\|/, $category);
		if ($info{'cat'} eq $link) { $sel = "selected"; }
		else { $sel = ""; }
		$catsdropdown = qq~$catsdropdown\n<option value="$link" $sel>$name~;
	}
	print qq~<form action="$admin&amp;op=movelink" method="post">
<tr>
<td colspan="3">$admin{'084'} : <select name="tocat">$catsdropdown
</select>
<input type="hidden" name="linkid" value="$info{'id'}">
<input type="hidden" name="oldcat" value="$info{'cat'}"><input type="submit" value="$admin{'085'}"></td>
</tr>
</form>
</table>
~;
	print_bottom();
	exit;
}

################
sub editlinks3 {
################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($input{'cat'});

	$input{'name'} = htmlescape($input{'name'});
	$input{'desc'} = htmlescape($input{'desc'});
	chomp($input{'cat'});

	open(FILE, "$linksdir/$input{'cat'}.dat") || error("$err{'001'} $linksdir/$input{'cat'}.dat");
	@links = <FILE>;
	close(FILE);

	if ($input{'moda'} eq $btn{'015'}) {
		open(FILE, ">$linksdir/$input{'cat'}.dat") || error("$err{'016'} $linksdir/$input{'cat'}.dat");
		lock(FILE);
		foreach $line (@links) {
			chomp($line);
			($id, $name, $url, $desc, $postdate, $linkposter, $hits) = split(/\|/, $line);
			if ($input{'id'} eq $id) { 
				print FILE "$input{'id'}|$input{'name'}|$input{'url'}|$input{'desc'}|$postdate|$linkposter|$hits\n"; 
			}
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);
	}
	if ($input{'moda'} eq $btn{'016'}) {
		open(FILE, ">$linksdir/$input{'cat'}.dat") || error("$err{'016'} $linksdir/$input{'cat'}.dat");
		lock(FILE);
		foreach $line (@links) {
			chomp($line);
			($id, $name, $url, $desc, $postdate, $linkposter, $hits) = split(/\|/, $line);
			if ($input{'id'} eq $id) { }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

		open(FILE, "$linksdir/$input{'cat'}.cnt");
		chomp($linkscnt = <FILE>);
		close(FILE);

		open(FILE, "$linksdir/linkcats.cnt");
		chomp($linkscatscnt = <FILE>);
		close(FILE);

		$linkscnt--;
#		$newcount = $linkscatscnt - $linkscnt;

#		open(FILE, ">$linksdir/linkcats.cnt");
#		lock(FILE);
#		print FILE $newcount;
#		unlock(FILE);
#		close(FILE);

  		$linkscatscnt--;

  		open(FILE, ">$linksdir/linkcats.cnt");
 	 	lock(FILE);
  		print FILE $linkscatscnt;
  		unlock(FILE);
  		close(FILE);

		open(FILE, ">$linksdir/$input{'cat'}.cnt");
		lock(FILE);
		print FILE $linkscnt;
		unlock(FILE);
		close(FILE);
	}

	print "Location: $pageurl/$admin&op=editlinks\n\n";
	exit;
}

##############
sub movelink {
##############
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($input{'oldcat'});
	check_hash($input{'tocat'});

	open (FILE, "$linksdir/$input{'oldcat'}.dat") || error("$err{'001'} $linksdir/$input{'cat'}.dat");
	@links = <FILE>;
	close (FILE);

	open (FILE, ">$linksdir/$input{'oldcat'}.dat") || error("$err{'016'} $linksdir/$input{'cat'}.dat");
	lock(FILE);
	for ($a = 0; $a < @links; $a++) {
		($id, $name, $url, $desc, $postdate, $linkposter, $hits) = split(/\|/,$links[$a]);
		$hits  =~ s~[\n\r]~~g;
		if ($id ne $input{'linkid'}) { print FILE "$links[$a]"; }
		else { $linetowrite = "$links[$a]"; }
	}
	unlock(FILE);
	close(FILE);

	open (FILE, "$linksdir/$input{'tocat'}.dat");
	@links = <FILE>;
	close (FILE);

	open (FILE, ">$linksdir/$input{'tocat'}.dat");
	lock(FILE);
	print FILE "$linetowrite";
	foreach $line (@links) {
		print FILE "$line";
	}
	unlock(FILE);
	close(FILE);

	open(FILE, "$linksdir/$input{'oldcat'}.cnt");
	chomp($linkscnt = <FILE>);
	close(FILE);

	open(FILE, "$linksdir/$input{'tocat'}.cnt");
	chomp($linkscnt2 = <FILE>);
	close(FILE);

	$linkscnt--;
	$linkscnt2++;

	open(FILE, ">$linksdir/$input{'oldcat'}.cnt");
	lock(FILE);
	print FILE $linkscnt;
	unlock(FILE);
	close(FILE);

	open(FILE, ">$linksdir/$input{'tocat'}.cnt");
	lock(FILE);
	print FILE $linkscnt2;
	unlock(FILE);
	close(FILE);
	
	print "Location: $pageurl/$admin&op=editlinks\n\n";
	exit;
}

##################
sub editdownloadcats {
##################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
	check_user_permission();

	open(EFILED, "$downloadsdir/downloadcats.dat") || error("$err{'001'} $downloadsdir/downloadcats.dat");
	chomp(@edownloadcats = <EFILED>);
	close(EFILED);

	$navbar = "$admin{'btn2'} $admin{'097'} $admin{'btn2'} $admin{'098'}";

	print_top();
	print qq~<table>
~;
	foreach $eline (@edownloadcats) {
		@eitem = split(/\|/, $eline);
		$eitem[2] = htmltotext($eitem[2]);
		print qq~<form action="$admin&amp;op=editdownloadcats2" method="post">
<tr>
<td colspan="2" valign="top">
<table>
<tr>
<td>$admin{'090'}:</td>
<td><input type="text" name="name" value="$eitem[0]">
<input type="hidden" name="cat" value="$eitem[1]"></td>
</tr>
<tr>
<td valign="top">$admin{'057'}:</td>
<td><textarea name="desc" rows="10" cols="40">$eitem[2]</textarea></td>
</tr>
</table>
</td>
<td valign="top"><input type="hidden" name="eoldcat" value="$eitem[1]">
<input type="submit" name="moda" value="$btn{'015'}"><br>
<input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
</form>
~;
	}
	print qq~<form action="$admin&amp;op=editdownloadcats3" method="post">
<tr>
<td colspan="2"><hr size="1">
<b>$admin{'087'}</b></td>
</tr>
<tr>
<td>$admin{'090'}:</td>
<td><input type="text" name="name"></td>
</tr>
<tr>
<td>$admin{'099'} :</td>
<td><input type="text" name="cat"></td>
</tr>
<tr>
<td valign="top">$admin{'057'} :</td>
<td><textarea name="desc" rows="10" cols="40"></textarea></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="$admin{'044'}"></td>
</tr>
</form>
</table>
~;

	print_bottom();
	exit;
}

###################
sub editdownloadcats2 {
###################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();

	error("$err{'006'} ") if (($input{'name'} eq "") || ($input{'desc'} eq ""));

	$input{'name'} = htmlescape($input{'name'});
	$input{'desc'} = htmlescape($input{'desc'});

	open(EFILED, "$downloadsdir/downloadcats.dat") || error("$err{'001'} $downloadsdir/downloadcats.dat");
	@edownloadscats = <EFILED>;
	close(EFILED);

	if ($input{'moda'} eq $btn{'015'}) {
		chomp($input{'eoldcat'});

		open(EFILED, ">$downloadsdir/downloadcats.dat") || error("$err{'016'} $downloadsdir/downloadcats.dat");
		lock(EFILED);
		foreach $eline (@edownloadscats) {
			chomp($eline);
			($ename, $edownloads, $edesc) = split(/\|/, $eline);
			if ($input{'eoldcat'} eq $edownloads) { print EFILED "$input{'name'}|$input{'cat'}|$input{'desc'}\n"; }
			else { print EFILED "$eline\n"; }
		}
		unlock(EFILED);
		close(EFILED);
		check_hash($input{'eoldcat'});

		open(EFILED, "$downloadsdir/$input{'eoldcat'}.dat");
		chomp(@edownloads = <EFILED>);
		close(EFILED);

		open(EFILED, "$downloadsdir/$input{'eoldcat'}.cnt");
		$edownloadscnt = <EFILED>;
		close(EFILED);

		check_hash($input{'cat'});
		open(EFILED, ">$downloadsdir/$input{'cat'}.dat");
		lock(EFILED);
		foreach $eline (@edownloads) {
			print FILE "$eline\n";
		}
		unlock(EFILED);
		close(EFILED);

		open(EFILED, ">$downloadsdir/$input{'cat'}.cnt");
		print EFILED $edownloadscnt;
		close(EFILED);

		unlink("$downloadsdir/$input{'eoldcat'}.dat");
		unlink("$downloadsdir/$input{'eoldcat'}.cnt");
	}
	if ($input{'moda'} eq $btn{'016'}) {
		chomp($input{'cat'});

		open(EFILED, ">$downloadsdir/downloadcats.dat") || error("$err{'016'} $downloadsdir/downloadcats.dat");
		lock(EFILED);
		foreach $eline (@edownloadcats) {
			$eline =~ s/[\n\r]//g;
			($ename, $edownloads, $edesc) = split(/\|/, $eline);
			if ($input{'cat'} eq $edownloads) { }
			else { print EFILED "$eline\n"; }
		}
		unlock(EFILED);
		close(EFILED);

		open(EFILED, "$downloadsdir/$input{'eoldcat'}.cnt");
		chomp($downloadscnt = <EFILED>);
		close(EFILED);

		open(EFILED, "$downloadsdir/downloadcats.cnt");
		chomp($edownloadscatscnt = <EFILED>);
		close(EFILED);

		$newcount = $edownloadscatscnt - $edownloadscnt;

		open(EFILED, ">$downloadsdir/downloadcats.cnt");
		lock(EFILED);
		print EFILED $enewcount;
		unlock(EFILED);
		close(EFILED);

		unlink("$downloadsdir/$input{'eoldcat'}.dat");
		unlink("$downloadsdir/$input{'eoldcat'}.cnt");
	}

	print "Location: $pageurl/$admin&op=editdownloadcats\n\n";
	exit;
}

###################
sub editdownloadcats3 {
###################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
	check_user_permission();

	error("$err{'006'} ") if (($input{'name'} eq "") || ($input{'cat'} eq "" || $input{'cat'} !~ /^[0-9A-Za-z#%+,-\.:=?@^_]+$/ || $input{'cat'} eq "|") || ($input{'desc'} eq ""));

	$input{'name'} = htmlescape($input{'name'});
	$input{'desc'} = htmlescape($input{'desc'});

	open(EFILED, "$downloadsdir/downloadcats.dat") || error("$err{'001'} $downloadsdir/downloadcats.dat");
	@edownloadcats = <EFILED>;
	close(EFILED);

	open(EFILED, ">$downloadsdir/downloadcats.dat") || error("$err{'016'} $downloadsdir/downloadcats.dat");
	lock(EFILED);
	print EFILED @edownloadcats;
	print EFILED "$input{'name'}|$input{'cat'}|$input{'desc'}\n";
	unlock(EFILED);
	close(EFILED);

	open(EFILED, ">$downloadsdir/$input{'cat'}.cnt");
	lock(EFILED);
	print EFILED "0";
	unlock(EFILED);
	close(EFILED);

	print "Location: $pageurl/$admin&op=editdownloadcats\n\n";
	exit;
}

###############
sub editdownloads {
###############
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();

	open(FILE, "$downloadsdir/downloadcats.dat") || error("$err{'001'} $downloadsdir/downloadcats.dat");
	@edownloadcats = <FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} $admin{'097'} $admin{'btn2'} $admin{'100'}";

	print_top();
	print qq~<table>
<tr>
<td valign="top">$admin{'101'} : </td>
<td valign="top"><form action="$cgi?action=admin&amp;op=editdownloads" method="post">
<select name="cat">
~;
	foreach $category (@edownloadcats) {
		chomp($line);
		($name, $edownloads, $desc) = split(/\|/, $category);
		if ($input{'cat'} eq $edownloads) { 
			print qq~<option value="$edownloads" selected>$name</option>~; 
			$catname = $name;
		}
		else { print qq~<option value="$edownloads">$name</option>~; }
	}
	print qq~</select>
<input type="submit" value="$btn{'014'}">
</form></td>
</tr>
</table><br>
~;
	if ($input{'cat'} ne "") {
		print qq~<b>$admin{'102'} "$catname":</b><br>
<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg"><b>ID</b></td>
<td bgcolor="$windowbg"><b>$admin{'090'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'057'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'082'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'083'}</b></td>
<td bgcolor="$windowbg"><b>$admin{'094'}</b></td>
~;
		check_hash($input{'cat'});
		open(FILE, "$downloadsdir/$input{'cat'}.dat");
		@edownloads = <FILE>;
		close(FILE);

		foreach $line (@edownloads) {
			chomp($line);
			($id, $name, $url, $desc, $postdate, $downloadposter, $hits) = split(/\|/, $line);

			open(FILE, "$memberdir/$downloadposter.dat");
			@downloadposter_settings = <FILE>;
			close(FILE);

			$downloadposter_settings[1] =~ s/[\n\r]//g;

			print qq~<tr>
<td bgcolor="$windowbg2"><a href="$admin&amp;op=editdownloads2&amp;cat=$input{'cat'}&amp;id=$id">$id</a></td>
<td bgcolor="$windowbg2"><a href="$url" target"_blank">$name</a></td>
<td bgcolor="$windowbg2">$desc</td>
<td bgcolor="$windowbg2">$postdate</td>
<td bgcolor="$windowbg2"><a href="$pageurl/$cgi?action=viewprofile&amp;username=$downloadposter">$downloadposter_settings[1]</a></td>
<td bgcolor="$windowbg2">$hits</td>
</tr>
~;
		}
		print qq~</td>
</tr>
</table>
</td>
</tr>
</table>
~;
	}
	print_bottom();
	exit;
}

################
sub editdownloads2 {
################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($info{'cat'});

	open(FILE, "$downloadsdir/$info{'cat'}.dat") || error("$err{'001'} $downloadsdir/$info{'id'}.dat");
	chomp(@edownloads = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'024'} $admin{'btn2'} $admin{'103'}";
	print_top();
	print qq~<table width="100%">
~;

	for ($a = 0; $a < @edownloads; $a++) {
		($id, $name, $url, $desc, $postdate, $downloadposter, $hits) = split(/\|/, $edownloads[$a]);

		if ($info{'id'} eq $id) {
			open(FILE, "$memberdir/$downloadposter.dat");
			@downloadposter_settings = <FILE>;
			close(FILE);

			$downloadposter_settings[1] =~ s/[\n\r]//g;

			$desc = htmltotext($desc);

			print qq~<form action="$admin&amp;op=editdownloads3" method="post">
<input type="hidden" name="cat" value="$info{'cat'}">
<input type="hidden" name="id" value="$info{'id'}">
<tr>
<td valign="top">$admin{'096'} <a href="$pageurl/$cgi?action=viewprofile&amp;username=$downloadposter">$downloadposter_settings[1]</a>:<br>
($postdate)</td>
<td><input type="text" name="name" value="$name" size="30"><br>
<input type="text" name="url" value="$url" size="30"><br>
<textarea name="desc" rows="3" cols="30">$desc</textarea></td>
<td><input type="submit" name="moda" value="$btn{'015'}"><br>
<input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
<tr>
<td colspan="3"><hr size="1"></td>
</tr>
</form>
~;
		}
	}
	open(FILE, "$downloadsdir/downloadcats.dat");
	chomp(@downloadcats = <FILE>);
	close(FILE);

	foreach $category (@downloadcats) {
		chomp($category);
		($name, $edownloads, $desc) = split(/\|/, $category);
		if ($info{'cat'} eq $edownloads) { $sel = "selected"; }
		else { $sel = ""; }
		$catsdropdown = qq~$catsdropdown\n<option value="$edownloads" $sel>$name~;
	}
	print qq~<form action="$admin&amp;op=movedownload" method="post">
<tr>
<td colspan="3">$admin{'084'} : <select name="tocat">$catsdropdown
</select>
<input type="hidden" name="downloadid" value="$info{'id'}">
<input type="hidden" name="eoldcat" value="$info{'cat'}"><input type="submit" value="Move"></td>
</tr>
</form>
</table>
~;
	print_bottom();
	exit;
}

################
sub editdownloads3 {
################
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($input{'cat'});

	$input{'name'} = htmlescape($input{'name'});
	$input{'desc'} = htmlescape($input{'desc'});
	chomp($input{'cat'});

	open(FILE, "$downloadsdir/$input{'cat'}.dat") || error("$err{'001'} $downloadsdir/$input{'cat'}.dat");
	@edownloads = <FILE>;
	close(FILE);

	if ($input{'moda'} eq $btn{'015'}) {
		open(FILE, ">$downloadsdir/$input{'cat'}.dat") || error("$err{'016'} $downloadsdir/$input{'cat'}.dat");
		lock(FILE);
		foreach $line (@edownloads) {
			chomp($line);
			($id, $name, $url, $desc, $postdate, $downloadposter, $hits) = split(/\|/, $line);
			if ($input{'id'} eq $id) { 
				print FILE "$input{'id'}|$input{'name'}|$input{'url'}|$input{'desc'}|$postdate|$downloadposter|$hits\n"; 
			}
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);
	}
	if ($input{'moda'} eq $btn{'016'}) {
		open(FILE, ">$downloadsdir/$input{'cat'}.dat") || error("$err{'016'} $downloadsdir/$input{'cat'}.dat");
		lock(FILE);
		foreach $line (@edownloads) {
			chomp($line);
			($id, $name, $url, $desc, $postdate, $downloadposter, $hits) = split(/\|/, $line);
			if ($input{'id'} eq $id) { }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

		open(FILE, "$downloadsdir/$input{'cat'}.cnt");
		chomp($downloadscnt = <FILE>);
		close(FILE);

		open(FILE, "$downloadsdir/downloadcats.cnt");
		chomp($downloadscatscnt = <FILE>);
		close(FILE);

		$downloadscnt--;
#		$newcount = $downloadscatscnt - $downloadscnt;

#		open(FILE, ">$downloadsdir/downloadcats.cnt");
#		lock(FILE);
#		print FILE $newcount;
#		unlock(FILE);
#		close(FILE);

  		$downloadscatscnt--;

  		open(FILE, ">$downloadsdir/downloadcats.cnt");
  		lock(FILE);
  		print FILE $downloadscatscnt;
  		unlock(FILE);
  		close(FILE);

		open(FILE, ">$downloadsdir/$input{'cat'}.cnt");
		lock(FILE);
		print FILE $downloadscnt;
		unlock(FILE);
		close(FILE);
	}

	print "Location: $pageurl/$admin&op=editdownloads\n\n";
	exit;
}

##############
sub movedownload {
##############
#	if ($settings[7] ne $userlevel[0]) { error("$err{'011'}"); }
require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($input{'eoldcat'});
	check_hash($input{'tocat'});

	open (FILE, "$downloadsdir/$input{'eoldcat'}.dat") || error("$err{'001'} $downloadsdir/$input{'cat'}.dat");
	@edownloads = <FILE>;
	close (FILE);

	open (FILE, ">$downloadsdir/$input{'eoldcat'}.dat") || error("$err{'016'} $downloadsdir/$input{'cat'}.dat");
	lock(FILE);
	for ($a = 0; $a < @edownloads; $a++) {
		($id, $name, $url, $desc, $postdate, $downloadposter, $hits) = split(/\|/,$edownloads[$a]);
		$hits  =~ s~[\n\r]~~g;
		if ($id ne $input{'downloadid'}) { print FILE "$edownloads[$a]"; }
		else { $linetowrite = "$edownloads[$a]"; }
	}
	unlock(FILE);
	close(FILE);

	open (FILE, "$downloadsdir/$input{'tocat'}.dat");
	@edownloads = <FILE>;
	close (FILE);

	open (FILE, ">$downloadsdir/$input{'tocat'}.dat");
	lock(FILE);
	print FILE "$linetowrite";
	foreach $line (@edownloads) {
		print FILE "$line";
	}
	unlock(FILE);
	close(FILE);

	open(FILE, "$downloadsdir/$input{'eoldcat'}.cnt");
	chomp($downloadscnt = <FILE>);
	close(FILE);

	open(FILE, "$downloadsdir/$input{'tocat'}.cnt");
	chomp($downloadscnt2 = <FILE>);
	close(FILE);

	$downloadscnt--;
	$downloadscnt2++;

	open(FILE, ">$downloadsdir/$input{'eoldcat'}.cnt");
	lock(FILE);
	print FILE $downloadscnt;
	unlock(FILE);
	close(FILE);

	open(FILE, ">$downloadsdir/$input{'tocat'}.cnt");
	lock(FILE);
	print FILE $downloadscnt2;
	unlock(FILE);
	close(FILE);
	
	print "Location: $pageurl/$admin&op=editdownloads\n\n";
	exit;
};

####################
sub new_autopage {
####################

$navbar = "$admin{'btn2'} $admin{'104'} $admin{'btn2'} $admin{'105'}";
print_top();
check_user_permission();
print qq~
<form action="$pageurl/$cgi\?action=newautopage1" method="post">
$admin{'106'} :<br>
<select name="autocats">
<option value="mainmenu">$admin{'107'}
<option value="help">$admin{'108'}
</select><br>
Code Type :<br>
<select name="codetype">
<option value="standard">Standard
<option value="pee">PEE
<option value="ssi">SSI
<option value="perl">Perl
</select>
<p>
$admin{'109'}<br>
<input type=text name="fname" value="">
<p>
$admin{'110'} :<br><center>
<textarea name="data" rows=20 cols=40 wrap=virtual align=center>
</textarea><p>
<input type="submit" value="$admin{'044'}"></center>
</form>
~;
print_bottom();
};

####################
sub new_autopage1 {
####################
require "$sourcedir/security.pl";
check_hash($input{'fname'});

$navbar = "$admin{'btn2'} $admin{'104'} $admin{'btn2'} $admin{'111'}";
print_top();
check_user_permission();

open(NEWAUTO, ">$datadir/autopage/$input{'autocats'}/$input{'fname'}.dat") || error (" Error creating Autopage");
lock(NEWAUTO);
print NEWAUTO "$input{'data'}";
unlock(NEWAUTO);
close(NEWAUTO);

open(NEWAUTO, ">$datadir/autopage/$input{'autocats'}/$input{'fname'}.set") || error (" Error creating Autopage");
lock(NEWAUTO);
print NEWAUTO "$input{'codetype'}|reserved|reserved\n";
unlock(NEWAUTO);
close(NEWAUTO);

print qq~$admin{'112'}.~;

print_bottom();
};

####################
sub edit_autopage {
####################
require "$sourcedir/security.pl";
check_hash($info{'fname'});

$navbar = "$admin{'btn2'} $admin{'104'} $admin{'btn2'} Edit Autopage";
print_top();
check_user_permission();

if ($info{'type'} eq "") { error("Autopage type empty!"); }
if ($info{'fname'} eq "") { error("Autopage file empty!"); }

open(AUTOPAGE, "$datadir/autopage/$info{'type'}/$info{'fname'}.dat") || error("Can't open $datadir/autopage/$info{'type'}/$info{'fname'}.dat");
@editautocont = <AUTOPAGE>;
close(AUTOPAGE);

if(!open(AUTOPAGE, "$datadir/autopage/$info{'type'}/$info{'fname'}.set")) { $curtype = "pee"; }
else { @editautocontctype = <AUTOPAGE>; 
	close(AUTOPAGE); 

	@ctypen = split(/\|/, $editautocontctype[0]);
	$curtype = $ctypen[0];
}


print qq~
	<form action="$pageurl/$cgi\?action=newautopage1" method="post">
	$admin{'106'} Category: $info{'type'}<br>
	<input type="hidden" name="autocats" value="$info{'type'}">
	<p>
	$admin{'109'}<br>
	<input name="fname" value="$info{'fname'}">
	<p>
	$admin{'110'} :<br>
	<textarea name="data" rows=10 cols=40 wrap=virtual>@editautocont</textarea><p>
	This Autopage is typed as : 
	<br>
	<select name="codetype">~;

	if($curtype eq "standard") { print qq~<option value="standard" checked>Standard<option value="pee">PEE<option value="ssi">SSI<option value="perl">Perl~; }
	if($curtype eq "pee") { print qq~<option value="standard">Standard<option value="pee" checked>PEE<option value="ssi">SSI<option value="perl">Perl~; }
	if($curtype eq "ssi") { print qq~<option value="standard">Standard<option value="pee">PEE<option value="ssi" checked>SSI<option value="perl">Perl~; }
	if($curtype eq "perl") { print qq~<option value="standard">Standard<option value="pee">PEE<option value="ssi">SSI<option value="perl" selected>Perl~; }

print qq~</select><br><input type="submit" value="$admin{'044'}">
	</form>
~;
print_bottom();

};

#######################
sub remove_autopage {
#######################
require "$sourcedir/security.pl";
check_hash($info{'fname'});

$navbar = "$admin{'btn2'} $admin{'104'} $admin{'btn2'} $admin{'113'}";
print_top();
check_user_permission();

	if ($info{'cats'} ne "") {
		if ($info{'fname'} ne "") {
			unlink("$datadir/autopage/$info{'cats'}/$info{'fname'}.dat");
			unlink("$datadir/autopage/$info{'cats'}/$info{'fname'}.set");
		}
		else { print "$admin{'114'}"; exit; }
	}

	print qq~<b>$admin{'115'}</b><br><ul>~;

	opendir(DIRR, "$datadir/autopage/help");
	@contentsr = readdir(DIRR);
	closedir(DIRR);

     	FILER: foreach $liner (sort @contentsr) {
		
		($namer, $extensionr) = split (/\./, $liner);
	        next FILER if  ($liner eq '.');
       	 	next FILER if ($liner eq '..');
        	next FILER if ($liner eq '.htaccess');
		next FILER if ($extensionr ne 'dat');

		$namer_space = $namer;
		$namer_space =~ s/ /%20/g;

		$daf_help .= qq~<li>$namer - <a href=\"$pageurl/$cgi\?action=editautopage\&type=help\&fname=$namer_space">edit</a>-<a href=\"$pageurl/$cgi\?action=removeautopage\&cats=help\&fname=$namer">remove</a><br>\n~;
	}

	print "$daf_help </ul><p>";
	print qq~<b>$admin{'116'}</b><br><ul>~;
		
	opendir(DIRRM, "$datadir/autopage/mainmenu");
	@contentsrm = readdir(DIRRM);
	closedir(DIRRM);

     	FILERM: foreach $linerm (sort @contentsrm) {

		($namerm, $extensionrm) = split (/\./, $linerm);
        	next FILERM if  ($linerm eq '.');
        	next FILERM if ($linerm eq '..');
        	next FILERM if ($linerm eq '.htaccess');
		next FILERM if ($extensionmr ne 'dat');

		$namerm_space = $namerm;
		$namerm_space =~ s/ /%20/g;
		$daf_mainmenu .= qq~<li>$namerm - <a href=\"$pageurl/$cgi\?action=editautopage\&type=mainmenu\&fname=$namerm_space">edit</a>-<a href=\"$pageurl/$cgi\?action=removeautopage\&cats=mainmenu\&fname=$namerm">remove</a><br>\n~;
	}

	print "$daf_mainmenu </ul><p>";

	print_bottom();

}

###################
sub brokend_admin {
###################

	$navbar = "$admin{'bnt2'} $download{'admin'} $admin{'btn2'} $download{'broken_download'}";
	print_top();
	check_user_permission();
	print "<center><big>$download{'broken_download_report'}</big></center><br><p>";
	print qq~<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\"><tr><td>~;

	open(BROKEND, "$downloadsdir/broken/broken.dat") || error("$err{'001'} $downloadsdir/broken/broken.dat");
	@brokendlists = <BROKEND>;
	close(BROKEND);

	for ($a = 0; $a < @brokendlists; $a++) {
		($id[$a], $catbd[$a], $idbd[$a], $namebd[$a], $typebd[$a], $posterbd[$a], $descbd[$a], $datebd[$a]) = split(/\|/, $brokendlists[$a]);
	}

	$numshown = 0;
	for ($b = 0; $b < @brokendlists; $b++) {
		++$numshown;
		print qq~<img src=\"$imagesurl/stats/downloads.gif\" border=\"0\" alt=\"\">&nbsp;&nbsp;<b><a href=\"$pageurl/$cgi\?action=redirectd&amp;cat=$catbd[$b]&amp;id=$idbd[$b]\" target="_blank">$namebd[$b]</a></b><br>
		$download{'download_category'} : $catbd[$b]<br>
		$download{'download_description'} :<br>
		$descbd[$b]<br>
		$download{'broken_type'} : $typebd[$b]<br>
		$download{'poster'}      : <a href=\"$pageurl/$cgi\?action=viewprofile&amp;username=$posterbd[$b]\"> $posterbd[$b]</a><br>
	 	$download{'date'}        : $datebd[$b]<br>
		<a href=\"$admin&amp;op=brokendadmin1\&id=$id[$b]\">$download{'delete_report'}</a> <p>
		~;
	}
	print qq~</td></tr></table>~;
	print_bottom();
}

####################
sub brokend_admin1 {
####################

	open(BROKEND, "$downloadsdir/broken/broken.dat") || error("$err{'001'} $downloadsdir/broken/broken.dat");
	@ebrokends = <BROKEND>;
	close(BROKEND);

	open(BROKEND, ">$downloadsdir/broken/broken.dat") || error("$err{'016'} $downloadsdir/broken/broken.dat");
	lock(BROKEND);
	foreach $line (@ebrokends) {
		chomp($line);
		($id, $catbd, $idbd, $namebd, $typebd, $posterbd, $descbd, $datebd) = split(/\|/, $line);
		if ($info{'id'} eq $id) { }
		else { print BROKEND "$line\n"; }
	}
	unlock(BROKEND);
	close(BROKEND);

	open(BROKEND, "$downloadsdir/broken/broken.cnt");
	chomp($brokendcnt = <BROKEND>);
	close(BROKEND);

	$brokendcnt--;

	open(BROKEND, ">$downloadsdir/broken/broken.cnt");
	lock(BROKEND);
	print BROKEND $brokendcnt;
	unlock(BROKEND);
	close(BROKEND);

	print "Location: $pageurl/$admin\&op=brokendadmin\n\n";
}

###################
sub brokenl_admin {
###################

	$navbar = "$admin{'bnt2'} $download{'admin'} $admin{'btn2'} $link{'broken_link'}";
	print_top();
	check_user_permission();
	print "<center><big>$link{'broken_link_report'}</big></center><br><p>";
	print qq~<table border="0" cellpadding="5" cellspacing="0" width="100%"><tr><td>~;

	open(BROKENL, "$linksdir/broken/broken.dat") || error("$err{'001'} $linksdir/broken/broken.dat");
	@brokenllists = <BROKENL>;
	close(BROKENL);

	for ($a = 0; $a < @brokenllists; $a++) {
		($id[$a], $catbl[$a], $idbl[$a], $namebl[$a], $typebl[$a], $posterbl[$a], $descbl[$a], $datebl[$a]) = split(/\|/, $brokenllists[$a]);
	}

	$numshown = 0;
	for ($b = 0; $b < @brokenllists; $b++) {
		++$numshown;
		print qq~<img src=\"$imagesurl/stats/links.gif\" border=\"0\" alt=\"\">&nbsp;&nbsp;<b><a href=\"$pageurl/$cgi\?action=redirect&amp;cat=$catbl[$b]&amp;id=$idbl[$b]\" target=\"_blank\">$namebl[$b]</a></b><br>
		$link{'link_category'} : $catbl[$b]<br>
		$link{'link_description'} :<br>
		$descbd[$b]<br>
		$link{'broken_type'} : $typebd[$b]<br>
		$link{'link_poster'} : <a href=\"$pageurl/$cgi\?action=viewprofile&amp;username=$posterbl[$b]\"> $posterbd[$b]</a><br>
	 	$link{'date'}        : $datebd[$b]<br>
		<a href=\"$admin&amp;op=brokenladmin1\&id=$id[$b]\">$link{'delete_report'}</a> <p>
		~;
	}
	print qq~</td></tr></table>~;
	print_bottom();
}

####################
sub brokenl_admin1 {
####################

	open(BROKENL, "$linksdir/broken/broken.dat") || error("$err{'001'} $linksdir/broken/broken.dat");
	@ebrokenls = <BROKENL>;
	close(BROKENL);

	open(BROKENL, ">$linksdir/broken/broken.dat") || error("$err{'016'} $linksdir/broken/broken.dat");
	lock(BROKENL);
	foreach $line (@ebrokenls) {
		chomp($line);
		($id, $catbl, $idbl, $namebl, $typebl, $posterbl, $descbl, $datebl) = split(/\|/, $line);
		if ($info{'id'} eq $id) { }
		else { print BROKENL "$line\n"; }
	}
	unlock(BROKENL);
	close(BROKENL);

	open(BROKENL, "$linksdir/broken/broken.cnt");
	chomp($brokenlcnt = <BROKENL>);
	close(BROKENL);

	$brokenlcnt--;

	open(BROKENL, ">$linksdir/broken/broken.cnt");
	lock(BROKENL);
	print BROKENL $brokenlcnt;
	unlock(BROKENL);
	close(BROKENL);

	print "Location: $pageurl/$admin\&op=brokenladmin\n\n";
}

###############
sub userranks {
###############
	if ($username ne 'admin') { error("$err{'011'}"); }

	open(FILE, "<$memberdir/membergroups.dat") || error("$err{'001'} $topicsdir/cats.dat");
	@membergroups = <FILE>;
	close(FILE);

	@req_posts = qw(Admin Moderator 0 25 50 75 100 250 500);

	$navbar = "$admin{'btn2'} User Admin $admin{'btn2'} Edit User Ranks";

	print_top();
	print "<table>";

	$num = 0;
	foreach $line (@membergroups) {
		chomp($line);
		print qq~<form action="$admin&amp;op=userranks2" method="post">
<tr>
<td>> $req_posts[$num] Posts</td>
<td><input type="text" name="lvl" value="$line">&nbsp;<input type="submit" value="Edit"><input type="hidden" name="line" value="$num"></td>
</tr>
</form>
~;
		$num++;
	}
	print "</table>\n";
	print_bottom();
	exit;
}

################
sub userranks2 {
################
	if ($username ne 'admin') { error("$err{'011'}"); }

	open(FILE, "<$memberdir/membergroups.dat") || error("$err{'001'} $memberdir/membergroups.dat");
	@membergroups = <FILE>;
	close(FILE);

	$num = 0;
	open(FILE, ">$memberdir/membergroups.dat") || error("$err{'016'} $memberdir/membergroups.dat");
	lock(FILE);
	foreach $line (@membergroups) {
		$line =~ s/\n//g;
		if ($num eq $input{'line'}) { print FILE "$input{'lvl'}\n"; }
		else { print FILE "$line\n"; }
		$num++;
	}
	close(FILE);

	print "Location: $pageurl/$admin&op=userranks\n\n";
	exit;
}

1; # return true
