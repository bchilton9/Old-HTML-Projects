###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# forum.pl - this code handles the entire forums                              #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                             #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: forum.pl, Last modified: 18:35 08/04/2002                             #
###############################################################################
###############################################################################


#-------------------------------------------
# The routines for the forum are based on
# the free BBS-software YaBB (www.yabb.org).
#-------------------------------------------


################
sub boardindex {
################
	open(FILE, "$boardsdir/cats.txt") || error("$err{'001'} $boardsdir/cats.txt");
	@categories = <FILE>;
	close(FILE);

	open(FILE, "$memberdir/memberlist.dat") || error("$err{'001'} $memberdir/memberlist.dat");
	@memberlist = <FILE>;
	close(FILE);

	$totalm = 0;
	$totalt = 0;

	foreach $curcat (@categories) {
		$curcat =~ s/[\n\r]//g;

		open(FILE, "$boardsdir/$curcat.cat") || error("$err{'001'} $boardsdir/$curcat.cat");
		@catinfo = <FILE>;
		close(FILE);

		$catinfo[1] =~ s/[\n\r]//g;
		if ($catinfo[1] ne "") {
			if ($settings[7] ne "$root" && $settings[7] ne "$catinfo[1]") {	next; }
		}

		$curcatname = "$catinfo[0]";
		foreach $curboard (@catinfo) {
			if ($curboard ne "$catinfo[0]" && $curboard ne "$catinfo[1]") {
				$curboard =~ s/[\n\r]//g;

				open(FILE, "$boardsdir/$curboard.txt") || error("$err{'001'} $boardsdir/$curboard.txt");
				chomp(@messages = <FILE>);
				close(FILE);

				$tm = @messages;

				($dummy, $dummy, $dummy, $dummy, $dummy, $postdate, $dummy, $dummy, $dummy, $dummy, $dummy) = split(/\|/, $messages[0]);
				$boardinfo[2] =~ s/[\n\r]//g;
				$messagecount = 0;
				for ($a = 0; $a < @messages; $a++) {
					($dummy, $dummy, $dummy, $dummy, $dummy, $dummy, $mreplies, $dummy, $dummy, $dummy, $dummy, $dummy) = split(/\|/, $messages[$a]);
					$messagecount++;
					$messagecount = $messagecount+$mreplies;
				}
				$totalm = $totalm+$messagecount;
				$totalt = $totalt+$tm;
			}
		}
	}

	$navbar = "$admin{'btn2'} $nav{'003'}";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td valign="bottom"><img src="$imagesurl/forum/open.gif" width="17" height="15" border="0" alt="">&nbsp;&nbsp;
$nav{'003'}</td>
</tr>
</table>
<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td width="10" bgcolor="$windowbg">&nbsp;</td>
<td bgcolor="$windowbg"><b>$msg{'095'}</b></td>
<td nowrap align="center" bgcolor="$windowbg"><b>$msg{'096'}</b></td>
<td nowrap align="center" bgcolor="$windowbg"><b>$msg{'097'}</b></td>
<td nowrap align="center" bgcolor="$windowbg"><b>$msg{'098'}</b></td>
<td nowrap bgcolor="$windowbg"><b>$msg{'099'}</b></td>
</tr>
~;

	foreach $curcat (@categories) {
		$curcat =~ s/[\n\r]//g;

		open(FILE, "$boardsdir/$curcat.cat");
		chomp(@catinfo = <FILE>);
		close(FILE);

		$catinfo[1] =~ s/[\n\r]//g;
		if ($catinfo[1] ne "") {
			if ($settings[7] ne "$root" && $settings[7] ne "$catinfo[1]") { next; }
		}
		$curcatname = "$catinfo[0]";

		print qq~<tr>
<td width="10" valign="top" bgcolor="$windowbg3">&nbsp;</td>
<td colspan="5" bgcolor="$windowbg3"><b>$curcatname</b></td>
</tr>
~;

		foreach $curboard (@catinfo) {
			if ($curboard ne "$catinfo[0]" && $curboard ne "$catinfo[1]") {
				$curboard =~ s/[\n\r]//g;

				open(FILE, "$boardsdir/$curboard.dat");
				chomp(@boardinfo = <FILE>);
				close(FILE);

				$curboardname = "$boardinfo[0]";
				$descr = "$boardinfo[1]";

				open(FILE, "$boardsdir/$curboard.txt");
				chomp(@messages = <FILE>);
				close(FILE);

				$tm = @messages;
				if (@messages == 0) { $tm = "0"; }

				($dummy, $dummy, $dummy, $dummy, $dummy, $postdate, $dummy, $dummy, $poster, $dummy, $dummy) = split(/\|/, $messages[0]);
				$boardinfo[2] =~ s/[\n\r]//g;
				$messagecount = 0;

				for ($a = 0; $a < @messages; $a++) {
					($dummy, $dummy, $dummy, $dummy, $dummy, $dummy, $mreplies, $dummy, $dummy, $dummy, $dummy) = split(/\|/, $messages[$a]);
					$messagecount++;
					$messagecount = $messagecount+$mreplies;
				}

				open(FILE, "$memberdir/$boardinfo[2].dat");
				chomp(@modprop = <FILE>);
				close(FILE);

				$moderator = $modprop[1];

				if ($postdate eq "") { $postdate="???"; }
				$dlp = readlog("$curboard");
				$new = qq~<img src="$imagesurl/forum/off.gif" alt="">~;
				if ($dlp ne "$postdate" && $postdate ne "???" && $username ne "$anonuser") { $new = qq~<img src="$imagesurl/forum/on.gif" alt="">~; }

				if ($poster eq "") { $poster = "???"; }
				else { $poster = "$poster"; }

				print qq~<tr>
<td valign="top" width=10 bgcolor="$windowbg2">$new</td>
<td valign="top" bgcolor="$windowbg2">
<b><a href="$pageurl/$cgi?action=forum&amp;board=$curboard">$curboardname</a></b><br>
$descr</td>
<td valign="top" width="15%" align="center" bgcolor="$windowbg2">$tm</td>
<td valign="top" width="15%" align="center" bgcolor="$windowbg2">$messagecount</td>
<td valign="top" width="15%" align="center" bgcolor="$windowbg2">$postdate<br>($poster)</td>
<td valign="top" width="20%" bgcolor="$windowbg2">$moderator</td>
</tr>
~;
			}
		}
	}
	print qq~</table>
</td>
</tr>
</table>
<table width="100%">
<tr>
<td align="right">$totalm $msg{'097'}<br>
$totalt $msg{'096'}</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

##################
sub messageindex {
##################
	open (FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	chomp(@messages = <FILE>);
	close(FILE);

	$messagecount = 0;
	$threadcount = 0;

	for ($a = 0; $a < @messages; $a++) {
		($mnum[$a], $msub[$a], $mname[$a], $musername[$a], $memail[$a], $mdate[$a], $mreplies[$a], $mviews[$a], $mlpname[$a], $micon[$a], $mstate[$a]) = split(/\|/, $messages[$a]);
		$messagecount++;
		if ($mfollow[$a] == 1) { $threadcount++; }
	}

	$writedate = "$mdate[0]";
	writelog("Read forum post no $currentboard");

	$navbar = "$admin{'btn2'} $nav{'003'} $admin{'btn2'} $boardname";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td><img src="$imagesurl/forum/open.gif" width="17" height="15" border="0" alt="">&nbsp;&nbsp;
<a href="$pageurl/$cgi?action=forum&amp;board=">$nav{'003'}</a>
<br>
<img src="$imagesurl/forum/tline.gif" width="12" height="12" border="0" alt=""><img src="$imagesurl/forum/open.gif" width="17" height="15" border="0" alt="">&nbsp;&nbsp;$boardname</td>
<td align="right" valign="bottom"><a href="$forum&amp;op=post=&amp;title=start+new+thread"><img src="$imagesurl/forum/new_thread.gif" alt="$msg{'100'}" border="0"></a></td>
</tr>
</table>
<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg" width="16">&nbsp;</td>
<td bgcolor="$windowbg" width="15">&nbsp;</td>
<td bgcolor="$windowbg" width="40%"><b>$msg{'037'}</b></td>
<td bgcolor="$windowbg" width="20%"><b>$msg{'101'}</b></td>
<td bgcolor="$windowbg" width="10%" align="center"><b>$msg{'102'}</b></td>
<td bgcolor="$windowbg" width="10%" align="center"><b>$msg{'157'}</b></td>
<td bgcolor="$windowbg" width="20%" align="center"><b>$msg{'103'}</b></td>
~;

	if ($info{'start'} eq "") { $start = 0; }
	else { $start = "$info{'start'}"; }

	$numshown = 0;

	open(CENSOR, "$boardsdir/censor.txt");
	chomp(@censored = <CENSOR>);
	close(CENSOR);

	$second="$windowbg3";
	for ($b = $start; $b < @messages; $b++) {
		if ($second eq "$windowbg2") { $second="$windowbg3"; }
		else { $second="$windowbg2"; }
		$numshown++;

		$dlp = readlog("$mnum[$b]");
		$new="";
		$date1 = "$mdate[$b]";
		$date2 = "$date";

		calcdifference();

		if ($dlp ne "$date1" && $result <= $max_log_days_old && $username ne "$anonuser") { $new = qq~<img src="$imagesurl/forum/new.gif" alt="">~; }
		if ($musername[$b] ne "$anonuser") { }

		foreach $censor (@censored) {
			($word, $censored) = split(/\=/, $censor);
			$msub[$b] =~ s/$word/$censored/g;
		}

		if ($mstate[$b] == 0) { $type = "thread"; }
		if ($mreplies[$b] >= 15 || $mviews[$b] >= 75) { $type = "hotthread"; }
		if ($mreplies[$b] >= 25 || $mviews[$b] >= 100) { $type = "veryhotthread"; }
		if ($mstate[$b] == 1) { $type = "locked"; }

		$nummessages = $mreplies[$b]+1;
		$c = 0;
		$pages = "";
		if ($nummessages > $maxmessagedisplay) {
			while (($c*$maxmessagedisplay) < $nummessages) {
				$viewc = $c+1;
				$strt = ($c*$maxmessagedisplay);
				$pages = qq~$pages<a href="$forum&amp;op=display&amp;num=$mnum[$b]&amp;start=$strt">$viewc</a>~;
				$c++;
			}
			$pages =~ s/\n$//g;
			$pages = qq~( <img src="$imagesurl/forum/multipage.gif" alt=""> $pages )~;
		}

		print qq~<tr>
<td width="16" bgcolor="$second"><img src="$imagesurl/forum/$type.gif" alt=""></td>
<td width="15" bgcolor="$second"><img src="$imagesurl/forum/$micon[$b].gif" alt="" border="0" align="middle"></td>
<td width="40%" bgcolor="$second"><a href="$forum&amp;op=display&amp;num=$mnum[$b]"><b>$msub[$b]</b></a> $new $pages</td>
<td width="20%" bgcolor="$second">$mname[$b]</td>
<td width="10%" align="center" bgcolor="$second">$mreplies[$b]</td>
<td width="10%" align="center" bgcolor="$second">$mviews[$b]</td>
<td width="20%" align="center" bgcolor="$second">$mdate[$b]<br>$msg{'042'} $mlpname[$b]</td>
</tr>
~;
		$lastposter = "";
		if ($numshown >= $maxdisplay && $info{'view'} ne 'all') { $b = @messages; }
	}
	print qq~</table>
</td>
</tr>
</table>
<table border="0" width="100%">
<tr>
<td><b>$msg{'039'}</b>
~;
	$nummessages = @messages;
	$c = 0;
	while (($c*$maxdisplay) < $nummessages) {
		$viewc = $c+1;
		$strt = ($c*$maxdisplay);
		if ($start == $strt) { print "[$viewc] "; }
		else { print qq~<a href="$forum&amp;start=$strt">$viewc</a> ~; }
		++$c;
	}

	jumpto();

	print qq~</td>
<td align="right"><a href="$forum&amp;op=post&amp;title=start+new+thread"><img src="$imagesurl/forum/new_thread.gif" alt="$msg{'100'}" border="0"></a></td>
</tr>
<tr>
<td colspan="2" align="right" valign="bottom"><form action="$pageurl/$cgi" method="get">$msg{'104'} 
<input type="hidden" name="action" value="forum">
<select name="board">
$selecthtml
</select>
<input type="submit" value="$btn{'014'}">
</form></td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

#############
sub display {
#############
require "$sourcedir/security.pl";
	$viewnum = $info{'num'};
	if ($viewnum !~ /^[0-9]+$/) { error("$err{'006'}" ); }

	open(FILE, "$memberdir/membergroups.dat");
	chomp(@membergroups = <FILE>);
	close(FILE);

	open(FILE, "$messagedir/$viewnum.txt") || error("$err{'001'} $messagedir/$viewnum.txt");
	chomp(@messages = <FILE>);
	close(FILE);

	($msub, $mname, $memail, $mdate, $musername, $micon, $mip, $mmessage) = split(/\|/, $messages[@messages-1]);
	$writedate = "$mdate";
	writelog("Read forum no $viewnum");

	open(FILE, "$boardsdir/$currentboard.dat") || error("$err{'001'} $boardsdir/$currentboard.dat!");
	chomp(@boardinfo=<FILE>);
	close(FILE);

	$boardname = "$boardinfo[0]";

	open(FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	chomp(@tthreads = <FILE>);
	close(FILE);

	$d = 0;
	while ($tthreads[$d] ne '') { $d++; }
	$count = $d;
	$i = 0;

	open(FILE, ">$boardsdir/$currentboard.txt") || error("$err{'016'} $boardsdir/$currentboard.txt");
	lock(FILE);
	while ($i < $count) {
		($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $tthreads[$i]);
		if ($viewnum eq $mnum) {
			$mviews++;
			print FILE "$mnum|$msub|$mname|$musername|$memail|$mdate|$mreplies|$mviews|$mlpname|$micon|$mstate\n";
		}
		else { print FILE "$mnum|$msub|$mname|$musername|$memail|$mdate|$mreplies|$mviews|$mlpname|$micon|$mstate\n"; }

		$i++;
	}
	unlock(FILE);
	close(FILE);

	open(FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	chomp(@threads = <FILE>);
	close(FILE);

	for ($x = 0; $x < @threads; $x++) {
		($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $threads[$x]);
		if ($viewnum eq $mnum) { 
			if ($mstate == 0) { $type = "thread"; }
			if ($mreplies >= 15 || $mviews >= 75) { $type = "hotthread"; }
			if ($mreplies >= 25 || $mviews >= 100) { $type = "veryhotthread"; }
			if ($mstate == 1) { $type = "locked"; }
			$x = @threads;
		}
	}

	($msub[0], $mname[0], $memail[0], $mdate[0], $musername[0], $micon[0], $mip[0], $mmessage[0]) = split(/\|/, $messages[0]);
	$title = "$msub[0]";

	open(FILE, "$boardsdir/censor.txt");
	chomp(@censored = <FILE>);
	close(CENSOR);

	foreach $censor (@censored) {
		($word, $censored) = split(/\=/, $censor);
		$msub[0] =~ s/$word/$censored/g;
	}

	if ($enable_notification && $username ne $anonuser) { 
		$notification = qq~&nbsp;<a href="$forum&amp;op=notify&amp;thread=$viewnum"><img src="$imagesurl/forum/notify.gif" alt="$msg{'105'}" border="0"></a> ~; 
	}

	jumpto();

	if ($info{'start'} ne "") { $start = "$info{'start'}"; }
	else { $start = 0; }

	$navbar = "$admin{'btn2'} $nav{'003'} $admin{'btn2'} $boardname";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td valign="bottom"><img src="$imagesurl/forum/open.gif" width="17" height="15" border="0" alt="">&nbsp;&nbsp;
<a href="$pageurl/$cgi?action=forum&amp;board=">Forum</a>
<br>
<img src="$imagesurl/forum/tline.gif" width="12" height="12" border="0" alt=""><img src="$imagesurl/forum/open.gif" width="17" height="15" border="0" alt="">&nbsp;&nbsp;<a href="$forum">$boardname</a>
<br>
<img src="$imagesurl/forum/tline2.gif" width="24" height="12" border="0" alt=""><img src="$imagesurl/forum/open.gif" width="17" height="15" border="0" alt="">&nbsp;&nbsp;$msub[0]</td>
<td align="right" valign="bottom"><a href="$forum&amp;op=printpage&amp;num=$viewnum" target="_blank"><img src="$imagesurl/forum/print.gif" alt="$msg{'106'}" border=0></a><br>
<a href="$forum&amp;op=post&amp;num=$viewnum&amp;title=post+reply&amp;start=$start"><img src="$imagesurl/forum/reply.gif" alt="$msg{'107'}" border="0"></a>$notification</td>
</tr>
</table>
<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td><img src="$imagesurl/forum/$type.gif" alt=""></td>
<td>&nbsp;<b>$msg{'049'}</b></td>
</tr>
</table>
</td>
<td bgcolor="$windowbg"><b>$msg{'064'} $msub[0]</b></td>
</tr>
~;
	$second = "$windowbg3";
	for ($a = $start; $a < @messages; $a++) {
		if ($second eq "$windowbg2") { $second="$windowbg3"; }
		else { $second="$windowbg2"; }
		$numshown++;
		($msub[$a], $mname[$a], $memail[$a], $mdate[$a], $musername[$a], $micon[$a], $mip[$a], $mmessage[$a]) = split(/\|/, $messages[$a]);

		$subject = "$msub[$a]";
		if ($subject eq "") { $subject="---"; }
		$mmessage[$a] =~ s/\n//g;
		$message = "$mmessage[$a]";
		$name = "$mname[$a]";
		$date = "$mdate[$a]";
		
		if ($settings[7] eq "$root") { $ip = "$mip[$a]"; }
		else { $ip = "$msg{'108'}"; }
		
		$removed = 0;
		if (!(-e("$memberdir/$musername[$a].dat"))) { $removed = 1; }
		$postinfo = "";
		$signature = "";
		$viewd = "";
		$icq = "";
		$star = "";
		$sendm = "";
		if ($musername[$a] ne "$anonuser" && $removed == 0) {
			if ($username ne "$anonuser") { $sendm = qq~&nbsp;&nbsp;<a href="$pageurl/$cgi?action=imsend&amp;to=$musername[$a]"><img src="$imagesurl/forum/message.gif" alt="$msg{'109'} $mname[$a]" border="0"></a>~; }

			check_hash($musername[$a]);
			open(FILE, "$memberdir/$musername[$a].dat");
			chomp(@memset = <FILE>);
			close(FILE);

			$ranking = $memset[6]+$memset[11]+$memset[12];
		
			$postinfo = qq~$msg{'021'} $memset[6]<br>
$msg{'022'} $memset[11]<br>
$msg{'023'} $memset[12]<br>
~;

			if ($username ne "$anonuser") {
				$viewd = qq~&nbsp;&nbsp;<a href="$pageurl/$cgi?action=viewprofile&amp;username=$musername[$a]"><img src="$imagesurl/forum/profile.gif" alt="$msg{'051'} $mname[$a]" border="0"></a>~;
			}
			$memberinfo = "$membergroups[2]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
			if ($ranking > 25) {
				$memberinfo = "$membergroups[3]";
				$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
			}
			if ($ranking > 50) {
				$memberinfo = "$membergroups[4]";
				$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
			}
			if ($ranking > 75) {
				$memberinfo = "$membergroups[5]";
				$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
			}
			if ($ranking > 100) {
				$memberinfo = "$membergroups[6]";
				$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
			}
			if ($ranking > 250) {
				$memberinfo = "$membergroups[7]";
				$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
			}
			if ($ranking > 500) {
				$memberinfo = "$membergroups[8]";
				$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
			}
			if ($boardmoderator eq "$musername[$a]") { $memberinfo = "$membergroups[1]"; }
			if ($memset[7] ne "") { $memberinfo = "$memset[7]"; }
			if ($memberinfo eq "$root") { $memberinfo = "$membergroups[0]"; }
			$signature = "$memset[5]";
			$signature =~ s/\&\&/<br>/g;
			if ($signature ne "") {
				$signature = qq~<br><br><br>
-----------------<br>
$signature
~;

			}
			if (!($memset[8] =~ /\D/) && $memset[8] ne "") { $icq = qq~&nbsp;&nbsp;<a href="http://www.icq.com/$memset[8]" target="_blank"><img src="http://wwp.icq.com/scripts/online.dll?icq=$memset[8]&amp;img=5" alt="$msg{'052'} $memset[8]" border="0"></a>~; }
		}
		else { $memberinfo = "$anonuser"; }

		$message = "$message\n$signature";
		$memberpic ="";

		if ($musername[$a] ne "$anonuser") { 
			if ($memset[9] eq "") { $memset[9] = "_nopic.gif"; }
			if ($memset[9] =~ /^\http:\/\// ) {
				if ($memberpic_width ne 0) { $tmp_width = qq~width="$memberpic_width"~; } 
				else { $tmp_width = ""; }
				if ($memberpic_height ne 0) { $tmp_height = qq~height="$memberpic_height"~; } 
				else { $tmp_height = ""; }
				$memberpic = qq~<img src="$memset[9]" $tmp_width $tmp_height border="0" alt="$info{'username'}"></a>~;
			}
			else {
				$memberpic = qq~<img src="$imagesurl/avatars/$memset[9]" border="0" alt=""></a>~;
			}
		}

		if ($enable_ubbc) { doubbc(); }

		$url = "";
		if ($memset[3] ne "\n" && $musername[$a] ne "$anonuser") { $url = qq~<a href="$memset[4]" target="_blank"><img src="$imagesurl/forum/www.gif" alt="$msg{'053'} $mname[$a]" border="0"></a>&nbsp;&nbsp;~; }

		foreach $censor (@censored) {
			($word, $censored) = split(/\=/, $censor);
			$message =~ s/$word/$censored/g;
			$subject =~ s/$word/$censored/g;
		}

		if ($settings[7] ne "$root") { $ip = "$msg{'108'}"; }

		print qq~<tr>
<td bgcolor="$second" width="140" valign="top"><b>$name</b><br>
$memberpic<br>
$memberinfo<br>
$star<br><br>
$postinfo<br>
</td>
<td bgcolor="$second" valign="top">
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td><img src="$imagesurl/forum/$micon[$a].gif" alt=""></td>
<td width="100%">&nbsp;<b>$subject</b></td>
<td align="right" nowrap>&nbsp;<b>$msg{'110'}</b> $date</td>
</tr>
</table>
<hr noshade="noshade" size="1">
$message<br>
</td>
</tr>
<tr bgcolor="$second">
<td><img src="$imagesurl/forum/ip.gif" alt="$msg{'111'}" align="top"> $ip</td>
<td>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td>$url<a href="mailto:$memail[$a]"><img src="$imagesurl/forum/email.gif" alt="$msg{'055'} $mname[$a]" border="0"></a>$viewd$sendm$icq</td>
<td align="right"><a href="$forum&amp;op=post&amp;num=$viewnum&amp;quote=$a&amp;title=post+reply&amp;start=$start"><img src="$imagesurl/forum/quote.gif" alt="$msg{'056'}" border="0"></a>&nbsp;&nbsp;<a href="$forum&amp;op=modify&amp;message=$a&amp;thread=$viewnum"><img src="$imagesurl/forum/modify.gif" alt="$msg{'112'}" border="0"></a>&nbsp;&nbsp;<a href="$forum&amp;op=modify2&amp;thread=$viewnum&amp;id=$a&amp;d=1"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></td>
</tr>
</table>
</td>
</tr>
~;
		if ($numshown >= $maxmessagedisplay) { $a = @messages; }
	}

	print qq~</table>
</td>
</tr>
</table>
<table border="0" width="100%" cellspacing="1" cellpadding="2">
<tr>
<td><b>$msg{'039'}</b>
~;

	$nummessages = @messages;
	$c = 0;
	while (($c*$maxmessagedisplay) < $nummessages) {
		$viewc = $c+1;
		$strt = ($c*$maxmessagedisplay);
		if ($start == $strt) { print "[$viewc] "; }
		else { print qq~<a href="$forum$curboard&amp;op=display&amp;num=$viewnum&amp;start=$strt">$viewc</a> ~; }
		$c++;
	}

	print qq~</td>
<td align="right">
~;
	if($username eq "$boardmoderator" || $settings[7] eq "$root") { $adminfunction = qq~<a href="$forum&amp;op=movethread&amp;thread=$viewnum"><img src="$imagesurl/forum/move.gif" alt="$msg{'113'}" border="0"></a>&nbsp;<a href="$forum&amp;op=removethread&amp;thread=$viewnum"><img src="$imagesurl/forum/remove.gif" alt="$msg{'114'}" border="0"></a>&nbsp;<a href="$forum&amp;op=lockthread&amp;thread=$viewnum"><img src="$imagesurl/forum/lock.gif" alt="$msg{'115'}" border="0"></a>~; }

	print qq~$adminfunction</td>
<td align="right"><a href="$forum&amp;op=post&amp;num=$viewnum&amp;title=post+reply&amp;start=$start"><img src="$imagesurl/forum/reply.gif" alt="$msg{'107'}" border="0"></a>$notification</td>
</tr>
</table>
<div align="right"><form action="$pageurl/$cgi" method="get">
$msg{'104'} <select name="board">$selecthtml</select> <input type=submit value="$btn{'014'}">
</form></div>
~;

	print_bottom();
	exit;
}

##########
sub post {
##########
	if ($username eq $anonuser && $enable_guestposting == 0) { error("$err{'011'}"); }

	open(FILE, "$boardsdir/$currentboard.txt") || error("$err{'01'} $boardsdir/$currentboard.txt");
	chomp(@threads = <FILE>);
	close(FILE);

	for ($x = 0; $x < @threads; $x++) {
($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $threads[$x]);
		if ($info{'num'} eq $mnum && $mstate == 1) {
			error("$err{'024'}");
			$x = @threads;
		}
	}
	
	if ($enable_notification && $username ne $anonuser) {
	 $notification = qq~<tr>
<td><b>$msg{'105'}</b></td>
<td><input type="checkbox" name="notify" value="x"></td>
</tr>
~;
	}

	if ($realname ne "") { $name_field = qq~$realname<input type="hidden" name="name" value="$realname">~; }
	else { $name_field = qq~<input type="text" name="name" size="10" value="$form_name">~; }

	if ($realemail ne "") { $email_field = qq~$realemail<input type="hidden" name="email" value="$realemail">~; }
	else { $email_field = qq~<input type="text" name="email" size="50" value="$form_name">~; }

	if ($info{'num'} ne "") {
		open(FILE, "$messagedir/$info{'num'}.txt") || error("$err{'001'} $messagedir/$info{'num'}.txt");
		chomp(@messages = <FILE>);
		close(FILE);

		($msubject, $mname, $memail, $mdate, $musername, $micon, $mip, $mmessage) = split(/\|/, $messages[0]);
		$msubject =~ s/Re: //g;
		$form_subject = "Re: $msubject";

		if ($info{'quote'} ne "") {
			($msubject, $mname, $memail, $mdate, $musername, $micon, $mip, $mmessage) = split(/\|/, $messages[$info{'quote'}]);
			$form_message = "$mmessage";
			$form_message =~ s/\[quote\](\S+?)\[\/quote\]//isg;
			$form_message =~ s/\[(\S+?)\]//isg;
			$form_message = "\n\n\[quote\]$form_message\[/quote\]";
			$form_message = htmltotext($form_message);
			$msubject =~ s/Re: //g;
			$form_subject = "Re: $msubject";
		}
	}

	$navbar = "$admin{'btn2'} $nav{'036'} ";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="0" cellpadding="1">
<tr>
<td><form action="$forum&amp;op=post2&amp;start=$info{'start'}" method="post" name="creator">
<input type="hidden" name="followto" value="$info{'num'}">
<table border="0">
<tr>
<td><b>$msg{'013'}</b></td>
<td>$name_field</td>
</tr>
<tr>
<td><b>$msg{'007'}</b></td>
<td>$email_field</td>
</tr>
<tr>
<td><b>$msg{'037'}</b></td>
~;
if ($username eq $anonuser) 
{
print "<td><input type=\"text\" name=\"subject\" value=\"$form_subject\" size=\"20\" maxlength=\"20\"></td> "; 
}

else {
print qq~
<td><input type="text" name="subject" value="$form_subject" size="40" maxlength="50"></td>
~; }
print qq~
</tr>
<tr>
<td><b>$msg{'116'}</b></td>
<td><script language="javascript" type="text/javascript">
<!--
function showImage() {
document.images.icons.src="$imagesurl/forum/"+document.creator.icon.options[document.creator.icon.selectedIndex].value+".gif";
}
// -->
</script>
<select name="icon" onChange="showImage()">
<option value="xx">$msg{'143'}</option>
<option value="thumbup">$msg{'144'}</option>
<option value="thumbdown">$msg{'145'}</option>
<option value="exclamation">$msg{'146'}</option>
<option value="question">$msg{'147'}</option>
<option value="lamp">$msg{'148'}</option>
</select>
<img src="$imagesurl/forum/xx.gif" name="icons" width="15" height="15" border="0" hspace="15" alt=""></td>
</tr>
<tr>
<td valign=top><b>$msg{'038'}</b></td>
<td>
<script language="javascript" type="text/javascript">
<!--
function addCode(anystr) { 
document.creator.message.value+=anystr;
} 
function showColor(color) { 
document.creator.message.value+="[color="+color+"][/color]";
}
// -->
</script>
<textarea name="message" rows="10" cols="40">$form_message</textarea></td>
</tr>
<tr>
<td><b>$msg{'156'}</b></td>
<td valign="top"><a href="javascript:addCode('[b][/b]')"><img src="$imagesurl/forum/bold.gif" align="bottom" width="23" height="22" alt="$msg{'117'}" border="0"></a>
<a href="javascript:addCode('[i][/i]')"><img src="$imagesurl/forum/italicize.gif" align="bottom" width="23" height="22" alt="$msg{'118'}" border="0"></a>
<a href="javascript:addCode('[u][/u]')"><img src="$imagesurl/forum/underline.gif" align="bottom" width="23" height="22" alt="$msg{'119'}" border="0"></a>
<a href="javascript:addCode('[center][/center]')"><img src="$imagesurl/forum/center.gif" align="bottom" width="23" height="22" alt="$msg{'120'}" border="0"></a>
<a href="javascript:addCode('[url][/url]')"><img src="$imagesurl/forum/url.gif" align="bottom" width="23" height="22" alt="$msg{'121'}" border="0"></a>
<a href="javascript:addCode('[img][/img]')"><img src="$imagesurl/forum/img.gif" align="bottom" width="23" height="22" alt="$msg{'171'}" border="0"></a>
<a href="javascript:addCode('[email][/email]')"><img src="$imagesurl/forum/email2.gif" align="bottom" width="23" height="22" alt="$msg{'122'}" border="0"></a>
<a href="javascript:addCode('[code][/code]')"><img src="$imagesurl/forum/code.gif" align="bottom" width="23" height="22" alt="$msg{'123'}" border="0"></a>
<a href="javascript:addCode('[quote][/quote]')"><img src="$imagesurl/forum/quote2.gif" align="bottom" width="23" height="22" alt="$msg{'124'}" border="0"></a>
<a href="javascript:addCode('[list][*][*][*][/list]')"><img src="$imagesurl/forum/list.gif" align="bottom" width="23" height="22" alt="$msg{'125'}" border="0"></a>
<a href="javascript:void(0)" onClick="window.open('$pageurl/$cgi?action=showsmilies','_blank','scrollbars=yes,toolbar=no,height=270,width=270')"><img src="$imagesurl/forum/smilie.gif" align="bottom" width="23" height="22" alt="$msg{'126'}" border="0"></a><br>
<select name="color" onChange="showColor(this.options[this.selectedIndex].value)">
<option value="Black" selected>$msg{'127'}</option>
<option value="Red">$msg{'128'}</option>
<option value="Yellow">$msg{'129'}</option>
<option value="Pink">$msg{'130'}</option>
<option value="Green">$msg{'131'}</option>
<option value="Orange">$msg{'132'}</option>
<option value="Purple">$msg{'133'}</option>
<option value="Blue">$msg{'134'}</option>
<option value="Beige">$msg{'135'}</option>
<option value="Brown">$msg{'136'}</option>
<option value="Teal">$msg{'137'}</option>
<option value="Navy">$msg{'138'}</option>
<option value="Maroon">$msg{'139'}</option>
<option value="LimeGreen">$msg{'140'}</option>
</select>
</td>
</tr>
$notification
<tr>
<td align="center" colspan="2"><input type=submit value="$btn{'008'}">
<input type="reset" value="$btn{'009'}"></td>
</tr>
</table>
</form>
</td>
</tr>
</table>
~;
	if (@messages) { 
		print qq~<br>
<b>$msg{'141'}</b><br>
<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
~;
		foreach $line (@messages) {
			($trash, $tempname, $trash, $tempdate, $trash, $trash, $trash, $temppost) = split(/\|/, $line);
			$message = "$temppost";	
			if ($enable_ubbc) { doubbc(); }
			print qq~<tr>
<td bgcolor="$windowbg3">$msg{'047'} $tempname ($tempdate)</td>
</tr>
<tr>
<td bgcolor="$windowbg2">$message</td>
</tr>
~;
		}
		print qq~</table>
</td>
</tr>
</table>
~;
 	}
	else { print "<!--no summary-->"; }

	print_bottom();
	exit;
}

###########
sub post2 {
###########
	if ($username eq "$anonuser" && $enable_guestposting == 0) { error("$err{'011'}"); }

	error("$err{'013'}") unless($input{'name'});
	error("$err{'005'}") unless($input{'email'});
	error("$err{'014'}") unless($input{'subject'});
	error("$err{'015'}") unless($input{'message'});

	$name = htmlescape($input{'name'});
	$email = htmlescape($input{'email'});
	$subject = htmlescape($input{'subject'});
	$message = htmlescape($input{'message'});
	$icon = "$input{'icon'}";

	if ($username ne "$anonuser") { 
		$name = "$settings[1]";
		$email = "$settings[2]";
	}
	else {
		open(FILE, "$memberdir/memberlist.dat");
		chomp(@memberlist = <FILE>);
		close(FILE);

		if (exists $memberlist{$name}) { error("$err{'007'}"); }
		for ($a = 0; $a < @memberlist; $a++) {
			open(FILE, "$memberdir/$memberlist[$a].dat");
			chomp(@check_settings = <FILE>);
			close(FILE);

			if ($check_settings[1] eq $name) { error("$err{'007'}"); }
		}
	}
	if (length($subject) > 50) { $subject = substr($subject,0,50); }

	if ($input{'followto'} eq "") {
		opendir (DIR, "$messagedir");
		@files = readdir(DIR);
		closedir (DIR);
		@files = grep(/txt/,@files);
		@files = reverse(sort { $a <=> $b } @files);
		$postnum = @files[0];
		$postnum =~ s/.txt//;
		$postnum++;
	}
	
	open (FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	@messages = <FILE>;
	close (FILE);

	open (FILE, ">$boardsdir/$currentboard.txt") || error("$err{'016'} $boardsdir/$currentboard.txt");
	lock(FILE);
	$followto = $input{'followto'};
	if ($followto eq "") {
		print FILE "$postnum|$subject|$name|$username|$email|$date|0|0|$name|$icon\|0\n";
		print FILE @messages;
	}
	else {
		for ($a = 0; $a < @messages; $a++) {
			($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $messages[$a]);
			$mstate =~ s/[\n\r]//g;
			$mreplies++;
			if ($mnum == $followto) { print FILE "$mnum|$msub|$mname|$musername|$memail|$date|$mreplies|$mviews|$name|$micon|$mstate\n"; }
		}
		for ($a = 0; $a < @messages; $a++) {
			($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $messages[$a]);
			$mstate =~ s/[\n\r]//g;
			if ($mnum == $followto) { }
			else { print FILE "$messages[$a]"; }
		}
	}
	unlock(FILE);
	close(FILE);

	if (-e("$messagedir/$followto.txt")) { 
		open(FILE, ">>$messagedir/$followto.txt") || error("$err{'001'} $messagedir/$followto.txt"); 
	}
	else { 
		open(FILE, ">$messagedir/$postnum.txt") || error("$err{'016'} $messagedir/$postnum.txt"); 
	}
	lock(FILE);
	print FILE "$subject|$name|$email|$date|$username|$icon|$ENV{REMOTE_ADDR}|$message\n";
	unlock(FILE);
	close (FILE);
	
	if (-e("$messagedir/$followto.txt")) { $thread = "$followto"; }
	else { $thread = "$postnum"; }

	if (-e("$messagedir/$thread.mail")) { notify_users(); }
	$writedate = "$date";
	writelog("$currentboard");

	if ($username ne "$anonuser") {
		$settings[6]++;

		open(FILE, ">$memberdir/$username.dat") || error("$err{'016'} $memberdir/$username.dat");
		lock(FILE);
		for ($i = 0; $i < @settings; $i++) {
				print FILE "$settings[$i]\n";
		}
		unlock(FILE);
		close(FILE);
	}


	if ($input{'notify'}) {
		print "Location: $pageurl/$cgi\?action=forum\&board=$currentboard\&op=notify2\&thread=$thread\n\n";
	}
	else { print "Location: $pageurl/$cgi\?action=forum\&board=$currentboard\&op=display\&num=$thread\&start=$info{'start'}\n\n"; }
	exit;
}

##################
sub notify_users {
##################
	open(FILE, "$messagedir/$thread.mail");
	@mails = <FILE>;
	close(FILE);

	foreach $curmail (@mails) {
		$curmail =~ s/[\n\r]//g;
		$notifysubject = "$msg{'142'} $subject";
		$notifymessage = qq~$inf{'016'} $pageurl/$forum$curboard&op=display&num=$thread~;
		sendemail($curmail, $notifysubject, $notifymessage, $master_email);
	sendemail($settings[2], $subject, $message, $master_email);
	}
}

############
sub notify {
############
	if ($username eq "$anonuser") { error("$err{'011'}"); }

	$navbar = "$admin{'btn2'} $nav{'003'} $admin{'btn2'} $boardname";
	print_top();
	print qq~$msg{'155'}<br>
<b><a href="$pageurl/$cgi?action=forum&amp;board=$currentboard&amp;op=notify2&amp;thread=$info{'thread'}">$nav{'047'}</a> - <a href="$pageurl/$cgi?action=forum&amp;board=$currentboard&amp;op=display&num=$info{'thread'}">$nav{'048'}</a></b>
~;
	print_bottom();
	exit;
}

#############
sub notify2 {
#############
	if ($username eq "$anonuser") { error("$err{'011'}"); }

	open (FILE, "$messagedir/$info{'thread'}.mail");
	chomp(@mails = <FILE>);
	close(FILE);

	open (FILE, ">$messagedir/$info{'thread'}.mail") || error("$err{'016'} $thread.mail");
	lock(FILE);
	print FILE "$settings[2]\n";
	foreach $curmail (@mails) {
		if($settings[2] ne "$curmail") { print FILE "$curmail\n"; }
	}
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$cgi?action=forum&amp;board=$currentboard&amp;op=display&num=$info{'thread'}\n\n";
	exit;
}

###################
sub modifymessage {
###################
	open(FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	chomp(@threads = <FILE>);
	close(FILE);

	for ($x = 0; $x < @threads; $x++) {
($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $threads[$x]);
		if ($info{'thread'} eq $mnum && $mstate == 1) {
			error("$err{'024'}");
			$x = @threads;
		}
	}

	$viewnum = $info{'message'};
	$viewnum = int($viewnum);

	open (FILE, "$messagedir/$info{'thread'}.txt") || error("$err{'001'} $messagedir/$info{'thread'}.txt");
	chomp(@messages = <FILE>);
	close(FILE);

	($msubject, $mname, $memail, $mdate, $musername, $micon, $mip,  $mmessage) = split(/\|/, $messages[$viewnum]);
	$mmessage = htmltotext($mmessage);

	if($musername ne "$username" && $boardmoderator ne "$username" && $settings[7] ne "$root" || $username eq "$anonuser") { error("$err{'011'}"); }

	$navbar = "$admin{'btn2'} $nav{'003'} $admin{'btn2'} $nav{'035'}";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="0" cellpadding="1">
<tr>
<td><form action="$forum$curboard&op=modify2" method="post" name="creator">
<input type="hidden" name="viewnum" value="$viewnum">
<input type="hidden" name="thread" value="$info{'thread'}">
<table border="0">
<tr>
<td><b>$msg{'013'}</b></td>
<td>$mname</td>
</tr>
<tr>
<td><b>$msg{'007'}</b></td>
<td>$memail</td>
</tr>
<tr>
<td><b>$msg{'037'}</b></td>
<td><input type=text name="subject" value="$msubject" size="40" maxlength="50"></font></td>
</tr>
<tr>
<td><b>$msg{'116'}</b></td>
<td><script language="javascript" type="text/javascript">
<!--
function showImage() {
document.images.icons.src="$imagesurl/forum/"+document.creator.icon.options[document.creator.icon.selectedIndex].value+".gif";
// -->
}
</script>
<select name="icon" onChange="showImage()">
<option value="$micon">$msg{'142'}</option>
<option value="$micon">------------</option>
<option value="xx">$msg{'143'}</option>
<option value="thumbup">$msg{'144'}</option>
<option value="thumbdown">$msg{'145'}</option>
<option value="exclamation">$msg{'146'}</option>
<option value="question">$msg{'147'}</option>
<option value="lamp">$msg{'148'}</option>
</select>
<img src="$imagesurl/forum/smilies/$micon.gif" name="icons" width="15" height="15" border="0" hspace="15"></td>
</tr>
<tr>
<td valign="top"><b>$msg{'038'}</b></td>
<td><script language="javascript" type="text/javascript">
<!--
function addCode(anystr) { 
document.creator.message.value+=anystr;
} 
function showColor(color) { 
document.creator.message.value+="[color="+color+"][/color]";
}
// -->
</script>
<textarea name="message" rows="10" cols="40">$mmessage</textarea></td>
</tr>
<tr>
<td><b>$msg{'156'}</b></td>
<td valign="top"><a href="javascript:addCode('[b][/b]')"><img src="$imagesurl/forum/bold.gif" align="bottom" width="23" height="22" alt="$msg{'117'}" border="0"></a>
<a href="javascript:addCode('[i][/i]')"><img src="$imagesurl/forum/italicize.gif" align="bottom" width="23" height="22" alt="$msg{'118'}" border="0"></a>
<a href="javascript:addCode('[u][/u]')"><img src="$imagesurl/forum/underline.gif" align="bottom" width="23" height="22" alt="$msg{'119'}" border="0"></a>
<a href="javascript:addCode('[center][/center]')"><img src="$imagesurl/forum/center.gif" align="bottom" width="23" height="22" alt="$msg{'120'}" border="0"></a>
<a href="javascript:addCode('[url][/url]')"><img src="$imagesurl/forum/url.gif" align="bottom" width="23" height="22" alt="$msg{'121'}" border="0"></a>
<a href="javascript:addCode('[img][/img]')"><img src="$imagesurl/forum/img.gif" align="bottom" width="23" height="22" alt="$msg{'171'}" border="0"></a>
<a href="javascript:addCode('[email][/email]')"><img src="$imagesurl/forum/email2.gif" align="bottom" width="23" height="22" alt="$msg{'122'}" border="0"></a>
<a href="javascript:addCode('[code][/code]')"><img src="$imagesurl/forum/code.gif" align="bottom" width="23" height="22" alt="$msg{'123'}" border="0"></a>
<a href="javascript:addCode('[quote][/quote]')"><img src="$imagesurl/forum/quote2.gif" align="bottom" width="23" height="22" alt="$msg{'124'}" border="0"></a>
<a href="javascript:addCode('[list][*][*][*][/list]')"><img src="$imagesurl/forum/list.gif" align="bottom" width="23" height="22" alt="$msg{'125'}" border="0"></a>
<a href="javascript:void(0)" onClick="window.open('$pageurl/$cgi?action=showsmilies','_blank','scrollbars=yes,toolbar=no,height=270,width=270')"><img src="$imagesurl/forum/smilie.gif" align="bottom" width="23" height="22" alt="$msg{'126'}" border="0"></a><br>
<select name="color" onChange="showColor(this.options[this.selectedIndex].value)">
<option value="Black" selected>$msg{'127'}</option>
<option value="Red">$msg{'128'}</option>
<option value="Yellow">$msg{'129'}</option>
<option value="Pink">$msg{'130'}</option>
<option value="Green">$msg{'131'}</option>
<option value="Orange">$msg{'132'}</option>
<option value="Purple">$msg{'133'}</option>
<option value="Blue">$msg{'134'}</option>
<option value="Beige">$msg{'135'}</option>
<option value="Brown">$msg{'136'}</option>
<option value="Teal">$msg{'137'}</option>
<option value="Navy">$msg{'138'}</option>
<option value="Maroon">$msg{'139'}</option>
<option value="LimeGreen">$msg{'140'}</option>
</select>
</td>
</tr>
<tr>
<td align=center colspan="2"><input type="submit" name="moda" value="$btn{'015'}"><input type="submit" name="moda" value="$btn{'016'}"></td>
</tr>
</table>
</form>
</td>
</tr>
</table>
~;

	print_bottom();
	exit;
}

####################
sub modifymessage2 {
####################
require "$sourcedir/security.pl";
	if ($info{'d'} eq "1") {
		if($username ne "$boardmoderator" && $settings[7] ne "$root") { error("$err{'011'}"); }
		$input{'viewnum'} = "$info{'id'}";
		$input{'thread'} = $info{'thread'};
		$input{'moda'} = "$btn{'016'}";
	}

	check_hash($input{'thread'});
	open (FILE, "$messagedir/$input{'thread'}.txt") || error("$err{'001'} $messagedir/$input{'thread'}.txt");
	@messages = <FILE>;
	close(FILE);

	for ($a = 0; $a < @messages; $a++) { 
		($msub[$a], $mname[$a], $memail[$a], $mdate[$a], $musername[$a], $micon[$a], $mip[$a], $mmessage[$a]) = split(/\|/, $messages[$a]);
	}
	$count = $a;
	if ($input{'viewnum'} == 0 && $count > 1 && $input{'moda'} eq $btn{'016'}) { error("$err{'025'}"); }
	if ($a eq $input{'viewnum'}) {
		if ($musername[$a] ne "$username" && (!exists $moderators{$username}) && $settings[7] ne "$root" || $username eq "$anonuser") { error("$err{'011'}"); }
	}

	open (FILE, ">$messagedir/$input{'thread'}.txt") || error("$err{'001'} $messagedir/$input{'thread'}.txt");
	lock(FILE);
	for ($x = 0; $x < @messages; $x++) {
		if ($input{'viewnum'} eq $x) {
			if ($input{'moda'} eq $btn{'016'}) {
				open (FILE2, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.dat");
				@threads = <FILE2>;
				close (FILE2);

				open (FILE2, ">$boardsdir/$currentboard.txt") || error("$err{'016'} $boardsdir/$currentboard.dat");
				lock(FILE2);
				for ($a = 0; $a < @threads; $a++) {
					if ($x == (@messages-1)) { $tdate = "$mdate[@messages-2]"; }
					if ($x == (@messages-1)) { $tlpname = "$mname[@messages-2]"; }
					else { $tdate = "$mdate[$x]"; }

					($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $threads[$a]);
					$mstate =~ s/[\n\r]//g;
					$mreplies--;

					if ($mnum == $input{'thread'}) { 
						print FILE2 "$mnum|$msub|$mname|$musername|$memail|$tdate|$mreplies|$mviews|$tlpname|$micon|$mstate\n"; 
					}
					else { print FILE2 "$threads[$a]"; }
				}
				unlock(FILE2);
				close(FILE2);

				if($musername[$x] ne "$anonuser") {
					open(FILE2, "$memberdir/$musername[$x].dat") || error("$err{'010'}");
					chomp(@memsett = <FILE2>);
					close(FILE2);

					$memsett[6]--;
					open(FILE2, ">$memberdir/$musername[$x].dat") || error("$err{'016'} $memberdir/$musername[$x].dat");
					lock(FILE2);
					for ($i = 0; $i < @memsett; $i++) {
						print FILE2 "$memsett[$i]\n";
					}
					unlock(FILE2);
					close(FILE2);
				}
			}
			else {
				$name = htmlescape($input{'name'});
				$email = htmlescape($input{'email'});
				$subject = htmlescape($input{'subject'});
				$message = htmlescape($input{'message'});
				$icon = "$input{'icon'}";
				
				if ($input{'viewnum'} == 0) {
					open (FILE2, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.dat");
					@threads = <FILE2>;
					close (FILE2);

					open (FILE2, ">$boardsdir/$currentboard.txt");
					lock(FILE2);
					for ($a = 0; $a < @threads; $a++) {
						($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/, $threads[$a]);
						$mstate =~ s/[\n\r]//g;
						if ($mnum eq "$input{'thread'}") { 
							print FILE2 "$mnum|$subject|$mname|$musername|$memail|$mdate|$mreplies|$mviews|$mlpname|$icon|$mstate\n"; 
						}
						else { print FILE2 "$threads[$a]"; }
					}
					unlock(FILE2);
					close(FILE2);
				}

				print FILE "$subject|$mname[$x]|$memail[$x]|$mdate[$x]|$musername[$x]|$icon|$ENV{REMOTE_ADDR}|$message\n";
			}
		}
		else { print FILE $messages[$x]; }
	}
	unlock (FILE);
	close (FILE);

	print "Location: $pageurl/$cgi\?action=forum\&board=$currentboard\&op=display\&num=$input{'thread'}\n\n";
	exit;
}

################
sub movethread {
################
	if($username ne "$boardmoderator" && $settings[7] ne "$root") { error("$err{'011'}"); }

	open(FILE, "$boardsdir/cats.txt") || error("$err{'001'} $boardsdir/cats.txt");
	chomp(@categories = <FILE>);
	close(FILE);

	foreach $curcat (@categories) {
		open(CAT, "$boardsdir/$curcat.cat") || error("$err{'001'} $boardsdir/$curcat.cat");
		chomp(@catinfo = <CAT>);
		close(CAT);

		$curcatname="$catinfo[0]";
		foreach $curboard (@catinfo) {
			if($curboard ne "$catinfo[0]" && $curboard ne "$catinfo[1]") {
				$boardlist="$boardlist<option>$curboard</option>";
			}
		}
	}

	$navbar = "$admin{'btn2'} $nav{'046'}";
	print_top();
	print qq~<form action="$forum$curboard&op=movethread2&thread=$info{'thread'}" method="post">
<b>$msg{'151'}</b> <select name="toboard">$boardlist</select>
<input type="submit" value="Move">
</form>
~;
	print_bottom();
	exit;

}

#################
sub movethread2 {
#################
require "$sourcedir/security.pl";
	if($username ne "$boardmoderator" && $settings[7] ne "$root") { error("$err{'011'}"); }

	open (FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	@threads = <FILE>;
	close (FILE);

	open (FILE, ">$boardsdir/$currentboard.txt") || error("$err{'016'} $boardsdir/$currentboard.txt");
	lock(FILE);
	for ($a = 0; $a < @threads; $a++) {
		($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/,$threads[$a]);
		$mstate =~ s~[\n\r]~~g;
		if ($mnum ne $info{'thread'}) { print FILE "$threads[$a]"; }
		else { $linetowrite = "$threads[$a]"; }
	}
	unlock(FILE);
	close(FILE);
	
	check_hash($input{'toboard'});
	open (FILE, "$boardsdir/$input{'toboard'}.txt") || error("$err{'001'} $input{'toboard'}.txt");
	@threads = <FILE>;
	close (FILE);

	open (FILE, ">$boardsdir/$input{'toboard'}.txt") || error("$err{'016'} $boardsdir/$input{'toboard'}.txt");
	lock(FILE);
	print FILE "$linetowrite";
	foreach $line (@threads) {
		print FILE "$line";
	}
	unlock(FILE);
	close(FILE);
	
	print "Location: $pageurl/$cgi\?action=forum\&board=$currentboard\&op=display\&num=$info{'thread'}\n\n";
	exit;
}

##################
sub removethread {
##################
	if($username ne "$boardmoderator" && $settings[7] ne "$root") { error("$err{'011'}"); }

	$navbar = "$admin{'btn2'} Remove Thread";
	print_top();
	print qq~$msg{'152'}<br>
<a href="$forum$curboard&op=removethread2&thread=$info{'thread'}">$nav{'047'}</a> - <a href="$pageurl/$cgi\?action=forum\&board=$currentboard\&op=display\&num=$info{'thread'}">$nav{'048'}</a>
~;
	print_bottom();
	exit;

}

###################
sub removethread2 {
###################
require "$sourcedir/security.pl";
	if($username ne "$boardmoderator" && $settings[7] ne "$root") { error("$err{'011'}"); }

	check_hash($info{'thread'});
	open (FILE, "$messagedir/$info{'thread'}.txt") || error("$err{'001'} $messagedir/$info{'thread'}.txt");
	@messages = <FILE>;
	close(FILE);

	if (@messages != 0) { error("$err{'025'}"); }

	open (FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	@threads = <FILE>;
	close (FILE);

	open (FILE, ">$boardsdir/$currentboard.txt") || error("$err{'016'} $boardsdir/$currentboard.txt");
	lock(FILE);
	for ($a = 0; $a < @threads; $a++) {
		($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/,$threads[$a]);
		$mstate =~ s~[\n\r]~~g;
		if ($mnum ne $info{'thread'}) { print FILE "$threads[$a]"; }
	}
	unlock(FILE);
	close(FILE);

	unlink("$messagedir/$info{'thread'}.txt");
	unlink("$messagedir/$info{'thread'}.mail");
	print "Location: $pageurl/$cgi\?action=forum\&board=$currentboard\n\n";
	exit;
}

################
sub lockthread {
################
	if($username ne "$boardmoderator" && $settings[7] ne "$root") { error("$err{'011'}"); }

	open (FILE, "$boardsdir/$currentboard.txt") || error("$err{'001'} $boardsdir/$currentboard.txt");
	@threads = <FILE>;
	close (FILE);

	open (FILE, ">$boardsdir/$currentboard.txt") || error("$err{'016'} $boardsdir/$currentboard.txt");
	lock(FILE);
	for ($a = 0; $a < @threads; $a++) {
		($mnum, $msub, $mname, $musername, $memail, $mdate, $mreplies, $mviews, $mlpname, $micon, $mstate) = split(/\|/,$threads[$a]);
		$mstate =~ s~[\n\r]~~g;
		if ($mnum eq $info{'thread'}) {
			if ($mstate == 1) { $mnewstate = 0; }
			else { $mnewstate = 1; }
			print FILE "$mnum|$msub|$mname|$musername|$memail|$date|$mreplies|$mviews|$name|$micon|$mnewstate\n";
		}
		else { print FILE "$threads[$a]"; }
	}
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$cgi\?action=forum\&board=$currentboard\&op=display\&num=$info{'thread'}\n\n";
	exit;
}

############
sub jumpto {
############
	opendir (DIRECTORY, "$boardsdir"); 
	@dirdata = readdir(DIRECTORY);
	closedir (DIRECTORY);
	@datfiles = grep(/\.dat/, @dirdata);

	foreach $category (@datfiles) {
		($grabtxtfile, $trash) = split(/\./, $category);
		open(FILE, "$boardsdir/$category") || next;
		chomp(@newcatdata = <FILE>);
		close(FILE);
		$selecthtml .= qq~<option value="$grabtxtfile">@newcatdata[0]</option>~;
	}
}

###############
sub printpage {
###############
require "$sourcedir/security.pl";
	if ($info{'num'} ne "") {
		check_hash($info{'num'});
		open(FILE, "$messagedir/$info{'num'}.txt") || error("$err{'001'} $messagedir/$info{'num'}.txt");
		chomp(@messages = <FILE>);
		close(FILE);

		($title, $dummy, $dummy, $dummy, $dummy, $dummy, $dummy, $dummy) = split(/\|/, $messages[0]);

		print "Content-type: text/html\n\n";
		print qq~<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
    
<html>

<head>
$mtag
<meta name="Generator" content="$scriptname $scriptver">
<title>$title</title>
</head>

<body bgcolor="#ffffff" text="#000000">
<h1 align="center">$title</h1>
~;
		foreach $line (@messages) {
			($subject, $name, $dummy, $date, $dummy, $dummy, $dummy, $message) = split(/\|/, $line);
			if ($enable_ubbc) { doubbc(); }
			print qq~<hr size=2 width="100%">
<h3>$subject</h3>
<b>$msg{'047'} $name ($date)</b><br>
<p>$message</p>
~;
		}
		print qq~</body>

</html>
~;
	}
}

1; # return true
