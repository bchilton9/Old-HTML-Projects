################
sub maintool {
################

if ($info{'tools'} eq "counter") { &maincounter();}
if ($info{'tools'} eq "cstat") { &cstats();}

&toolslist();

}

################
sub toolslist {
################

$navbar = "$admin{'btn2'} Homepage Tool";
print_top();
print qq~ <center><big><big>User Homepage Tool</big></big><br><p></center>

<ul><li> Counter</ul><br>
To have counter on your website just put this code on you HTML page :<br>

&lt;script language=\"javascript\"
src=\"$pageurl/$cgi\?action=homepagetools\&tools=counter\&user=$username\"&gt;
&lt;/script&gt;<p><hr>
<ul><li> Site Statistics</ul><br>
<a href=\"$pageurl/$cgi\?action=homepagetools\&tools=cstat\&user=$username\">View Stat</a><br>
To view your site statistics you must put counter code on your website, the
logging procedure are integrated with the counter<p><hr>~;

print_bottom();

};

###########
sub cstats {
###########
	$|++;
	$navbar = "$admin{'btn2'} Homepage Tools $admin{'btn2'} Counter Stat";
	cparse_log();
	print_top();
	if ($username eq $anonuser) { error("$err{'011'}"); }
	ctopbar();
	chtml_browser();
	cos_system();
	print_bottom();
	exit;
}

###############
sub cparse_log {
###############
	open(CDATA,"$userspacedir/$info{'user'}/logs/stats/stats.dat") || error("$err{'001'} $userspacedir/$info{'user'}/logs/stats.dat");
	@clines = <CDATA>;
	close(CDATA);
	$ctotal = @clines;
	foreach $cline (@clines) {
		if ($cline =~ /(.*) - (.*) - \"(.*)\" - \"(.*)\"/) {
			$date = $1;
			($weekday, $day, $time) = split(/ /, $date);
			($hour, $minute) = split(/:/, $time);
			($temp, $month,$year) = split (/-/, $day);
			$host_name = $2;
			$user_agent = $3;
			$referer = $4;
			$day = "$day "."$weekday";
			$referer{$referer}++;
			$day{$day}++;
			$week_days{$weekday}++;
			$hour{$hour}++;
			push(@user_agents, $user_agent);
		}
	}
	$total_agent = @user_agents;
	if ($top_os == 1) {
		$os{'Windows'} = 0;
		$os{'Mac/PPC'} = 0;
		$os{'Linux'} = 0;
		$os{'SunOS'} = 0;
		$os{'BSD'} = 0;
		$os{'AIX'} = 0;
		$os{'OS/2'} = 0;
		$os{'Irix'} = 0;
		$os{'BeOS'} = 0;
		$os{"$msg{'067'}"} = 0;

		foreach $user_agent (@user_agents) {
			if ($user_agent =~ /MSIE/i) {
				if ($user_agent =~~ /Windows 95/i || $user_agent =~ /Windows 98/i || $user_agent =~ /Windows NT/i) {
					$os{'Windows'}++;
					next;
				}
				elsif ($user_agent =~ /Mac_PowerPC/i || $user_agent =~ /Macintosh/i) {
					$os{'Mac/PPC'}++;
					next;
				}
			}
			elsif  ($user_agent =~ /Windows 95/i || $user_agent =~ /Windows 98/i || $user_agent =~ /Windows NT/i) {
				$os{'Windows'}++;
		   		next;
			}
			elsif ($user_agent =~ /Mac_PowerPC/i || $user_agent =~ /Macintosh/i) {
				$os{'Mac/PPC'}++;
				next;
			}
			elsif  ($user_agent =~ /X11/i) {
				if  ($user_agent =~ /Linux/i) {
					$os{'Linux'}++;
					next;
				}
				elsif  ($user_agent =~ /SunOS/i) {
					$os{'SunOS'}++;
					next;
			   	}
			   	elsif  ($user_agent =~ /AIX/i) {
			   		$os{'AIX'}++;
		   			next;
	   			}
				elsif  ($user_agent =~ /Irix/i) {
					$os{'Irix'}++;
					next;
				}
			   	else {
	   				$os{'BSD'}++;
		   			next;
			   	}
			}
			elsif  ($user_agent =~ /Linux/i) {
				$os{'Linux'}++;
				next;
			}
			elsif  ($user_agent =~ /Win16/i || $user_agent =~ /Windows 3\.1/i) {
				$os{'Windows'}++;
				next;
			}
			elsif  ($user_agent =~ /OS\/2/i) {
				$os{'OS/2'}++;
				next;
			}
			elsif  ($user_agent =~ /BeOS/i) {
				$os{'BeOS'}++;
				next;
			}
			else {
				$os{"$msg{'067'}"}++;
				next;
			}
		}
	}
	if ($top_browsers == 1) {
		$browser{'Opera'} = 0;
		$browser{'Lynx'} = 0;
		$browser{'MSIE'} = 0;
		$browser{"$msg{'066'}"} = 0;
		$browser{'Konqueror'} = 0;
		$browser{'WebTV'} = 0;
		$browser{'Netscape'} = 0;
		$browser{"$msg{'067'}"} = 0;

		foreach $agent (@user_agents) {
			if ($agent =~ /Opera/i) {
				$browser{'Opera'}++;
				next;
			}
			elsif ($agent =~ /Lynx/i) {
				$browser{"Lynx"}++;
				next;
			}
			elsif ($agent =~ /Konqueror\/(\d)/i || $agent =~ /Konqueror (\d)/i) {
				$browser{"Konqueror"}++;
				next;
			}
			elsif ($agent =~ /WebTV/i || $agent =~ /WebTV (\d)/i) {
				$browser{"WebTV"}++;
				next;
			}
			elsif ($agent =~ /ArchitextSpider/i || $agent =~ /Scooter/i || $agent =~ /InfoSeek/i || $agent =~ /Lycos/i || $agent =~ /Slurp/i || $agent =~ /UltraSeek/i || $agent =~ /libwww-perl/i) {
				$browser{"$msg{'066'}"}++;
				next;
			}

			elsif ($agent =~ /MSIE/i) {
				if ($agent =~ /MSIE (\d)/i) {
					$browser{"MSIE"}++;
					next;
				}
				else {
					$browser{"$msg{'066'}"}++;
				}
			}
			elsif ($agent =~ /Mozilla/i) {
				if ($agent =~ /Mozilla\/5/i || $agent =~ /Mozilla 5/i) {
					$browser{'Netscape'}++;
					next;
				}
				elsif ($agent =~ /Mozilla\/(\d)/i || $agent =~ /Mozilla (\d)/i) {
					$browser{"Netscape"}++;
					next;
				}
				else {
					$browser{"$msg{'066'}"}++;
				}
			}
			elsif ($agent ne "") {
				$browser{"$msg{'067'}"}++;
				next;
			}
			else {
				$browser{"$msg{'067'}"}++;
			}
		}
	}
	foreach $count (keys %day) {
		$total_days++;
	}
	$hits_per_day = sprintf ("%.2f",($total/$total_days));
	$hits_per_hour = sprintf ("%.2f",($total/$total_days/24));
}

############
sub ctopbar {
############
	print qq~<table border="0" cellspacing="0" cellpadding="1" align="center">
<tr>
<td><b>$msg{'068'}</b></td>
<td colspan="2"><b>$total</b></td>
</tr>
<tr>
<td><b>$msg{'069'}</b></td>
<td colspan="2"><b>$total_days</b></td>
</tr>
<tr>
<td><b>$msg{'070'}</b></td>
<td colspan="2"><b>$hits_per_day</b></td>
</tr>
<tr>
<td><b>$msg{'071'}</b></td>
<td colspan="2"><b>$hits_per_hour</b></td>
</tr>
</table>
~;
}

##################
sub chtml_browser {
##################
	print qq~<br><br>
<table align="center" border="0" cellspacing="0" cellpadding="2">
<tr>
<td align="center" colspan="4"><b>$msg{'072'}</b></td>
</tr>
~;
	my $flag=0;
	my $num=0;
	my ($top_pos, $img_width, $percent);
	foreach $brow (sort { $browser{$b} <=> $browser{$a} } keys %browser) {
		$top_pos = $browser{$brow} if ($flag == 0);
		$img_width = int($browser{$brow}*200/$top_pos);
		$percent = sprintf ("%.2f", ($browser{$brow}/$total_agent*100));
		$brow_pic = $brow;
		$brow_pic =~ tr/A-Z/a-z/;
		if ($brow eq "$msg{'066'}") { $brow_pic = "searchengines"; }
		if ($brow eq "$msg{'067'}") { $brow_pic = "unknown"; }
		print qq~<tr>
<td><img src="$imagesurl/stats/$brow_pic.gif" alt=""></td>
<td>$brow</td>
<td>$browser{$brow}</td>
<td><img src="$imagesurl/leftbar.gif" width="7" height="14" alt=""><img src="$imagesurl/mainbar.gif" width="$img_width" height="14" alt=""><img src="$imagesurl/rightbar.gif" width="7" height="14" alt=""> $percent\%</td>
</tr>
~;
		$flag = 1;
	}
	print "</table>\n";
}

###############
sub cos_system {
###############
	print qq~<br><br>
<table align="center" border="0" cellspacing="0" cellpadding="2">
<tr>
<td align="center" colspan="4"><b>$msg{'073'}</b></td>
</tr>
~;
	my $flag = 0;
	my $num = 0;
	my ($top_pos, $img_width, $percent);
	foreach $os_sys (sort { $os{$b} <=> $os{$a} } keys %os) {
		$top_pos = $os{$os_sys} if ($flag == 0);
		$img_width = int($os{$os_sys}*200/$top_pos);
		$percent = sprintf ("%.2f", ($os{$os_sys}/$total_agent*100));
		$os_pic = $os_sys;
		$os_pic =~ tr/A-Z/a-z/;
		if ($os_pic eq "mac/ppc") { $os_pic = "mac"; }
		if ($os_pic eq "os/2") { $os_pic = "os2"; }
		if ($os_sys eq "$msg{'067'}") { $os_pic = "unknown"; }
		print qq~<tr>
<td><img src="$imagesurl/stats/$os_pic.gif" alt=""></td>
<td width="90">$os_sys</td>
<td>$os{$os_sys}</td>
<td><img src="$imagesurl/leftbar.gif" width="7" height="14" alt=""><img src="$imagesurl/mainbar.gif" width="$img_width" height="14" alt=""><img src="$imagesurl/rightbar.gif" width="7" height="14" alt=""> $percent\%</td>
</tr>
~;
		$flag = 1;
	}
	print "</table>\n";
}

############
sub clogips {
############
	@cskip = ('127.0.0.1');
	$cip_time = 5;
	$ccheck = 0;

	if (@cskip) {
		foreach $cips (@cskip) {
			if ($ENV{'REMOTE_ADDR'} =~ /$cips/) {
				$ccheck = 1;
				last;
			}
		}
	}
	if ($ccheck == 0) { 
		my $cthis_time = time();

		open(CFILE,"$userspacedir/$info{'user'}/logs/stats/ip.log");
		lock(CFILE);
		my @clines = <CFILE>;
		unlock(CFILE);
		close(CFILE);

		open(CFILE,">$userspacedir/$info{'user'}/logs/stats/ip.log");
		lock(CFILE);
		foreach $cvisitor (@clines) {
			($ip_addr,$time_stamp) = split(/\|/, $cvisitor);
			if ($cthis_time < $time_stamp + (60*$cip_time)) {
				if ($ip_addr eq $ENV{'REMOTE_ADDR'}) { $ccheck = 1; }
				else { print FILE "$ip_addr|$time_stamp"; }
			}
		}
		print CFILE "$ENV{'REMOTE_ADDR'}|$cthis_time\n";
		unlock(CFILE);
		close(CFILE);
	}

	if ($ccheck == 0) { 
		if ($ENV{'REMOTE_HOST'}) { $host = $ENV{'REMOTE_HOST'}; }
		else {
			$ip_address = $ENV{'REMOTE_ADDR'};
			@numbers = split(/\./, $ip_address);
			$ip_number = pack("C4", @numbers);
			$host = (gethostbyaddr($ip_number, 2))[0];
		}
		if ($host eq "") { $host = "$ENV{'REMOTE_ADDR'}"; }

		($value, $referer) = split(/=/, $query);
		if ($referer) {
			if ($referer =~ /(http:\/\/.*\.[a-z]{2,4}\/)/i) { $referer = $1; }
		}
		else { $referer = "-"; }

		open(CDATA, ">>$userspacedir/$info{'user'}/logs/stats/stats.dat");
		lock(CDATA);
		print CDATA ("$logdate - $host - \"$ENV{'HTTP_USER_AGENT'}\" - \"$referer\"\n");
		unlock(CDATA);
		close (CDATA);
	}
}

##################
sub maincounter {
##################

$counter_file = "$userspacedir/$info{'user'}/logs/counter/counter.txt";
@img_files=("0.gif","1.gif","2.gif","3.gif","4.gif","5.gif","6.gif","7.gif","8.gif","9.gif");
$data_dir="$imagesurl/homepagetools/counter";

open (file, $counter_file);
$counter=<file>;
close (file);

$counter++;

open (file,">$counter_file");
print file $counter;
close (file);

clogsip();

$i=0;

print "Content-type: text/html\n\n";

until ($i == length($counter)) {
$temp=substr($counter,$i,1);


print "document.write('<img src=\"";
print "$data_dir/$img_files[$temp]";
print "\">');";

$i++;
}
exit;
}

1;
