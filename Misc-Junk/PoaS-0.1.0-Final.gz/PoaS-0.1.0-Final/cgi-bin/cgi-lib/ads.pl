###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                        #
#-----------------------------------------------------------------------------#
# ads.pl - this code handles the rotating banners                            #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                             #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: ads.pl, Last modified: 18:52 08/28/2002                             #
###############################################################################
###############################################################################

sub check_ads_setting {

	open(FILEB, "$datadir/banners/setting.dat");
	chomp(@setads = <FILEB>);
	close(FILEB);

	foreach $lineads (@setads) {
		@itemads = split(/\|/, $lineads);
		if ($itemads[0] eq "Top") {
			if ($itemads[1] eq 1) {
			$top_ads = 1;
			}
			else  {
				$top_ads = 0;
			}
		}
		if ($itemads[0] eq "Bottom") {
			if ($itemads[1] eq 1) {
			$bottom_ads = 1;
			}
			else  {
				$bottom_ads = 0;
			}
		}
	}
}		


sub OutputAd {

$file_dat="$datadir/banners/data.txt"; # Name of data file which contains the banners
$align='center';      # (left, center, right)
$border=0;            # (0=No border)
$showtxt=1;           # (0=Don�t show text, 1=Show text)

################################################
# NOTHING BELOW THIS LINE NEEDS TO BE ALTERED! #
################################################


open (DAT,"<$file_dat");
 @buffer=<DAT>;
close (DAT);

$bans = @buffer;

$roll= int(rand $bans);
($nomer, $img, $url, $txt) = split(/\|/,$buffer[$roll]);
chomp($txt);

print "<p align=\"$align\">\n";
print "<a href=\"http://$url\" target=\"_top\">\n";
print "<img src=\"http://$img\" border=\"$border\" alt=\"$txt\">";
if ($showtxt) {
 print "<br>\n$banner{'001'} - <font size=\"2\">$txt</font>";
}
print "</a>\n</p>\n";

}
1;
