###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# downloads.pl - this code handles the links collection                       #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                         #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: downloads.pl, Last modified: 18:16 08/04/2002                             #
###############################################################################
###############################################################################


################
sub downloads {
################
require "$sourcedir/security.pl";

	check_hash($info{'cat'});
	if ($info{'cat'} eq "") {
		open(CAT, "$downloadsdir/downloadcats.dat") || error("$err{'001'} $downloadsdir/downloadcats.dat");
		@cats = <CAT>;
		close(CAT);

		open(CNT, "$downloadsdir/downloadcats.cnt") || error("$err{'001'} $downloadsdir/downloadcats.cnt");
		$catscount = <CNT>;
		close(CNT);

		$navbar = "$admin{'btn2'} $nav{'056'}";
		print_top();
		print qq~<table align="center" border="0" cellpadding="3" cellspacing="0">
<tr>
~;
		foreach $category (@cats) {
			@fields = split (/\|/, $category);
			if (-e "$downloadsdir/$fields[1].dat") {
				open(CNTFILE,"$downloadsdir/$fields[1].cnt");
				$cnt = <CNTFILE>;
				close(CNTFILE);
				print qq~<td valign="top" width="50%">
<table>
<tr>
<td colspan="2"><b><a href="$pageurl/$cgi?action=downloads&amp;cat=$fields[1]">$fields[0]</a></b> <i>($cnt)</i></td>
</tr>
<tr>
<td width="20">&nbsp;</td>
<td>$fields[2]</td>
</tr>
</table>
</td>
~;
			} 
			else {
				print qq~<td valign="top" width="50%">
<table>
<tr>
<td colspan="2"><b>$fields[0]</b> <i>(0)</i></td>
</tr>
<tr>
<td width="20">&nbsp;</td>
<td>$fields[2]</td>
</tr>
</table>
</td>
~;
			}
			$count++;
			if ($count == 2) {
				print qq~</tr>
<tr>
~;
				$count = 0;
		
			}
		}

		if ($catscount == 1) { $downloadscount = "$msg{'084'} <b>1</b> $msg{'169'}"; }
		else { $downloadscount = "$msg{'086'} <b>$catscount</b> $msg{'170'}"; }

		print qq~<td></td>
</tr>
</table>
<br>
<table align="center" border="0" cellpadding="3" cellspacing="0">
<tr>
<td align="center">$downloadscount</td>
</tr>
<tr>
<td></td>
</tr>
~;
	if($username ne "$anonuser") {
		print qq~<tr>
<td align="center"><a href="$pageurl/$cgi?action=adddownload">$nav{'058'}</a></td>
</tr>
~;
	}
	else {
	print qq~<tr>
<td></td>
</tr>
~;
	}
	print "</table>\n";
	print_bottom();
	exit;
	}
	else {
		open(DLNCATS, "$downloadsdir/downloadcats.dat") || error("$err{'001'} $downloadsdir/downloadcats.dat");
		@catsname = <DLNCATS>;
		close(DLNCATS);

		for ($a = 0; $a < @catsname; $a++) {
			($name[$a], $download[$a], $dsc[$a]) = split(/\|/, $catsname[$a]);
			if ($info{'cat'} eq $download[$a]) { 
				$dnlcatsname = $name[$a];
			}
		}
	
		open(CATS, "$downloadsdir/$info{'cat'}.dat") || error("$err{'001'} $downloadsdir/$info{'cat'}.dat");
		@dnlcats = <CATS>;
		close(CATS);

		for ($a = 0; $a < @dnlcats; $a++) {
			($id[$a], $name[$a], $url[$a], $desc[$a], $date[$a], $downloadposter[$a], $hits[$a]) = split(/\|/, $dnlcats[$a]);
		}

		if ($info{'start'} eq "") { $start = 0; }
		else { $start = "$info{'start'}"; }
		$numshown = 0;

		$navbar = "$admin{'btn2'} $nav{'056'} $admin{'btn2'} $dnlcatsname";
		print_top();
		print qq~<table border="0" cellpadding="5" cellspacing="0" width="100%">~;
		for ($b = $start; $b < @dnlcats; $b++) {
			++$numshown;
			print qq~<tr>
<td><img src="$imagesurl/stats/downloads.gif" border="0" alt="">&nbsp;&nbsp;<b><a href="$pageurl/$cgi?action=redirectd&amp;cat=$info{'cat'}&amp;id=$id[$b]" target="_blank">$name[$b]</a></b><br>
Download Id : $id[$b]<br>
$msg{'088'} $desc[$b]<br>
$msg{'089'} $date[$b] $download{'downloaded'} $hits[$b] $download{'times'}<br>
<small><a href=\"$pageurl/$cgi\?action=sendbdr\&cats=$info{'cat'}\&id=$id[$b]\&namebd=$name[$b]\&descbd=$desc[$b]\"> $nav{'060'}</a></small></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
~;
			if ($numshown >= $maxdownloads) { $b = @dnlcats; }
		}
		print qq~<tr>
<td>
~;
		if ($numshown >= $maxdownloads) {
			print qq~<hr noshade="noshade" size="1">
$msg{'039'} 
~;
			$numdownloads = @dlncats;
			$c = 0;
			while (($c*$maxdownloads) < $numdownloads) {
				$viewc = $c+1;
				$strt = ($c*$maxdownloads);
				if ($start == $strt) { print "$viewc "; }
				elsif ($strt == 0) { print qq~<a href="$pageurl/$cgi?action=downloads&amp;cat=$info{'cat'}">$viewc</a> ~; }
				else { print qq~<a href="$pageurl/$cgi?action=downloads&amp;cat=$info{'cat'}&amp;start=$strt">$viewc</a> ~; }
				++$c;
			}
		}
		print qq~</td>
</tr>
</table>
<br>
<table align="center" border="0" cellpadding="3" cellspacing="0">
~;
		if($username ne "$anonuser") {
			print qq~<tr>
<td align="center"><a href="$pageurl/$cgi?action=downloads">$nav{'033'}</a> | <a href="$cgi?action=adddownload">$nav{'058'}</a></td>
</tr>
~;
		}
		else {
		print qq~<tr>
<td align="center"><a href="$pageurl/$cgi?action=downloads">$nav{'033'}</a></td>
</tr>
~;
		}
		print "</table>\n";
		print_bottom();
		exit;
	}
}

##################
sub adddownload {
##################
	if ($username eq "$anonuser") { error("$download{'only_registered_add'}"); }

	open(FILE, "$downloadsdir/downloadcats.dat") || error("$download{'cannot_open'} downloadcats.dat!");
	@cats=<FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'056'} $admin{'btn2'} $nav{'058'}";
	print_top();
	print qq~<form method="post" action="$pageurl/$cgi?action=adddownload2">
<table border="0" cellpadding="5" cellspacing="0">
<tr>
<td><b>$msg{'167'}</b></td>
<td><input type="text" name="title" size=40" maxlength="100"></td>
</tr>
<tr>
<td><b>$msg{'168'}</b></td>
<td><input type="text" name="url" size="40" maxlength="100" value="http://"></td>
</tr>
<tr>
<td><b>$msg{'092'}</b></td>
<td><select name="cat">
~;
	foreach $category (@cats) {
		@fields = split (/\|/, $category);
		$cat[$i] =~ s/\n//g;
		$cat[$i] =~ s/\r//g;
		print qq~<option value="$fields[1]">$fields[0]~;
	}
	print qq~</select><td>
</tr>
<tr>
<td valign="top"><b>$msg{'093'}</b></td>
<td><textarea name="desc" cols="40" rows="5" maxlength="255"></textarea><br>$msg{'094'}</td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="$btn{'018'}"></td>
</tr>
</table>
</form>
~;
	print_bottom();
	exit;
}

###################
sub adddownload2 {
###################
require "$sourcedir/security.pl";

	error("$err{'021'}") unless ($input{'title'});
	error("$err{'022'}") unless ($input{'url'});
	error("$err{'023'}") unless ($input{'desc'});
	if (length($input{'desc'}) > 255) { $input{'desc'} = substr($input{'desc'},0,255); }
	if($username eq "$anonuser") { error("$err{'011'}"); }

	check_hash($info{'cat'});
	open (DATA, "<$downloadsdir/$input{'cat'}.dat");
	@datas=<DATA>;
	close(DATA);

	$a = 0;
	while ($datas[$a] ne '') { $a++; }


 ($mio, $dummy, $dummy, $dummy, $dummy) = split(/\|/, $datas[0]);
 chomp($mio);
 $mio = $mio +1;


	$count = $a;
	$i = 0;
	$id = $count +1;

	chomp($input{'desc'});
	chomp($input{'title'});
	chomp($input{'url'});

	$title = htmlescape($input{'title'});
	$desc = htmlescape($input{'desc'});

	open (DATABASE,">$downloadsdir/$input{'cat'}.dat");
	lock(DATABASE);
	print DATABASE "$mio|$title|$input{'url'}|$desc|$date|$username|0|\n";
	while ($i < $count) {
		($id, $name, $url, $text, $postdate, $downloadposter, $hits) = split(/\|/, $datas[$i]);
		chomp($id);
		chomp($hits);
		print DATABASE "$id|$name|$url|$text|$postdate|$downloadposter|$hits|\n";
		$i++;
	}
	unlock(DATABASE);
	close(DATABASE);

	open(CNT, "$downloadsdir/$input{'cat'}.cnt");
	$catscount = <CNT>;
	close(CNT);

	open(DCNT, "$downloadsdir/downloadcats.cnt");
	$downloadcatscount = <DCNT>;
	close(DCNT);

	$catscount++;
	$downloadcatscount++;

	open(CNT, ">$downloadsdir/$input{'cat'}.cnt");
	lock(CNT);
	print CNT "$catscount";
	unlock(CNT);
	close(CNT);

	open(DCNT, ">$downloadsdir/downloadcats.cnt");
	lock(DCNT);
	print DCNT "$downloadcatscount";
	unlock(DCNT);
	close(DCNT);

	writelog ("Add Download");

	success();
}

#############
sub success {
#############
	print_top();
	print qq~<b>$nav{'027'}</b><br>
$inf{'019'}
~;
	print_bottom();
	exit;
}

##############
sub redirect {
##############
require "$sourcedir/security.pl";
	check_hash($info{'cat'});
	$filetoopen = "$info{'cat'}.dat";
	open (DATA, "<$downloadsdir/$filetoopen") or error("$err{'001'} $filetoopen.dat");;
	@datas=<DATA>;
	close(DATA);

	$a = 0;
	while ($datas[$a] ne '') { $a++; }
	$count = $a;
	$i = 0;
	$num = $count +1;

	open(DATA,">$downloadsdir/$filetoopen") or error("$err{'016'} $filetoopen");
	lock(DATA);
	while ($i < $count) {
		($id_temp, $name, $url, $desc, $addate, $downloadposter, $hits_temp) = split(/\|/, $datas[$i]);

		if ($id_temp eq $info{'id'}) {
			$theurl = $url;
			$hits = $hits_temp +1;
			print DATA "$id_temp|$name|$url|$desc|$addate|$downloadposter|$hits|\n";
		}
		else { print DATA "$id_temp|$name|$url|$desc|$addate|$downloadposter|$hits_temp|\n"; }
		$i++;
	}
	unlock(DATA);
	close(DATA);

	print "Location: $theurl\n\n";	
}

#########################
sub save_brokend_report {
#########################

	$navbar = "$admin{'btn2'} $download{'download'} $admin{'btn2'} $download{'broken_download'} $admin{'btn2'} $download{'save_report'}";
	print_top();

	if ($username eq $anonuser) { error("$download{'only_member_post'}");}

	open (BROKEND, "$downloadsdir/broken/broken.dat") || error("$err{'001'} broken.dat");
	@datas=<BROKEND>;
	close(BROKEND);

	$a = 0;
	while ($datas[$a] ne '') { $a++; }

	$count = $a;
	$i = 0;
	$id = $count +1;

	open (BROKEND, ">>$downloadsdir/broken/broken\.dat");
	lock (BROKEND);
	print BROKEND "$id|$input{'catbd'}|$input{'idbd'}|$input{'namebd'}|$input{'typebd'}|$input{'posterbd'}|$input{'descbd'}|$date|\n";
	unlock (BROKEND);
	close (BROKEND);

	open (BROKENDCNT, ">$downloadsdir/broken/broken.cnt");
	$brokendcount=<BROKENDCNT>;
	close (BROKENDCNT);

	$brokendcount++;

	open (BROKENDCNT,">$downloadsdir/broken/broken.cnt");
	print BROKENDCNT $brokendcount;
	close (BROKENDCNT);

	print "$download{'broken_report_save'} <br>$download{'thankyou_support'}";
	print_bottom();
	exit();

}

#########################
sub send_brokend_report {
#########################

	$navbar = "$admin{'btn2'} $download{'download'} $admin{'btn2'} $download{'broken_download'} $admin{'btn2'} $download{'send_report'}";
	print_top();
	print "<center><big><b>$download{'broken_download_report'}</b></big></center><p><br>";
	print "<b>$download{'download_category'} : </b><br>$info{'cats'} <br><b>Download Id :</b> <br>$info{'id'}<br><b>$download{'download_name'} :</b> <br>$info{'namebd'}<br>";
	print "<b>$download{'report_poster'} : </b><br>$username<br>";
	print "<b>$download{'download_description'} :</b><br>$info{'descbd'}<br>";
	
	if ($username eq $anonuser) { error("$download{'only_member_post'}"); }
	else {
		print qq~<form action=\"$pageurl/$cgi\?action=savebdr\" method=\"POST\">
			<input type=\"hidden\" name=\"catbd\" value=\"$info{'cats'}\">
			<input type=\"hidden\" name=\"idbd\" value=\"$info{'id'}\">
			<input type=\"hidden\" name=\"posterbd\" value=\"$username\">
			<input type=\"hidden\" name=\"descbd\" value=\"$info{'descbd'}\">
			<b>$download{'broken_type'} :</b><br> <select name=\"typebd\">
			<option value=\"Can't Found File\" SELECTED>$download{'cannot_found_file'}</option>
			<option value=\"Site Doesn't Exist\">$download{'site_not_exist'}</option>
			<option value=\"Site Has Moved\">$download{'site_moved'}</option></select>
			<br><input type=\"Submit\" value=\"$download{'send_report'}\"></form>~;
	}
	print_bottom();
}

1; # return true
