###############################################################################
###############################################################################
# Poas - Perl on all site                                                     #
#-----------------------------------------------------------------------------#
# config.pl - the main config file                                            #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)	                      #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: config.pl, Last modified: 05/20/02 - 23:18:18                         #
###############################################################################
###############################################################################


##################
# General Settings
##################
$pagename = "Poas";
$pageurl = "http://poas.netfirms.com/cgi-bin";
$pagetitle = "PoaS - Perl on all Site";

$cgi = "index.cgi";
$cookieusername = "poasuid";
$cookiepassword = "poaspwd";
$cookieusertheme = "poasthm";
$cookieuserclang = "poasclang";

$mailtype = 0;
$mailprogram = "/usr/sbin/sendmail -t";
$smtp_server = "smtp.sourceforge.net";   
$master_email = 'you@yourdomain.com';

$basedir   = "/home/poas";
$baseurl   = "http://poas.netfirms.com";
$scriptdir = "$basedir/cgi-bin";
$scripturl = "$baseurl/cgi-bin";
$sourcedir = "$scriptdir/cgi-lib";
$datadir   = "$scriptdir/db";
$memberdir = "$datadir/members";
$imagesdir = "$basedir/html/images";
$themesdir = "$basedir/html/themes";

$imagesurl = "$baseurl/images";
$themesurl = "$baseurl/themes";

$langsdir  = "$scriptdir/lang";
$langname  = "english.lng";
$lang = "$langsdir/$langname";

$showban = 0;

########################
# News Specific Settings
########################
$topicsdir = "$datadir/topics";
$maxnews = 5;
$maxtopics = 25;
$enable_userarticles = 1;
$allow_html = 1;

##########################
# Forums Specific Settings
##########################
$boardsdir = "$datadir/forum";
$messagedir = "$datadir/forum/messages";

$enable_guestposting = 1;
$enable_notification = 1;
$maxdisplay = 25;
$maxmessagedisplay = 15;
$insert_original = 0;
$enable_ubbc = 1;
$max_log_days_old = 21;

#########################
# Stats Specific Settings
#########################
$logdir = "$datadir/stats";

$ip_time = 5;

$top_browsers = 1;
$top_os = 1;

#########################
# Links Specific Settings
#########################
$linksdir = "$datadir/links";
$maxlinks = "25";

#########################
# Download Specific Settings
#########################
$downloadsdir = "$datadir/downloads";
$maxdownloads = "25";

################################
# File Manager Specific Settings
################################
$awebspace = "20000";
$maxufile  = "900";
$giveuserspace = "1";
$userspacedir = "$basedir/html";
$userwebspace = "5000";
$usermaxufile = "900";
$userurl   = "$baseurl";


################
# Other Settings
################
$timeoffset = 6;

$memberpic_height = 93;
$memberpic_width = 60;

$use_flock = 1;
$LOCK_EX = 2;
$LOCK_UN = 8;

$IIS = 0;

##############################
##############################
require "$sourcedir/subs.pl";
check_extra_config();

1; #return true
