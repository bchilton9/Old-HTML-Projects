
##################
sub blockright {
##################
#	open(FILE, "$imagesdir/addons/PGallery/PGallery.cat");
#	@selectedlist = <FILE>;
#	close(FILE);

	opendir(DIR, "$imagesdir/addons/PGallery");
	chomp(@catpiclist = readdir(DIR));
	closedir(DIR);

	foreach $ocatpiclist (@catpiclist) {
		next if($ocatpiclist eq ".");
		next if($ocatpiclist eq "..");
		next if($ocatpiclist eq ".htaccess");
		if(!opendir(DIR, "$imagesdir/addons/PGallery/$ocatpiclist")) { next; }
		else { closedir(DIR); }

		$selectlistnow .= qq~$ocatpiclist|~;
	}

	@selectlist = split(/\|/, $selectlistnow);
	$selectlist = @selectlist;
	$randlist = int(rand $selectlist);
	$displayrandcat = $selectlist[$randlist];

	opendir(DIRP2, "$imagesdir/addons/PGallery/$displayrandcat/thumbs");
	chomp(@listdirp2 = readdir(DIRP2));
	closedir(DIRP2);

	
DIRP2:	foreach $contdirp2 (@listdirp2) {
		($picname, $picext) = split(/\./, $contdirp2);
		next if ($contdirp2 eq "..");
		next if ($contdirp2 eq ".");
		if (opendir(DIR, "$imagesdir/addons/PGallery/$displayrandcat/thumbs/$contdirp2")) { next; }
		else { closedir(DIR); }

		$listpicsnow .= qq~$contdirp2|~;
	}

	@listpics = split(/\|/, $listpicsnow);
	$listpics = @listpics;
	$randpics = int(rand $listpics);
	$selectedpic = $listpics[$randpics];
	$randselected_space = $selectedpic;
	$randselected_space =~ s/ /%20/g;

	print qq~<center>Pic of the moment<p><a href="$pageurl/addons/PGallery/index.cgi?command=show&cat=$displayrandcat&file=$randselected_space">
		<img src="$imagesurl/addons/PGallery/$displayrandcat/thumbs/$selectedpic" width=130 height=110></a></center>
	~;

}
1;
