sub blockright {

$quotesfile = "$scriptdir/addons/Quotes/db/quotes.db";

open (QUOTES,$quotesfile);
seek(QUOTES,0,0);
@QUOTES = <QUOTES>;
close(QUOTES);
$lines = @QUOTES;
$line = rand $lines;
print $QUOTES[$line];

}
1;
