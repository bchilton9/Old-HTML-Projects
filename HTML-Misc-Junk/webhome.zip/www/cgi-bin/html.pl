# WebHome 3.0
# HTML
# Made by CyberScript
# website: http://www.cyberscript.net
# email: webmaster@cyberscript.net
#####################################
# MANAGER LOGIN HTML
sub manager_login_html {
	my $output;
	$output = qq~
<html>

<head>
<title>$config{'site_name'} Manager</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><big><strong><font face="Arial">$config{'site_name'} Manager</font></strong></big></big></big></p>

<p>$header</p>
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">Manager Login</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><form method="POST">
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">username</font></td>
              <td><input type="text" name="loginName" size="20"></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">password</font></td>
              <td><input type="password" name="loginPass" size="20"></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">validation #</font></td>
              <td><input type="text" name="valNumber" size="20"></td>
            </tr>
          </table>
          <p><input type="submit" value="Login"> <input type="reset" value="Reset"></p>
        </form>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>

<p>$footer</p>

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>
~;
	return $output;
}

#####################################
# MANAGER ERROR HTML
sub manager_error_html {
	($error)=@_;
	my $output;
	$output = qq~
<html>

<head>
<title>$config{'site_name'} Manager</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><big><strong><font face="Arial">$config{'site_name'} Manager</font></strong></big></big></big></p>

<p>$header</p>
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">Error</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC">
          <font face="Arial">$error</font>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>

<p>$footer</p>

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>
~;
	return $output;
}

#####################################
# SIGNUP HTML
sub signup_html {
	my $output;
	$output = qq~
<html>

<head>
<title>WebHome Signup</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><strong><font face="Arial">$config{'site_name'} Signup</font></strong></big></big></p>

$header

<form method="POST">
  <div align="center"><center><table border="0" cellpadding="1" width="600"
  bgcolor="#FFCC66">
    <tr>
      <td><table border="0" cellspacing="0" bgcolor="#FFCC66" width="100%">
        <tr>
          <td><strong><font face="Arial">User Information</font></strong></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" nowrap><font face="Arial">To receive a account you must agree to the
          terms and conditions.</font><p><font face="Arial">$terms</font></p>
          <p><font face="Arial">Fill out all of the required information.</font></p>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Username</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="username" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'username'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Password</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="password" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'password'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Email</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="email" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'email'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Real name</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="real_name" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'real_name'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Site description</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="site_description" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'site_description'}"></font></small></td>
            </tr>
          </table>

$signup_communities_html

          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td>&nbsp;&nbsp;&nbsp; </td>
            </tr>
          </table>

$signup_questions_html

          <p><input type="submit" value="Submit" name="signup"> <input type="reset" value="Reset"></td>
        </tr>
      </table>
      </td>
    </tr>
  </table>
  </center></div>
</form>

$footer

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>
~;
	return $output;
}

#####################################
# SIGNUP SUCCESS HTML
sub signup_success_html {
	my $output;
	$output = qq~
<html>

<head>
<title>WebHome 3.0 Signup</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><big><strong><font face="Arial">$config{'site_name'} Signup</font></strong></big></big></big></p>

<p>$header</p>
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">Signup Success</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><font face="Arial">Your account has been added and a email has been
        sent to you with your info.<br>
        &nbsp;&nbsp;&nbsp; </font><table border="0" cellpadding="1" cellspacing="0" width="100%">
          <tr>
            <td width="50%" valign="top"><font face="Arial"><strong>User Information</strong><br>
            Username: $in{'username'}<br>
            Password: $in{'password'}<br>
            Email: $in{'email'}<br>
            Real name: $in{'real_name'}<br>
            Site description: $in{'site_description'}<br>
            Community: $in{'community'}<br>

$signup_success_questions

</font></td>
            <td width="50%" valign="top"><form method="POST" action="$config{'script_url'}/manager.cgi">
              <table border="0" cellpadding="1" cellspacing="0">
                <tr>
                  <td><strong><font face="Arial">Login</font></strong></td>
                </tr>
              </table>
              <table border="0" cellpadding="1" cellspacing="0">
                <tr>
                  <td width="120"><font face="Arial">username</font></td>
                  <td><input type="text" name="loginName" size="20" value="$in{'username'}"></td>
                </tr>
              </table>
              <table border="0" cellpadding="1" cellspacing="0">
                <tr>
                  <td width="120"><font face="Arial">password</font></td>
                  <td><input type="password" name="loginPass" size="20"></td>
                </tr>
              </table>

$signup_success_validation_field

              <p><input type="submit" value="Login"></p>
            </form>
            </td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>

<p>$footer</p>

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>
~;
	return $output;
}

#####################################
# SIGNUP ERROR HTML
sub signup_error_html {
	my $output;
	$output = qq~
<html>

<head>
<title>WebHome Signup Error</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><strong><font face="Arial">$config{'site_name'} Signup Error</font></strong></big></big></p>

$header

<form method="POST">
  <div align="center"><center><table border="0" cellpadding="1" width="600"
  bgcolor="#FFCC66">
    <tr>
      <td><table border="0" cellspacing="0" bgcolor="#FFCC66" width="100%">
        <tr>
          <td><strong><font face="Arial">Signup Error</font></strong></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" nowrap><font face="Arial">The following error has occured.</font><p><font face="Arial">$error</font></p>
          <p><font face="Arial">Fix your mistake on the form below.</font></p>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Username</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="username" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'username'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Password</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="password" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'password'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Email</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="email" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'email'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Real name</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="real_name" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'real_name'}"></font></small></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><div align="right"><p><font face="Arial">Site description</font></td>
              <td><small><font face="Arial">&nbsp;<input type="text" name="site_description" size="20"
              style="background-color: rgb(255,255,255)" value="$in{'site_description'}"></font></small></td>
            </tr>
          </table>

$signup_error_communities_html

          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td>&nbsp;&nbsp;&nbsp; </td>
            </tr>
          </table>

$signup_error_questions_html

          <p><input type="submit" value="Submit" name="signup"> <input type="reset" value="Reset"></td>
        </tr>
      </table>
      </td>
    </tr>
  </table>
  </center></div>
</form>

$footer

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>
~;
	return $output;
}

#####################################
# USER LIST HTML
sub user_list_html {
	my $output;
	$output = qq~
<html>

<head>
<title>WebHome 3.0 List</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><big><font face="Arial"><strong>$config{'site_name'} List</strong></font></big></big></big></p>

<form action="$config{'script_url'}/search.cgi">
  <div align="center"><center><input type="text" name="k" size="20"> <input type="submit" value="Search"><br>
  <font face="Arial">Show <select name="r"><option>10</option><option selected>25</option><option>50</option></select> results per page</font>
  </center></div>
</form>

$list_header

<ul>

$user_list

</ul>

$list_footer

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>
~;
	return $output;
}

#####################################
# GUESTBOOK HTML
sub guestbook_html {
	my $output;
	$output = qq~
<html>

<head>
<title>Guestbook</title>
</head>

<body bgcolor="#FFFFFF">
<font face="Arial"><center><strong><big>$user\'s Guestbook</big></strong></center></font><p>

$header
<form method="POST" align="center">
<input type="hidden" name="u" value="$user">
  <div align="center"><center><table border="0" cellpadding="1" width="600"
  bgcolor="#FFCC66">
    <tr>
      <td><table border="0" cellspacing="0" width="100%">
        <tr>
          <td><strong><font face="Arial">Sign</font></strong></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC"><table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">Name</font></td>
              <td><input type="text" name="name" size="20"></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">Email</font></td>
              <td><input type="text" name="email" size="20"></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">Comment</font></td>
              <td><input type="text" name="comment" size="20"></td>
            </tr>
          </table>
          <p><input type="submit" value="Submit" name="sign"><input type="reset" value="Reset"></td>
        </tr>
      </table>
      </td>
    </tr>
  </table>
  </center></div>
</form>
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">View</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC">

$guestbook_signs

</td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>
$footer
</body>
</html>
~;
	return $output;
}

#####################################
# GUESTBOOK ERROR HTML
sub guestbook_error_html {
	my $output;
	$output = qq~
<html>

<head>
<title>Error</title>
</head>

<body bgcolor="#FFFFFF">
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">Error</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><p align="center"><font face="Arial">$error</font></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>
</body>
</html>
~;
	return $output;
}

#####################################
# FORUM MAIN HTML
sub forum_main_html {
	my $output;
	$output = qq~
<html>

<head>
<title>Forum</title>
</head>

<body bgcolor="#FFFFFF">

$header
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><table border="0" cellpadding="1" cellspacing="0">
          <tr>
            <td width="250"><strong><font face="Arial">Forums</font></strong></td>
            <td width="120"><p align="center"><strong><font face="Arial">Posts</font></strong></td>
            <td><p align="center"><strong><font face="Arial">Last Post</font></strong></td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><table border="0" cellpadding="1" cellspacing="0">

$forum_list

        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>
$footer
</body>
</html>
~;
	return $output;
}

#####################################
# FORUM LIST HTML
sub forum_list_html {
	my $output;
	$output = qq~
<html>

<head>
<title>Forum</title>
</head>

<body bgcolor="#FFFFFF">
$header
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><table border="0" cellpadding="1" cellspacing="0">
          <tr>
            <td width="180"><strong><font face="Arial">Topic</font></strong></td>
            <td width="120"><strong><font face="Arial">Creator</font></strong></td>
            <td width="100"><p align="center"><strong><font face="Arial">Replies</font></strong></td>
            <td><p align="center"><strong><font face="Arial">Last Post</font></strong></td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><table border="0" cellpadding="1" cellspacing="0">

$topic_list

        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>
<form method="POST">
  <input type="hidden" name="u" value="$user"><div align="center"><center><table border="0"
  cellpadding="1" cellspacing="0" width="600">
    <tr>
      <td><div align="center"><center><p><strong><font face="Arial"><a href="forum.cgi?u=$user">Main</a> - <a href="forum.cgi?u=$user&f=$forum_link&c=post">Post Topic</a></font></strong></td>
      <td align="center"><select name="f" size="1">

$forum_list

      </select> <input type="submit" value="List" name="c"></td>
    </tr>
  </table>
  </center></div>
</form>
$footer
</body>
</html>
~;
	return $output;
}

#####################################
# FORUM READ HTML
sub forum_read_html {
	my $output;
	$output = qq~
<html>

<head>
<title>Forum</title>
</head>

<body bgcolor="#FFFFFF">
$header
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">$topic_name</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><font face="Arial"><a href="mailto:$topic_email">$topic_author</a><br>
        $topic_date</font><p><font face="Arial">$topic_message</font></td>
      </tr>
    </table>
    </td>
  </tr>
</table>

$topics

</center></div>

<form method="POST">
  <input type="hidden" name="u" value="$user"><div align="center"><center><table border="0"
  cellpadding="1" cellspacing="0" width="600">
    <tr>
      <td><div align="center"><center><p><strong><font face="Arial"><a href="forum.cgi?u=$user">Main</a> - <a href="forum.cgi?u=$user&f=$forum&c=post&p_number=$topic">Post Reply</a></font></strong></td>
      <td align="center"><select name="f" size="1">

$forum_list

      </select> <input type="submit" value="List" name="c"></td>
    </tr>
  </table>
  </center></div>
</form>
$footer
</body>
</html>
~;
	return $output;
}

#####################################
# FORUM ERROR HTML
sub forum_post_html {
	my $output;
	$output = qq~
<html>

<head>
<title>Forum</title>
</head>

<body bgcolor="#FFFFFF">
$header
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">Post</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><form method="POST">
          <input type="hidden" name="c" value="post"><input type="hidden" name="f" value="$forum"><input type="hidden" name="u" value="$user">
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">Your name</font></td>
              <td><input type="text" name="p_name" size="20" value="$in{'p_name'}"></td>
            </tr>
          </table>
          <table border="0" cellpadding="1" cellspacing="0">
            <tr>
              <td width="120"><font face="Arial">Your email</font></td>
              <td><input type="text" name="p_email" size="20" value="$in{'p_email'}"></td>
            </tr>
          </table>

$post_topic

          <div align="center"><center><p><textarea rows="8" name="p_message" cols="72">$in{'p_message'}</textarea></p>
          </center></div><p><input type="submit" value="Post"><input type="reset" value="Reset"></p>
        </form>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>
$footer
</body>
</html>
~;
	return $output;
}

#####################################
# FORUM ERROR HTML
sub forum_error_html {
	my $output;
	$output = qq~
<html>

<head>
<title>Error</title>
</head>

<body bgcolor="#FFFFFF">
<div align="center"><center>

<table border="0" cellpadding="1" width="600" bgcolor="#FFCC66">
  <tr>
    <td><table border="0" cellspacing="0" width="100%">
      <tr>
        <td><strong><font face="Arial">Error</font></strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFCC"><p align="center"><font face="Arial">$error</font></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>
</body>
</html>
~;
	return $output;
}

#####################################
# USER SEARCH FORM
sub user_search_form {
	my $output;
	$output = qq~
<html>

<head>
<title>$config{'site_name'} User Search</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><big><strong><font face="Arial">$config{'site_name'} User Search</font></strong></big></big></big></p>

$header

<form>
  <div align="center"><center><input type="text" name="k" size="20"> <input type="submit" value="Search"><br>
  <font face="Arial">Show <select name="r"><option>10</option><option selected>25</option><option>50</option></select> results per page</font>
  </center></div>
</form>

$footer

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>
~;
	return $output;
}

#####################################
# USER SEARCH HTML
sub user_search_html {
	my $output;
	$output = qq~
<html>

<head>
<title>$config{'site_name'} User Search</title>
</head>

<body bgcolor="#FFFFFF">

<p align="center"><big><big><big><strong><font face="Arial">$config{'site_name'} User Search</font></strong></big></big></big></p>

$header<p>

<form>
  <div align="center"><center><p><input type="text" name="k" size="20"> <input type="submit"
  value="Search"></p>
  </center></div>
  <input type="hidden" name="r" value="$results">
</form>

$user_search_results

<p>$footer

<hr width="80%" noshade size="1" color="#000000">

<p align="center"><font face="Arial">� Copyright 1999 WebHome 3.0<br>
<a href="mailto:webmaster\@cyberscript.net">webmaster\@cyberscript.net</a></font></p>
</body>
</html>

~;
	return $output;
}

1;