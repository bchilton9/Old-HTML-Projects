WebHome 3.0 README

Installing WebHome is easy.
1) make a data directory and put questions.txt and tips.txt in it.
2) chmod 777 the data directory, questions.txt, tips.txt
3) put everything in the cgi-bin directory on to the cgi-bin directory of your server.
4) chmod all the .cgi and .pl files to 755
5) chmod 777 the config.txt
6) chmod 777 the root directory of your website
7) run admin.cgi and continue with installation.

If you have any problems just email webmaster@cyberscript.net

Ryan Campbell
CyberScript
http://www.cyberscript.net