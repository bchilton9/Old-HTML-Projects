Virtual Subdomains V3.2
Copyright (C) 1999 By Jeff Ledger
All Rights Reserved



Version History
===============
1.0		Free version given out on the website, consists of one
		'virtual.cgi' file that must be modified to add and
		remove subdomains.

2.0		Expanded version updated to use a 'virtual.dat' file
		which contained subdomains.  (Never released)

3.0		Re-written from scratch.  Designed to allow anyone
		to not only have subdomains, but also run a domain
		redirection service.  All controlled online.

3.1		Added popup banner feature option

3.2		Fixed bug with Internet Explorer.
		Fixed UPPERCASE/lower case bug.
		Added "Reserved Names" Checklist.
		Added Password finder (see pass.zip)
		Added Recent Users List
		Other small critters not worth mention.


IF YOU ARE UPGRADING:
=====================
Save a copy of your "virtual.data" file before installing a new
copy of the script.  Your old records will be compatible!


Important Information
=====================
Please read ALL of the instructions completely before attempting to
install and use the Virtual Subdomains System V3.2!  After you have
read ALL of the instructions, then proceed to install and setup
software step-by-step.

If you this software from the Ledgerlabs.cc site, I thank you for your
contribution of $5.00.   If you have gotten a copy from somewhere else,
please consider registration at http://vs3.ledgerlabs.cc.  Registration
helps to offset the cost of the website, and provides postive modivation
to write free updates.  Either way, drop me a line and let me know you
have found the program useful.  (jledger@cyberstreet.com)

NOTE: You must have "SERVER SIDE INCLUDES" and "DNS WILDCARDS" enabled
before you will be successful with Virtual Subdomains.

If you can type http://anything.yourdomain.com into your web browser and
still get to your homepage, then DNS WILDCARDS are working.  If not, ask
your provider to enable them.  If you need a provided that understands
what DNS wildcards are, contact CRUSH.TO for a website account.
They have provided us excellent service! 
Be sure and let the guys know that Ledgerlabs sent you.


Unpacking Virtual Subdomains
----------------------------

First start by making four subdirectories in your website.
I would suggest the following...

Subdirectory One:	virtual
Subdirectory Two:	records
Subdirectory Three:	mainsite
Subdirectory Four:	banners

Using the chmod command set 'virtual' to 755 and set 'records' to 777.
Upload all of the files from this zip to the 'virtual' directory.

Using chmod set the files in 'virtual' as follows:

CHMOD 755 change.cgi
CHMOD 755 register.cgi
CHMOD 755 virtual.cgi
CHMOD 755 whois.cgi
CHMOD 777 recent.htm

Don't worry about 'records' this directory will take care of itself. ;)

Just to make perfectly sure that we are on the same page, you website
directory tree should look as follows...

  root
    |
    +----records  (Which has been chmod'd to 777)
    |
    +----mainsite (The new home of your orginal homepage!)
    |
    +----banners (Location of your banner code from banners.zip)
    |
    +----virtual  (Which has been chmod'd to 755)
    |	    |
    |       VIRTUAL CONTAINS THE FOLLOWING FILES:
    |
    |		change.cgi
    |		register.cgi
    |		virtual.cgi
    |		whois.cgi
    |		change.htm
    |		virtual.data
    |		whois.htm
    |		example.shtml
    |		virtual.reserved	
    |		recent.htm
    
The records directory will contain all the of actual record files for each
of your virtual subdomains.

Unzip the 'banners.zip' into the banners directory.


Edit 'virtual.data'
-------------------

You will need to edit 'virtual.data' first.   The file will look something like this.

ledgerlabs.cc
http://www.ledgerlabs.cc/errorpage/index.htm
nobanner
hide
<!-- Additional code can be placed here -->
Ledgerlabs
<BODY BGCOLOR="#000000" LINK="YELLOW" ALINK="YELLOW" VLINK="YELLOW">
<FONT COLOR="WHITE">
3
http://www.ledgerlabs.cc/banners/


Make the following changes...

Change line 1 - 'ledgerlabs.cc' to your domain name.  ie: 'yourdomain.com'
	ENTER IT AS IT IS LISTED WITH NETWORK SOLUTIONS!
	DO NOT PUT IN THE WWW!

Change line 2 - 'http://www.ledgerlabs.cc/errorpage/index.htm'
	This needs to be the complete location of your 404 error file to
	display if a domain is not found.  This could point at your homepage as well.

Change line 3 - 'no' 
	This is a 'yes/no' toggle for banners.  All new subdomains will
	be site with this setting unless each record is changed by you
	with a different setting.  Think of this as the default setting
	for all newly created subdomain records.
	If you want pop-up banners answer 'yes'
	
Change line 4 - 'hide'
	This is set to activate website cloaking.  In other words, when someone
	uses the system.  Their real address is not displayed.
	This can be turned off by changing it to: 'nohide' - Most don't.

       line 5 - '<!-- Additional code can be placed here -->'
	If you do not know what to do with this, leave it alone.
	All I will say, is that this is sometimes handy for linking to certain
	free sites.  If in doubt, leave it be.

Change line 6 - 'Ledgerlabs'
	Change this to the name of your website... ie: 'Joe's Place'

Change line 7 - '<BODY BGCOLOR="#000000" LINK="YELLOW" ALINK="YELLOW" VLINK="YELLOW">'
	This will allow you to change the background colors of WHOIS, and REGISTER
	pages so that they will match your site.  If you are a little confused,
	leave it be, you'll figure it out soon enough.

Change line 8 - '<FONT COLOR="WHITE">'
	This will allow you to change the font color of WHOIS and REGISTER pages
	so that they will match your site.  If you are still a little confused,
	do the same thing you did at line 7, leave it alone for now.

Change line 9 - '3'
	Change this to the number of banners you have in your banners
	directory.  (0 is also a banner number)  More on banners later.

Change line10 - 'http://www.ledgerlabs.cc/banners/'
	Change this to the actual location of your banners htm files
	and graphics.  If you have been using my examples to configure
	yourself, then it will be http://www.yoursite.com/banners/
	YOU MUST HAVE THE TRAILING /


Edit 'virtual.cgi'
------------------

Edit 'virtual.cgi' and look for the following lines.

	#################################################################
	# CHANGE THIS TO THE LOCATION OF YOUR SCRIPT & RECORDS		#
	#################################################################

	$directory = " ";
	$records = " ";

	# IMPORTANT!	READ THE DOCUMENTATION COMPLETELY FIRST!	#
	#################################################################
	# 	NO CHANGES NEED TO BE MADE BEYOND THIS POINT!		#
	#################################################################

Change the information in $directory to match the true location of 'virtual'
It *might* look something like this:

	$directory = "/usr/home/website/html/virtual";

Also change the information in $records to match the true location of 'records'
It *might* look something like this:

	$records = "/usr/home/website/html/records";


Write these changes down, you will need them again!




Edit 'whois.cgi'  - (Hint: Same changes as above)
----------------

Edit 'whois.cgi' and look for the following lines.

	#################################################################
	# CHANGE THIS TO THE LOCATION OF YOUR SCRIPT & RECORDS		#
	#################################################################

	$directory = " ";
	$records = " ";

	# IMPORTANT!	READ THE DOCUMENTATION COMPLETELY FIRST!	#
	#################################################################
	# 	NO CHANGES NEED TO BE MADE BEYOND THIS POINT!		#
	#################################################################

Change the information in $directory to match the true location of 'virtual'
It *might* look something like this:

	$directory = "/usr/home/website/html/virtual";

Also change the information in $records to match the true location of 'records'
It *might* look something like this:

	$records = "/usr/home/website/html/records";




Edit 'register.cgi'  (Almost the same as before...)
-------------------

Edit 'register.cgi' and look for the following lines.

	#################################################################
	# CHANGE THIS TO THE LOCATION OF YOUR  RECORDS			#
	#################################################################

	$records = " ";

	# IMPORTANT!	READ THE DOCUMENTATION COMPLETELY FIRST!	#
	#################################################################
	# 	NO CHANGES NEED TO BE MADE BEYOND THIS POINT!		#
	#################################################################

Change the information in $records to match the true location of 'records'
It *might* look something like this:

	$records = "/usr/home/website/html/records";



Edit 'change.cgi'	(Pay special attention here!)
-----------------

Edit 'change.cgi' and look for the following lines.

	#################################################################
	# CHANGE THIS TO THE LOCATION OF YOUR SCRIPT & RECORDS		#
	#################################################################

	$directory = " ";
	$records = " ";
	$masterpassword = "hal9000";

	# IMPORTANT!	READ THE DOCUMENTATION COMPLETELY FIRST!	#
	#################################################################
	# 	NO CHANGES NEED TO BE MADE BEYOND THIS POINT!		#
	#################################################################


Change the information in $directory to match the true location of 'virtual'
It *might* look something like this:

	$directory = "/usr/home/website/html/virtual";

Also change the information in $records to match the true location of 'records'
It *might* look something like this:

	$records = "/usr/home/website/html/records";

		****************************************************
		----------> ARE YOU PAYING ATTENTION?  <------------
		****************************************************

	$masterpassword = "hal9000";
	
Change 'hal9000' to something original!  Do not leave it like it is!
I allows you or anyone else to change any subdomain record in your system!


Edit 'change.htm' & 'whois.htm'
-------------------------------

These files are used for subdomain lookups and modification.
The changes you need to make are for things like color and putting in your
website name instead of Ledgerlabs.

Note: DO NOT CHANGE THE <FORMS> INFORMATION!
	This would cause your Virtual Subdomains System to fail.



Time to move your orginal homepage
----------------------------------

Move all of your original homepage index files and graphics, etc. to the directory,
'mainsite'  Get everything working so that you can type: 
'http://www.yourdomain.com/mainsite/' and see your orignal homepage.

Copy the file: 'example.shtml' to your 'root' directory where the old pages
used to be, and rename the file to 'index.shtml'

This is a one-line file that is the key to the whole thing.
Edit the line: <!--#exec cgi="./virtual/virtual.cgi" --> to the correct location
of 'virtual.cgi'  (If you are using my exact examples, you should be fine.)


Banner Configuration
--------------------
If you have answered 'no' to the banner option in 'virtual.data' you can
skip this section.  Otherwise...
You should have already placed the contents of banners.zip into the
banners directory in your webserver.  Banners are called by number
randomly as subdomains with the banner feature turned 'on' are displayed.
Banner html code must be named as I have started it. (#.HTM) - However
the actual code is can be altered without to much trouble.
It is easiest to copy my 1.HTM file format and simply change the
URL and BANNER#.JPG.


Configuring "virtual.reserved"
------------------------------
You can prevent users from registering certain subdomains by
simply adding them to "virtual.reserved".  Add the blocked
subdomains by putting only the subdomain name on each line.



Configuring "recent.htm"
------------------------
By now you should have already CHMOD 777 recent.htm so that the
system can update it on the fly.  Recent.htm will always contain
a list of the last 30 subdomains that have been either created
or modified.  You may ONLY edit the first four lines.  Any line
after four will be removed and placed with information as your
system runs.   Recent.htm is a nice way to keep an eye on what 
is going on.



Additional Note: Security - Strongly Suggested!
-------------------------
If your server allows users to browse directories, you may
want to put an blank index.htm file in your /records, /virtual,
and /banners directories to prevent people who have read this
documentation from viewing your scripts and records.



Time to configure the system!
-----------------------------

Ok, time to configure the system... 
Type the true location of your 'whois.htm' file into your webrowser.

ie: http://www.yourdomain.com/virtual/whois.htm

	Enter 'whois' into the subdomain box.


You will be taken to a setup screen to configure 'whois.yourdomain.com'.
Put in the following information:

	Actual Web Location: http://www.yourdomain.com/virtual/whois.htm
	     Your Full Name: Webmaster

Pick a password for this record. Fill in the site title, description and so on.
If you use the name 'Webmaster' instead of your own name, Virtual Domain will
hide the Actual Web Location from the view of someone who pulls up that record.

Don't sweat the password.. Remember $masterpassword?  That password will allow
you to edit any Virtual Domain Record in the system.

If you edit any record with your master password, you will also be given
the option of changing the 'Extra HTML CODE' and Banners 'on/off' toggle
for that record.  NOTE: These options are only on the modify screen
if you use the masterpassword.  This allows you to turn off banners for
some subdomains, and turn them on for others.  I use the option of
having all banners 'on' in 'virtual.data' then turn them off on selected
records.

Finish the record and click REGISTER.

Do all of the following records:

	RECORD NAME:		whois.yourdomain.com
	ACTUAL LOCATION:	http://www.yourdomain.com/virtual/whois.htm

	RECORD NAME:		change.yourdomain.com
	ACTUAL LOCATION:	http://www.yourdomain.com/virtual/change.htm

	RECORD NAME:		www.yourdomain.com
	ACTUAL LOCATION:	http://www.yourdomain.com/mainsite/
				(Wherever you moved your homepage)

	RECORD NAME:		recent.yourdomain.com
	ACTUAL LOCATION:	http://www.yourdomain.com/virtual/recent.htm


You should now be able to use the following locations:

	http://whois.yourdomain.com
		To lookup and add records

	http://change.yourdomain.com
		To modify existing records

	http://www.yourdomain.com
		To get to your original homepage


Take a peek at your 'records' directory... and do a 'whois' on an existing record.
Everything should be working and ready to go...


FEQUENTLY ASKED QUESTIONS:
==========================

	Q. 	Will this system work with any domain? (.net.com .etc)
	A.	Yes,  VS3 has even been tested to work with
		subdomains of other subdomains, provided the dns
		of the original subdomain is set for Wildcards.

	
	Q.	Can I use multiple domain names on the same system?
	A.	Yes, however the web-interface only allows for one
		domain.  So records for other domains will have to
		be created by hand.  The easy way to do this, is
		to copy an existing record.  Rename it, and change
		the first two lines accordingly.

	A.A.	You can also install two different copies of the
		script using a different "virtual" directory.
		This will allow you to use the web-interface on
		multiple domains.


	Q.	My records are not being created when I use the
		whois.htm. It appears to work, but nothing is
		in the /records directory when it is finished.
	A.	You forgot to CHMOD 777 records.


	Q.	My recent.htm file is not being updated when
		someone adds or modifies a record.
	A.	You forgot to CHMOD 777 recent.htm


	Q.	When someone clicks on a banner, it attempts to
		open the website inside of the banner box.
	A.	Use my banner format.  You need a TARGET="TOP"
		command in your banner hyperlink.  Then it will
		open a new window.	

	Q.	I can create and modify subdomains. They are even
		in the records directory.  Still they do not work.
	A.	Make sure your INDEX.HTM file has a EXEC CGI not
		your original homepage. (Re-read the directions!)



Until Version 4.0
-Enjoy!

Jeff Ledger




